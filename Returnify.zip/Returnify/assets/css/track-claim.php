<?php
require_once '../config/init.php';
$db = getDB();

$claim = null;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $claimId = sanitize($_POST['claim_id'] ?? '');
    $email = sanitize($_POST['email'] ?? '');

    $stmt = $db->prepare("
        SELECT c.*, li.item_name AS lost_item_name
        FROM claims c
        LEFT JOIN lost_items li ON c.lost_item_id = li.id
        WHERE c.claim_id = :cid AND c.email = :email
    ");
    $stmt->execute([':cid' => $claimId, ':email' => $email]);
    $claim = $stmt->fetch();

    if (!$claim) {
        $error = 'No claim found with that ID and email combination.';
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Claim - University Lost & Found</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/public-style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg sticky-top glass-nav">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php"><i class="fas fa-search-location text-primary me-2"></i>Uni Lost & Found</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="found-items.php">Found Items</a></li>
                    <li class="nav-item"><a class="nav-link" href="report-lost.php">Report Lost</a></li>
                    <li class="nav-item"><a class="nav-link active" href="track-claim.php">Track Claim</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <h2 class="fw-bold mb-4"><i class="fas fa-search text-primary me-2"></i>Track Your Claim</h2>

                <?php if ($error): ?>
                    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>

                <?php if ($claim): ?>
                    <div class="glass-card p-4">
                        <h5 class="mb-3">Claim Status: <strong><?= $claim['claim_id'] ?></strong></h5>
                        <div class="mb-3">
                            <?php
                            $statusIcons = [
                                'pending' => ['icon' => 'fa-clock', 'color' => 'warning', 'text' => 'Pending Review'],
                                'under_review' => ['icon' => 'fa-search', 'color' => 'info', 'text' => 'Under Review'],
                                'approved' => ['icon' => 'fa-check-circle', 'color' => 'success', 'text' => 'Approved'],
                                'rejected' => ['icon' => 'fa-times-circle', 'color' => 'danger', 'text' => 'Rejected'],
                                'released' => ['icon' => 'fa-box-open', 'color' => 'success', 'text' => 'Item Released'],
                            ];
                            $s = $statusIcons[$claim['status']] ?? ['icon' => 'fa-circle', 'color' => 'secondary', 'text' => $claim['status']];
                            ?>
                            <span class="badge bg-<?= $s['color'] ?> p-3 fs-6">
                                <i class="fas <?= $s['icon'] ?> me-2"></i><?= $s['text'] ?>
                            </span>
                        </div>
                        <hr>
                        <p><strong>Claimed By:</strong> <?= htmlspecialchars($claim['claimed_by']) ?></p>
                        <p><strong>Item:</strong> <?= htmlspecialchars($claim['lost_item_name'] ?? 'N/A') ?></p>
                        <p><strong>Contact:</strong> <?= htmlspecialchars($claim['contact_number']) ?></p>
                        <p><strong>Submitted:</strong> <?= date('M d, Y H:i', strtotime($claim['created_at'])) ?></p>
                        <?php if ($claim['status'] === 'approved'): ?>
                            <div class="alert alert-success mt-3">
                                <i class="fas fa-info-circle me-2"></i>Your claim has been approved! Please visit the Lost & Found office with your student ID to collect your item.
                            </div>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="glass-card p-4">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Claim ID</label>
                                <input type="text" class="form-control" name="claim_id" required placeholder="e.g., CLM-20260119-1234">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Email Used in Claim</label>
                                <input type="email" class="form-control" name="email" required placeholder="your@email.com">
                            </div>
                            <button type="submit" class="btn btn-primary btn-lg w-100">
                                <i class="fas fa-search me-2"></i>Track Claim
                            </button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>