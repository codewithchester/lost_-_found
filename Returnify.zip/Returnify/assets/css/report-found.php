<?php
require_once '../config/init.php';
$db = getDB();

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $itemName = sanitize($_POST['item_name']);
    $category = sanitize($_POST['category']);
    $color = sanitize($_POST['color'] ?? '');
    $brand = sanitize($_POST['brand'] ?? '');
    $locationFound = sanitize($_POST['location_found']);
    $dateFound = sanitize($_POST['date_found']);
    $description = sanitize($_POST['description'] ?? '');
    $finderName = sanitize($_POST['finder_name']);
    $contactNumber = sanitize($_POST['contact_number']);
    $finderRole = sanitize($_POST['finder_role'] ?? 'student');

    $imageName = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../assets/uploads/found/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp']) && $_FILES['image']['size'] <= 5 * 1024 * 1024) {
            $imageName = 'found_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
            move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName);
        }
    }

    if (empty($error)) {
        $stmt = $db->prepare("
            INSERT INTO found_items (item_name, category, color, brand, location_found, date_found, description, finder_name, contact_number, finder_role, image)
            VALUES (:name, :cat, :color, :brand, :loc, :date, :desc, :finder, :contact, :role, :image)
        ");
        $stmt->execute([
            ':name' => $itemName, ':cat' => $category, ':color' => $color,
            ':brand' => $brand, ':loc' => $locationFound, ':date' => $dateFound,
            ':desc' => $description, ':finder' => $finderName,
            ':contact' => $contactNumber, ':role' => $finderRole, ':image' => $imageName
        ]);

        // Run matching engine
        $engine = new MatchEngine();
        $engine->findMatchesForFound($db->lastInsertId());

        $notif = new Notification();
        $notif->create('new_found', 'New Found Item Reported', "{$itemName} found at {$locationFound}");

        $success = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Found Item - University Lost & Found</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/public-style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg sticky-top glass-nav">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php"><i class="fas fa-search-location text-primary me-2"></i>Uni Lost & Found</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="found-items.php">Found Items</a></li>
                    <li class="nav-item"><a class="nav-link" href="report-lost.php">Report Lost</a></li>
                    <li class="nav-item"><a class="nav-link active" href="report-found.php">Report Found</a></li>
                    <li class="nav-item"><a class="nav-link" href="track-claim.php">Track Claim</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <h2 class="fw-bold mb-4"><i class="fas fa-hand-holding-heart text-success me-2"></i>Report Found Item</h2>

                <?php if ($success): ?>
                    <div class="glass-card p-5 text-center">
                        <i class="fas fa-check-circle text-success" style="font-size:60px;"></i>
                        <h3 class="mt-3">Thank You!</h3>
                        <p class="text-muted">Your found item has been recorded. It will be matched against our lost items database. The owner will be notified if a match is found.</p>
                        <a href="index.php" class="btn btn-primary">Back to Home</a>
                        <a href="report-found.php" class="btn btn-outline-success ms-2">Report Another</a>
                    </div>
                <?php else: ?>
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>

                    <div class="glass-card p-4">
                        <form method="POST" enctype="multipart/form-data">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Item Name *</label>
                                    <input type="text" class="form-control" name="item_name" required placeholder="e.g., iPhone 14">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Category *</label>
                                    <select class="form-select" name="category" required>
                                        <option value="">Select category...</option>
                                        <option>Electronics</option><option>Clothing</option><option>Books</option>
                                        <option>ID Cards</option><option>Keys</option><option>Bags</option>
                                        <option>Jewelry</option><option>Water Bottle</option><option>Other</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Color</label>
                                    <input type="text" class="form-control" name="color" placeholder="e.g., Silver">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Brand</label>
                                    <input type="text" class="form-control" name="brand" placeholder="e.g., Apple">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Date Found *</label>
                                    <input type="date" class="form-control" name="date_found" required>
                                </div>
                                <div class="col-md-12">
                                    <label class="form-label">Location Found *</label>
                                    <input type="text" class="form-control" name="location_found" required placeholder="e.g., Cafeteria">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Description</label>
                                    <textarea class="form-control" name="description" rows="3" placeholder="Describe the item you found..."></textarea>
                                </div>
                                <hr>
                                <h6 class="fw-bold">Your Contact Information</h6>
                                <div class="col-md-6">
                                    <label class="form-label">Your Full Name *</label>
                                    <input type="text" class="form-control" name="finder_name" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">You are a:</label>
                                    <select class="form-select" name="finder_role">
                                        <option value="student">Student</option>
                                        <option value="staff">Staff</option>
                                        <option value="security">Security</option>
                                        <option value="visitor">Visitor</option>
                                    </select>
                                </div>
                                <div class="col-md-12">
                                    <label class="form-label">Contact Number *</label>
                                    <input type="text" class="form-control" name="contact_number" required placeholder="e.g., +233 XX XXX XXXX">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Upload Image</label>
                                    <input type="file" class="form-control" name="image" accept=".jpg,.jpeg,.png,.webp">
                                </div>
                                <div class="col-12 mt-3">
                                    <button type="submit" class="btn btn-success btn-lg px-4">
                                        <i class="fas fa-paper-plane me-2"></i>Submit Found Item
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>