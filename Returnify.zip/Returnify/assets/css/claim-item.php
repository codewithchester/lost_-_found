<?php
require_once '../config/init.php';
$db = getDB();

$foundId = (int)($_GET['id'] ?? 0);
$item = $db->prepare("SELECT * FROM found_items WHERE id = :id");
$item->execute([':id' => $foundId]);
$item = $item->fetch();

if (!$item) {
    header('Location: found-items.php');
    exit;
}

$success = false;
$error = '';
// Initialize claim ID string to avoid undefined variable in templates
$claimIdStr = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $claimIdStr = 'CLM-' . date('Ymd') . '-' . rand(1000, 9999);

    // Find the matching lost item if any
    $matchStmt = $db->prepare("SELECT lost_item_id FROM matches WHERE found_item_id = :fid AND status = 'approved' LIMIT 1");
    $matchStmt->execute([':fid' => $foundId]);
    $matchId = $matchStmt->fetchColumn();

    $stmt = $db->prepare("
        INSERT INTO claims (claim_id, lost_item_id, match_id, claimed_by, student_id, contact_number, email, ownership_evidence, additional_notes)
        VALUES (:cid, :lid, :mid, :name, :sid, :contact, :email, :evidence, :notes)
    ");
    $stmt->execute([
        ':cid' => $claimIdStr,
        ':lid' => null, // We don't know the lost item yet
        ':mid' => $matchId ?: null,
        ':name' => sanitize($_POST['full_name']),
        ':sid' => sanitize($_POST['student_id'] ?? ''),
        ':contact' => sanitize($_POST['contact_number']),
        ':email' => sanitize($_POST['email'] ?? ''),
        ':evidence' => sanitize($_POST['ownership_evidence'] ?? ''),
        ':notes' => sanitize($_POST['additional_notes'] ?? '')
    ]);

    $notif = new Notification();
    $notif->create('claim_submitted', 'New Claim', "{$claimIdStr} - Someone claims {$item['item_name']}");

    $success = true;
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Claim Item - University Lost & Found</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/public-style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg sticky-top glass-nav">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php"><i class="fas fa-search-location text-primary me-2"></i>Uni Lost & Found</a>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <h2 class="fw-bold mb-4"><i class="fas fa-check-circle text-success me-2"></i>Claim This Item</h2>

                <?php if ($success): ?>
                    <div class="glass-card p-5 text-center">
                        <i class="fas fa-check-circle text-success" style="font-size:60px;"></i>
                        <h3 class="mt-3">Claim Submitted!</h3>
                        <p class="text-muted">Your claim reference is: <strong><?= $claimIdStr ?></strong></p>
                        <p>Our team will review your claim and contact you. Please bring proof of ownership (e.g., photo, receipt, description) when you come to collect.</p>
                        <a href="track-claim.php" class="btn btn-primary">Track Your Claim</a>
                    </div>
                <?php else: ?>
                    <!-- Item Preview -->
                    <div class="glass-card p-4 mb-4">
                        <div class="d-flex gap-3 align-items-center">
                            <?php if ($item['image']): ?>
                                <img src="../assets/uploads/found/<?= $item['image'] ?>" width="100" height="100" class="rounded" style="object-fit:cover;">
                            <?php endif; ?>
                            <div>
                                <h5><?= htmlspecialchars($item['item_name']) ?></h5>
                                <p class="mb-0 text-muted">
                                    Found at: <?= htmlspecialchars($item['location_found']) ?> |
                                    Date: <?= date('M d, Y', strtotime($item['date_found'])) ?>
                                </p>
                                <span class="badge bg-info"><?= htmlspecialchars($item['category']) ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="glass-card p-4">
                        <form method="POST">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Your Full Name *</label>
                                    <input type="text" class="form-control" name="full_name" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Student/Staff ID</label>
                                    <input type="text" class="form-control" name="student_id" placeholder="e.g., STU-2024-001">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Contact Number *</label>
                                    <input type="text" class="form-control" name="contact_number" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Ownership Evidence *</label>
                                    <textarea class="form-control" name="ownership_evidence" rows="3" required placeholder="Describe how this item belongs to you (e.g., 'It has a scratch on the bottom left', 'The case is navy blue with a university sticker')"></textarea>
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Additional Notes</label>
                                    <textarea class="form-control" name="additional_notes" rows="2"></textarea>
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-success btn-lg">
                                        <i class="fas fa-paper-plane me-2"></i>Submit Claim
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>