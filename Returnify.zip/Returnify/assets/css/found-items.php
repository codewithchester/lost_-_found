<?php
require_once '../config/init.php';
$db = getDB();

$search = sanitize($_GET['search'] ?? '');
$category = sanitize($_GET['category'] ?? '');

$sql = "SELECT * FROM found_items WHERE status IN ('found', 'unclaimed')";
$params = [];
if ($search) { $sql .= " AND (item_name LIKE :search OR description LIKE :search2 OR location_found LIKE :search3)"; $params[':search'] = "%{$search}%"; $params[':search2'] = "%{$search}%"; $params[':search3'] = "%{$search}%"; }
if ($category) { $sql .= " AND category = :cat"; $params[':cat'] = $category; }
$sql .= " ORDER BY created_at DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

$categories = $db->query("SELECT DISTINCT category FROM found_items ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browse Found Items - University Lost & Found</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/public-style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg sticky-top glass-nav">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php"><i class="fas fa-search-location text-primary me-2"></i>Uni Lost & Found</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link active" href="found-items.php">Found Items</a></li>
                    <li class="nav-item"><a class="nav-link" href="report-lost.php">Report Lost</a></li>
                    <li class="nav-item"><a class="nav-link" href="report-found.php">Report Found</a></li>
                    <li class="nav-item"><a class="nav-link" href="track-claim.php">Track Claim</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <h2 class="fw-bold mb-4"><i class="fas fa-hand-holding-heart text-success me-2"></i>Browse Found Items</h2>
        <p class="text-muted mb-4">See if your lost item has been found by someone on campus.</p>

        <!-- Search & Filter -->
        <div class="glass-card p-3 mb-4">
            <form method="GET" class="row g-2">
                <div class="col-md-6">
                    <input type="text" class="form-control" name="search" placeholder="Search by name or location..." value="<?= htmlspecialchars($search) ?>">
                </div>
                <div class="col-md-4">
                    <select class="form-select" name="category">
                        <option value="">All Categories</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= htmlspecialchars($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>><?= $cat ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100"><i class="fas fa-search me-1"></i>Filter</button>
                </div>
            </form>
        </div>

        <!-- Items Grid -->
        <div class="row g-3">
            <?php if (empty($items)): ?>
                <div class="col-12 text-center py-5">
                    <i class="fas fa-box-open text-muted mb-3" style="font-size:48px;"></i>
                    <h5>No found items match your search.</h5>
                </div>
            <?php endif; ?>
            <?php foreach ($items as $item): ?>
            <div class="col-md-4">
                <div class="glass-card h-100">
                    <?php if ($item['image']): ?>
                        <img src="../assets/uploads/found/<?= $item['image'] ?>" class="card-img-top" style="height:200px;object-fit:cover;">
                    <?php else: ?>
                        <div class="bg-light d-flex align-items-center justify-content-center" style="height:200px;">
                            <i class="fas fa-image text-muted" style="font-size:40px;"></i>
                        </div>
                    <?php endif; ?>
                    <div class="p-3">
                        <span class="badge bg-info mb-2"><?= htmlspecialchars($item['category']) ?></span>
                        <h5 class="card-title"><?= htmlspecialchars($item['item_name']) ?></h5>
                        <p class="small text-muted mb-1">
                            <i class="fas fa-map-marker-alt me-1"></i><?= htmlspecialchars($item['location_found']) ?><br>
                            <i class="fas fa-calendar me-1"></i><?= date('M d, Y', strtotime($item['date_found'])) ?>
                        </p>
                        <?php if ($item['color']): ?>
                            <small class="text-muted d-block">Color: <?= htmlspecialchars($item['color']) ?></small>
                        <?php endif; ?>
                        <?php if ($item['brand']): ?>
                            <small class="text-muted d-block">Brand: <?= htmlspecialchars($item['brand']) ?></small>
                        <?php endif; ?>
                        <a href="claim-item.php?id=<?= $item['id'] ?>" class="btn btn-sm btn-outline-success mt-2">
                            <i class="fas fa-check-circle me-1"></i>This is Mine
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>