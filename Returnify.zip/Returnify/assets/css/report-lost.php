<?php
require_once '../config/init.php';
$db = getDB();

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $itemName = sanitize($_POST['item_name']);
    $category = sanitize($_POST['category']);
    $color = sanitize($_POST['color'] ?? '');
    $brand = sanitize($_POST['brand'] ?? '');
    $locationLost = sanitize($_POST['location_lost']);
    $dateLost = sanitize($_POST['date_lost']);
    $description = sanitize($_POST['description'] ?? '');
    $ownerName = sanitize($_POST['owner_name']);
    $studentId = sanitize($_POST['student_id'] ?? '');
    $contactNumber = sanitize($_POST['contact_number']);
    $email = sanitize($_POST['email'] ?? '');

    // Handle image upload
    $imageName = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../assets/uploads/lost/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
            if ($_FILES['image']['size'] <= 5 * 1024 * 1024) {
                $imageName = 'lost_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName);
            } else {
                $error = 'Image must be under 5MB.';
            }
        } else {
            $error = 'Invalid image format. Use JPG, PNG, or WEBP.';
        }
    }

    if (empty($error)) {
        $stmt = $db->prepare("
            INSERT INTO lost_items (item_name, category, color, brand, location_lost, date_lost, description, owner_name, student_id, contact_number, email, image)
            VALUES (:name, :cat, :color, :brand, :location, :date, :desc, :owner, :sid, :contact, :email, :image)
        ");
        $stmt->execute([
            ':name' => $itemName, ':cat' => $category, ':color' => $color,
            ':brand' => $brand, ':location' => $locationLost,
            ':date' => $dateLost, ':desc' => $description,
            ':owner' => $ownerName, ':sid' => $studentId,
            ':contact' => $contactNumber, ':email' => $email,
            ':image' => $imageName
        ]);

        // Run matching engine
        $engine = new MatchEngine();
        $engine->findMatches($db->lastInsertId());

        // Notify admins
        $notif = new Notification();
        $notif->create('new_lost', 'New Lost Item Reported', "{$itemName} reported lost at {$locationLost} by {$ownerName}");

        $success = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Lost Item - University Lost & Found</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/public-style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg sticky-top glass-nav">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php"><i class="fas fa-search-location text-primary me-2"></i>Uni Lost & Found</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="found-items.php">Found Items</a></li>
                    <li class="nav-item"><a class="nav-link active" href="report-lost.php">Report Lost</a></li>
                    <li class="nav-item"><a class="nav-link" href="report-found.php">Report Found</a></li>
                    <li class="nav-item"><a class="nav-link" href="track-claim.php">Track Claim</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <h2 class="fw-bold mb-4"><i class="fas fa-box-open text-danger me-2"></i>Report Lost Item</h2>

                <?php if ($success): ?>
                    <div class="glass-card p-5 text-center">
                        <i class="fas fa-check-circle text-success" style="font-size:60px;"></i>
                        <h3 class="mt-3">Item Reported Successfully!</h3>
                        <p class="text-muted">Your lost item has been recorded. Our system will automatically search for matches with found items. We'll contact you if a match is found.</p>
                        <div class="mt-3">
                            <a href="index.php" class="btn btn-primary">Back to Home</a>
                            <a href="report-lost.php" class="btn btn-outline-primary ms-2">Report Another</a>
                        </div>
                    </div>
                <?php else: ?>
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>

                    <div class="glass-card p-4">
                        <form method="POST" enctype="multipart/form-data">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Item Name *</label>
                                    <input type="text" class="form-control" name="item_name" required placeholder="e.g., Black Dell Laptop">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Category *</label>
                                    <select class="form-select" name="category" required>
                                        <option value="">Select category...</option>
                                        <option>Electronics</option><option>Clothing</option><option>Books</option>
                                        <option>ID Cards</option><option>Keys</option><option>Bags</option>
                                        <option>Jewelry</option><option>Water Bottle</option><option>Other</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Color</label>
                                    <input type="text" class="form-control" name="color" placeholder="e.g., Black">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Brand</label>
                                    <input type="text" class="form-control" name="brand" placeholder="e.g., Dell">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Date Lost *</label>
                                    <input type="date" class="form-control" name="date_lost" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Location Lost *</label>
                                    <input type="text" class="form-control" name="location_lost" required placeholder="e.g., Library 2nd Floor">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Unique Features</label>
                                    <input type="text" class="form-control" name="unique_features" placeholder="Stickers, scratches, etc.">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Description</label>
                                    <textarea class="form-control" name="description" rows="3" placeholder="Describe your item in detail..."></textarea>
                                </div>
                                <hr>
                                <h6 class="fw-bold">Your Contact Information</h6>
                                <div class="col-md-6">
                                    <label class="form-label">Your Full Name *</label>
                                    <input type="text" class="form-control" name="owner_name" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Student/Staff ID</label>
                                    <input type="text" class="form-control" name="student_id" placeholder="e.g., STU-2024-001">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Contact Number *</label>
                                    <input type="text" class="form-control" name="contact_number" required placeholder="e.g., +233 XX XXX XXXX">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email" placeholder="your@email.com">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Upload Image (optional)</label>
                                    <input type="file" class="form-control" name="image" accept=".jpg,.jpeg,.png,.webp">
                                    <small class="text-muted">Max 5MB. JPG, PNG, or WEBP.</small>
                                </div>
                                <div class="col-12 mt-3">
                                    <button type="submit" class="btn btn-danger btn-lg px-4">
                                        <i class="fas fa-paper-plane me-2"></i>Submit Report
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>