// ============================================
// University Lost & Found Management System
// Main JavaScript
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebarClose = document.getElementById('sidebarClose');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', () => {
            if (sidebar) sidebar.classList.add('open');
            if (overlay) overlay.classList.add('active');
        });
    }

    if (sidebarClose) {
        sidebarClose.addEventListener('click', closeSidebar);
    }

    if (overlay) {
        overlay.addEventListener('click', closeSidebar);
    }

    function closeSidebar() {
        if (sidebar) sidebar.classList.remove('open');
        if (overlay) overlay.classList.remove('active');
    }

    // Theme detection and toggle
    initTheme();

    // Initialize DataTables
    initDataTables();

    // Image preview
    initImagePreview();

    // Auto-dismiss alerts
    document.querySelectorAll('.alert-dismissible').forEach(alert => {
        setTimeout(() => {
            alert.classList.remove('show');
            setTimeout(() => alert.remove(), 300);
        }, 5000);
    });

    // Confirmation dialogs
    document.querySelectorAll('[data-confirm]').forEach(el => {
        el.addEventListener('click', function(e) {
            if (!confirm(this.getAttribute('data-confirm') || 'Are you sure?')) {
                e.preventDefault();
            }
        });
    });
});

function initTheme() {
    const saved = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const icon = document.getElementById('themeIcon');
    if (saved === 'dark' || (!saved && prefersDark)) {
        document.documentElement.setAttribute('data-bs-theme', 'dark');
        if (icon) icon.className = 'fas fa-sun';
    }
}

function toggleTheme() {
    const html = document.documentElement;
    const icon = document.getElementById('themeIcon');
    if (html.getAttribute('data-bs-theme') === 'dark') {
        html.setAttribute('data-bs-theme', 'light');
        if (icon) icon.className = 'fas fa-moon';
        localStorage.setItem('theme', 'light');
    } else {
        html.setAttribute('data-bs-theme', 'dark');
        if (icon) icon.className = 'fas fa-sun';
        localStorage.setItem('theme', 'dark');
    }
}

function initDataTables() {
    document.querySelectorAll('.datatable').forEach(table => {
        if (!$.fn.DataTable.isDataTable(table)) {
            $(table).DataTable({
                responsive: true,
                pageLength: 25,
                lengthMenu: [10, 25, 50, 100],
                language: {
                    search: '<i class="fas fa-search"></i>',
                    searchPlaceholder: 'Search...',
                    paginate: {
                        previous: '<i class="fas fa-chevron-left"></i>',
                        next: '<i class="fas fa-chevron-right"></i>'
                    }
                },
                dom: '<"d-flex justify-content-between align-items-center mb-3"<"d-flex gap-2"l><"d-flex gap-2"f>>rt<"d-flex justify-content-between align-items-center mt-3"<"text-muted small"i><"pagination-wrap"p>>'
            });
        }
    });
}

function initImagePreview() {
    document.querySelectorAll('.image-upload').forEach(input => {
        input.addEventListener('change', function() {
            const wrapper = this.closest('.image-upload-wrapper');
            const preview = wrapper ? wrapper.querySelector('.image-preview') : null;
            const file = this.files[0];
            if (file && preview) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            }
        });
    });
}

function markAllRead() {
    fetch('../ajax/mark-all-read.php')
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data.success) location.reload();
        })
        .catch(console.error);
}

// Toast notification helper
function showToast(type, message) {
    if (typeof toastr !== 'undefined') {
        toastr[type](message);
    }
}

// Confirm action helper
function confirmAction(message, callback) {
    if (confirm(message)) {
        callback();
    }
}