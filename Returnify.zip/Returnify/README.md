<!-- # University Lost & Found Management System

## Setup Instructions

### Prerequisites
- XAMPP (PHP 8+, MySQL)
- Visual Studio Code

### Installation Steps

1. Copy the `lost-found-system` folder to `C:\xampp\htdocs\`

2. Start Apache & MySQL in XAMPP Control Panel

3. Open phpMyAdmin at http://localhost/phpmyadmin

4. Create a new database: `lost_found_db`

5. Import the SQL file: `sql/database.sql`

6. Configure database credentials in `config/database.php`:
   - Default: username=root, password=(empty)

7. Access the system: http://localhost/lost-found-system

### Default Login
- URL: http://localhost/lost-found-system/auth/login.php
- Username: admin
- Password: Admin@123

### Folder Structure -->