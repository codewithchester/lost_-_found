
<?php
// Simply redirect to the public homepage
header('Location: public/index.php');
exit;