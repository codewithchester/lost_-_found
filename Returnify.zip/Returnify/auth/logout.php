<?php
require_once '../config/init.php';

// Log the logout
if (isset($_SESSION['admin_id'])) {
    $logger = new ActivityLogger();
    $logger->log('logout', 'auth', $_SESSION['admin_id'], 'Admin logged out');
}

// Clear session
$_SESSION = [];

// Destroy session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destroy session
session_destroy();

// Clear remember me cookie
setcookie('remember_token', '', time() - 3600, '/');

header('Location: login.php?msg=logged_out');
exit;