<?php
$notif = new Notification();
$unreadCount = $notif->getUnreadCount();
$recentNotifs = $notif->getRecent(5);
?>
<!-- Top Navbar -->
<nav class="top-navbar glass-nav">
    <div class="d-flex align-items-center">
        <button class="sidebar-toggle me-3" id="sidebarToggle">
            <i class="fas fa-bars"></i>
        </button>
        <div class="search-box">
            <i class="fas fa-search"></i>
            <input type="text" class="search-input" placeholder="Search items, claims, users...">
        </div>
    </div>

    <div class="d-flex align-items-center gap-2">
        <!-- Theme Toggle -->
        <button class="btn btn-icon" onclick="toggleTheme()" title="Toggle theme">
            <i class="fas fa-moon" id="themeIcon"></i>
        </button>

        <!-- Notifications Dropdown -->
        <div class="dropdown">
            <button class="btn btn-icon position-relative" data-bs-toggle="dropdown">
                <i class="fas fa-bell"></i>
                <?php if ($unreadCount > 0): ?>
                    <span class="notification-badge"><?= $unreadCount > 99 ? '99+' : $unreadCount ?></span>
                <?php endif; ?>
            </button>
            <div class="dropdown-menu dropdown-menu-end notification-dropdown">
                <div class="dropdown-header d-flex justify-content-between">
                    <strong>Notifications</strong>
                    <?php if ($unreadCount > 0): ?>
                        <a href="#" class="small" onclick="markAllRead()">Mark all read</a>
                    <?php endif; ?>
                </div>
                <?php foreach ($recentNotifs as $n): ?>
                    <a href="#" class="dropdown-item <?= !$n['is_read'] ? 'unread' : '' ?>">
                        <div class="d-flex">
                            <i class="fas fa-info-circle me-2 mt-1 <?= !$n['is_read'] ? 'text-primary' : 'text-muted' ?>"></i>
                            <div>
                                <small class="d-block fw-semibold"><?= htmlspecialchars($n['title']) ?></small>
                                <small class="text-muted"><?= timeAgo($n['created_at']) ?></small>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
                <div class="dropdown-divider"></div>
                <a href="notifications.php" class="dropdown-item text-center text-primary">View All</a>
            </div>
        </div>

        <!-- User Dropdown -->
        <div class="dropdown">
            <button class="btn btn-icon dropdown-toggle" data-bs-toggle="dropdown">
                <div class="avatar-sm"><?= strtoupper(substr($_SESSION['admin_name'], 0, 2)) ?></div>
            </button>
            <div class="dropdown-menu dropdown-menu-end">
                <div class="dropdown-header">
                    <strong><?= htmlspecialchars($_SESSION['admin_name']) ?></strong><br>
                    <small class="text-muted"><?= $_SESSION['admin_role'] ?></small>
                </div>
                <div class="dropdown-divider"></div>
                <a href="settings.php" class="dropdown-item"><i class="fas fa-cog me-2"></i>Settings</a>
                <a href="../auth/logout.php" class="dropdown-item text-danger"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
            </div>
        </div>
    </div>
</nav>

<?php
function timeAgo($datetime) {
    $time = strtotime($datetime);
    $diff = time() - $time;
    if ($diff < 60) return 'Just now';
    if ($diff < 3600) return floor($diff/60).'m ago';
    if ($diff < 86400) return floor($diff/3600).'h ago';
    return floor($diff/86400).'d ago';
}
?>