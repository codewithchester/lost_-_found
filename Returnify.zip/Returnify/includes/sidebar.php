<?php
$currentPage = basename($_SERVER['PHP_SELF']);
$adminRole = $_SESSION['admin_role'] ?? 'admin';
?>
<!-- Sidebar Overlay for Mobile -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- Sidebar -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <a href="index.php" class="sidebar-brand">
            <i class="fas fa-search-location"></i>
            <span>Lost & Found</span>
        </a>
        <button class="sidebar-close d-lg-none" id="sidebarClose">
            <i class="fas fa-times"></i>
        </button>
    </div>

    <div class="sidebar-user">
        <div class="avatar">
            <?= strtoupper(substr($_SESSION['admin_name'], 0, 2)) ?>
        </div>
        <div class="user-info">
            <span class="user-name"><?= htmlspecialchars($_SESSION['admin_name']) ?></span>
            <span class="user-role"><?= ucfirst(str_replace('_', ' ', $adminRole)) ?></span>
        </div>
    </div>

    <nav class="sidebar-nav">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a href="index.php" class="nav-link <?= $currentPage == 'index.php' ? 'active' : '' ?>">
                    <i class="fas fa-th-large"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a href="lost-items.php" class="nav-link <?= $currentPage == 'lost-items.php' ? 'active' : '' ?>">
                    <i class="fas fa-box-open"></i> Lost Items
                </a>
            </li>
            <li class="nav-item">
                <a href="found-items.php" class="nav-link <?= $currentPage == 'found-items.php' ? 'active' : '' ?>">
                    <i class="fas fa-hand-holding-heart"></i> Found Items
                </a>
            </li>
            <li class="nav-item">
                <a href="matches.php" class="nav-link <?= $currentPage == 'matches.php' ? 'active' : '' ?>">
                    <i class="fas fa-magic"></i> Matches
                    <?php
                    $db = getDB();
                    $pendingMatches = $db->query("SELECT COUNT(*) FROM matches WHERE status='pending'")->fetchColumn();
                    if ($pendingMatches > 0): ?>
                        <span class="badge bg-warning ms-auto"><?= $pendingMatches ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item">
                <a href="claims.php" class="nav-link <?= $currentPage == 'claims.php' ? 'active' : '' ?>">
                    <i class="fas fa-clipboard-check"></i> Claims
                    <?php
                    $pendingClaimsBadge = $db->query("SELECT COUNT(*) FROM claims WHERE status='pending'")->fetchColumn();
                    if ($pendingClaimsBadge > 0): ?>
                        <span class="badge bg-danger ms-auto"><?= $pendingClaimsBadge ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item">
                <a href="rewards.php" class="nav-link <?= $currentPage == 'rewards.php' ? 'active' : '' ?>">
                    <i class="fas fa-trophy"></i> Rewards
                </a>
            </li>
            <li class="nav-item">
                <a href="payments.php" class="nav-link <?= $currentPage == 'payments.php' ? 'active' : '' ?>">
                    <i class="fas fa-money-bill-wave"></i> Payments
                </a>
            </li>
            <li class="nav-item">
                <a href="advertisements.php" class="nav-link <?= $currentPage == 'advertisements.php' ? 'active' : '' ?>">
                    <i class="fas fa-bullhorn"></i> Advertisements
                </a>
            </li>
            <li class="nav-item">
                <a href="users.php" class="nav-link <?= $currentPage == 'users.php' ? 'active' : '' ?>">
                    <i class="fas fa-users"></i> Users
                </a>
            </li>
            <li class="nav-item">
                <a href="notifications.php" class="nav-link <?= $currentPage == 'notifications.php' ? 'active' : '' ?>">
                    <i class="fas fa-bell"></i> Notifications
                </a>
            </li>
            <li class="nav-item">
                <a href="reports.php" class="nav-link <?= $currentPage == 'reports.php' ? 'active' : '' ?>">
                    <i class="fas fa-file-alt"></i> Reports
                </a>
            </li>
            <li class="nav-item">
                <a href="settings.php" class="nav-link <?= $currentPage == 'settings.php' ? 'active' : '' ?>">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </li>
            <li class="nav-item">
                <a href="activity-logs.php" class="nav-link <?= $currentPage == 'activity-logs.php' ? 'active' : '' ?>">
                    <i class="fas fa-history"></i> Activity Logs
                </a>
            </li>
        </ul>
    </nav>

    <div class="sidebar-footer">
        <a href="../auth/logout.php" class="btn btn-outline-danger btn-sm w-100">
            <i class="fas fa-sign-out-alt me-1"></i> Logout
        </a>
    </div>
</aside>