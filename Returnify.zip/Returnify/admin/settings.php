<?php
require_once '../config/init.php';
requireLogin();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST as $key => $value) {
        if ($key !== 'csrf_token') {
            $stmt = $db->prepare("UPDATE settings SET setting_value = :val WHERE setting_key = :key");
            $stmt->execute([':val' => sanitize($value), ':key' => $key]);
        }
    }
    setFlash('success', 'Settings saved successfully!');
    header('Location: settings.php');
    exit;
}

$settings = $db->query("SELECT * FROM settings")->fetchAll();
$settingsMap = [];
foreach ($settings as $s) { $settingsMap[$s['setting_key']] = $s['setting_value']; }

$pageTitle = 'Settings';
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<main class="main-content" id="mainContent">
<?php include '../includes/navbar.php'; ?>

<div class="container-fluid p-4">
    <h2 class="fw-bold mb-4"><i class="fas fa-cog text-muted me-2"></i>System Settings</h2>

    <form method="POST">
        <div class="glass-card p-4 mb-4">
            <h5 class="fw-bold mb-3">General Settings</h5>
            <div class="row g-3">
                <div class="col-md-6">
                    <label>Site Name</label>
                    <input type="text" class="form-control" name="site_name" value="<?= htmlspecialchars($settingsMap['site_name'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label>Admin Email</label>
                    <input type="email" class="form-control" name="admin_email" value="<?= htmlspecialchars($settingsMap['admin_email'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label>Session Timeout (minutes)</label>
                    <input type="number" class="form-control" name="session_timeout" value="<?= $settingsMap['session_timeout'] ?? '30' ?>">
                </div>
                <div class="col-md-6">
                    <label>Default Theme</label>
                    <select class="form-select" name="theme_default">
                        <option value="light" <?= ($settingsMap['theme_default'] ?? '') === 'light' ? 'selected' : '' ?>>Light</option>
                        <option value="dark" <?= ($settingsMap['theme_default'] ?? '') === 'dark' ? 'selected' : '' ?>>Dark</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="glass-card p-4 mb-4">
            <h5 class="fw-bold mb-3">Matching Engine</h5>
            <div class="row g-3">
                <div class="col-md-6">
                    <label>Match Threshold (%)</label>
                    <input type="number" class="form-control" name="match_threshold" value="<?= $settingsMap['match_threshold'] ?? '60' ?>" min="0" max="100">
                </div>
            </div>
        </div>

        <div class="glass-card p-4 mb-4">
            <h5 class="fw-bold mb-3">Security</h5>
            <div class="row g-3">
                <div class="col-md-6">
                    <label>Max Login Attempts</label>
                    <input type="number" class="form-control" name="max_login_attempts" value="<?= $settingsMap['max_login_attempts'] ?? '5' ?>">
                </div>
                <div class="col-md-6">
                    <label>Lockout Duration (minutes)</label>
                    <input type="number" class="form-control" name="lockout_duration" value="<?= $settingsMap['lockout_duration'] ?? '15' ?>">
                </div>
                <div class="col-md-6">
                    <label>Max Upload Size (MB)</label>
                    <input type="number" class="form-control" name="max_upload_size" value="<?= $settingsMap['max_upload_size'] ?? '5' ?>">
                </div>
                <div class="col-md-6">
                    <label>Allowed Extensions</label>
                    <input type="text" class="form-control" name="allowed_extensions" value="<?= $settingsMap['allowed_extensions'] ?? 'jpg,png,webp' ?>">
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-save me-2"></i>Save Settings</button>
    </form>
</div>
</main>
<?php include '../includes/footer.php'; ?>