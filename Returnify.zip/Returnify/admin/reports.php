<?php
require_once '../config/init.php';
requireLogin();

$db = getDB();
$pageTitle = 'Reports';
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<main class="main-content" id="mainContent">
<?php include '../includes/navbar.php'; ?>

<div class="container-fluid p-4">
    <h2 class="fw-bold mb-4"><i class="fas fa-file-alt text-primary me-2"></i>Reports</h2>

    <div class="row g-3">
        <div class="col-md-4">
            <div class="glass-card p-4 text-center">
                <i class="fas fa-box-open text-danger mb-3" style="font-size:40px;"></i>
                <h5>Lost Items Report</h5>
                <p class="text-muted small">Complete list of all lost items</p>
                <a href="export-lost-items.php" class="btn btn-outline-danger btn-sm"><i class="fas fa-file-pdf me-1"></i>PDF</a>
                <a href="export-lost-items.php?format=excel" class="btn btn-outline-success btn-sm"><i class="fas fa-file-excel me-1"></i>Excel</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="glass-card p-4 text-center">
                <i class="fas fa-hand-holding-heart text-success mb-3" style="font-size:40px;"></i>
                <h5>Found Items Report</h5>
                <p class="text-muted small">Complete list of all found items</p>
                <a href="export-found-items.php" class="btn btn-outline-danger btn-sm"><i class="fas fa-file-pdf me-1"></i>PDF</a>
                <a href="export-found-items.php?format=excel" class="btn btn-outline-success btn-sm"><i class="fas fa-file-excel me-1"></i>Excel</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="glass-card p-4 text-center">
                <i class="fas fa-magic text-info mb-3" style="font-size:40px;"></i>
                <h5>Matches Report</h5>
                <p class="text-muted small">All match records</p>
                <a href="export-matches.php" class="btn btn-outline-danger btn-sm"><i class="fas fa-file-pdf me-1"></i>PDF</a>
                <a href="export-matches.php?format=excel" class="btn btn-outline-success btn-sm"><i class="fas fa-file-excel me-1"></i>Excel</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="glass-card p-4 text-center">
                <i class="fas fa-clipboard-check text-warning mb-3" style="font-size:40px;"></i>
                <h5>Claims Report</h5>
                <p class="text-muted small">All claim records</p>
                <a href="export-claims.php" class="btn btn-outline-danger btn-sm"><i class="fas fa-file-pdf me-1"></i>PDF</a>
                <a href="export-claims.php?format=excel" class="btn btn-outline-success btn-sm"><i class="fas fa-file-excel me-1"></i>Excel</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="glass-card p-4 text-center">
                <i class="fas fa-money-bill-wave text-success mb-3" style="font-size:40px;"></i>
                <h5>Payments Report</h5>
                <p class="text-muted small">Financial transactions</p>
                <a href="export-payments.php" class="btn btn-outline-danger btn-sm"><i class="fas fa-file-pdf me-1"></i>PDF</a>
                <a href="export-payments.php?format=excel" class="btn btn-outline-success btn-sm"><i class="fas fa-file-excel me-1"></i>Excel</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="glass-card p-4 text-center">
                <i class="fas fa-trophy text-warning mb-3" style="font-size:40px;"></i>
                <h5>Rewards Report</h5>
                <p class="text-muted small">All reward distributions</p>
                <a href="export-rewards.php" class="btn btn-outline-danger btn-sm"><i class="fas fa-file-pdf me-1"></i>PDF</a>
                <a href="export-rewards.php?format=excel" class="btn btn-outline-success btn-sm"><i class="fas fa-file-excel me-1"></i>Excel</a>
            </div>
        </div>
    </div>
</div>
</main>
<?php include '../includes/footer.php'; ?>