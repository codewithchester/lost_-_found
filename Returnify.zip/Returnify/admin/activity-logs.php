<?php
require_once '../config/init.php';
requireLogin();

$db = getDB();
$logs = $db->query("SELECT al.*, a.fullname FROM activity_logs al LEFT JOIN admins a ON al.admin_id = a.id ORDER BY al.created_at DESC LIMIT 200")->fetchAll();

$pageTitle = 'Activity Logs';
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<main class="main-content" id="mainContent">
<?php include '../includes/navbar.php'; ?>

<div class="container-fluid p-4">
    <h2 class="fw-bold mb-4"><i class="fas fa-history text-muted me-2"></i>Activity Logs</h2>
    <div class="glass-card p-3">
        <table class="table table-glass datatable">
            <thead>
                <tr><th>ID</th><th>Admin</th><th>Action</th><th>Module</th><th>Details</th><th>IP</th><th>Date</th></tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $log): ?>
                <tr>
                    <td>#<?= $log['id'] ?></td>
                    <td><?= htmlspecialchars($log['fullname'] ?? 'System') ?></td>
                    <td><span class="badge bg-info"><?= htmlspecialchars($log['action']) ?></span></td>
                    <td><?= htmlspecialchars($log['module']) ?></td>
                    <td><?= htmlspecialchars($log['details'] ?? '') ?></td>
                    <td><small><?= $log['ip_address'] ?></small></td>
                    <td><?= date('M d, H:i:s', strtotime($log['created_at'])) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</main>
<?php include '../includes/footer.php'; ?>