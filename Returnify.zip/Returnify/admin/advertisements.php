<?php
require_once '../config/init.php';
requireLogin();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $title = sanitize($_POST['title']);
        $desc = sanitize($_POST['description'] ?? '');
        $startDate = $_POST['start_date'];
        $endDate = $_POST['end_date'];
        $status = $_POST['status'] ?? 'active';

        $banner = null;
        if (isset($_FILES['banner']) && $_FILES['banner']['error'] === UPLOAD_ERR_OK) {
            $dir = '../assets/uploads/ads/';
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            $ext = strtolower(pathinfo($_FILES['banner']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
                $banner = 'ad_' . time() . '.' . $ext;
                move_uploaded_file($_FILES['banner']['tmp_name'], $dir . $banner);
            }
        }

        if ($action === 'create') {
            $stmt = $db->prepare("INSERT INTO advertisements (title, description, banner_image, start_date, end_date, status, created_by) VALUES (:t, :d, :b, :s, :e, :st, :cb)");
            $stmt->execute([':t' => $title, ':d' => $desc, ':b' => $banner, ':s' => $startDate, ':e' => $endDate, ':st' => $status, ':cb' => $_SESSION['admin_id']]);
            setFlash('success', 'Advertisement created!');
        } else {
            $id = (int)$_POST['id'];
            $sql = "UPDATE advertisements SET title=:t, description=:d, start_date=:s, end_date=:e, status=:st";
            $params = [':t' => $title, ':d' => $desc, ':s' => $startDate, ':e' => $endDate, ':st' => $status, ':id' => $id];
            if ($banner) { $sql .= ", banner_image=:b"; $params[':b'] = $banner; }
            $sql .= " WHERE id=:id";
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            setFlash('success', 'Advertisement updated!');
        }
        header('Location: advertisements.php');
        exit;
    }

    if ($action === 'delete') {
        $stmt = $db->prepare("DELETE FROM advertisements WHERE id = :id");
        $stmt->execute([':id' => (int)$_POST['id']]);
        setFlash('success', 'Advertisement deleted.');
        header('Location: advertisements.php');
        exit;
    }
}

$ads = $db->query("SELECT * FROM advertisements ORDER BY created_at DESC")->fetchAll();
$pageTitle = 'Advertisements';
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<main class="main-content" id="mainContent">
<?php include '../includes/navbar.php'; ?>

<div class="container-fluid p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1"><i class="fas fa-bullhorn text-danger me-2"></i>Advertisements</h2>
        </div>
        <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#adModal" onclick="resetAdForm()">
            <i class="fas fa-plus me-1"></i>New Advertisement
        </button>
    </div>

    <div class="row g-3">
        <?php foreach ($ads as $ad): ?>
        <div class="col-md-4">
            <div class="glass-card h-100">
                <?php if ($ad['banner_image']): ?>
                    <img src="../assets/uploads/ads/<?= $ad['banner_image'] ?>" class="card-img-top" style="height:160px;object-fit:cover;">
                <?php endif; ?>
                <div class="p-3">
                    <span class="badge bg-<?= $ad['status'] === 'active' ? 'success' : ($ad['status'] === 'scheduled' ? 'info' : 'secondary') ?> mb-2"><?= ucfirst($ad['status']) ?></span>
                    <h6><?= htmlspecialchars($ad['title']) ?></h6>
                    <p class="small text-muted"><?= htmlspecialchars(substr($ad['description'] ?? '', 0, 100)) ?>...</p>
                    <small class="text-muted"><?= $ad['start_date'] ?> - <?= $ad['end_date'] ?></small>
                    <div class="mt-2">
                        <button class="btn btn-sm btn-outline-primary" onclick="editAd(<?= htmlspecialchars(json_encode($ad)) ?>)"><i class="fas fa-edit"></i></button>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= $ad['id'] ?>">
                            <button class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Ad Modal -->
<div class="modal fade" id="adModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content glass-card">
            <div class="modal-header"><h5 id="adModalTitle">New Advertisement</h5></div>
            <form method="POST" enctype="multipart/form-data" id="adForm">
                <div class="modal-body">
                    <input type="hidden" name="action" id="adAction" value="create">
                    <input type="hidden" name="id" id="adId">
                    <div class="row g-3">
                        <div class="col-12"><label>Title *</label><input type="text" class="form-control" name="title" id="adTitle" required></div>
                        <div class="col-12"><label>Description</label><textarea class="form-control" name="description" id="adDesc" rows="3"></textarea></div>
                        <div class="col-12"><label>Banner Image</label><input type="file" class="form-control" name="banner" accept=".jpg,.jpeg,.png,.webp"></div>
                        <div class="col-md-6"><label>Start Date *</label><input type="date" class="form-control" name="start_date" id="adStart" required></div>
                        <div class="col-md-6"><label>End Date *</label><input type="date" class="form-control" name="end_date" id="adEnd" required></div>
                        <div class="col-md-6"><label>Status</label>
                            <select class="form-select" name="status" id="adStatus">
                                <option value="active">Active</option><option value="inactive">Inactive</option><option value="scheduled">Scheduled</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
</main>

<script>
function resetAdForm() {
    document.getElementById('adAction').value = 'create';
    document.getElementById('adId').value = '';
    document.getElementById('adModalTitle').textContent = 'New Advertisement';
    document.getElementById('adForm').reset();
}
function editAd(ad) {
    document.getElementById('adAction').value = 'update';
    document.getElementById('adId').value = ad.id;
    document.getElementById('adModalTitle').textContent = 'Edit Advertisement';
    document.getElementById('adTitle').value = ad.title;
    document.getElementById('adDesc').value = ad.description || '';
    document.getElementById('adStart').value = ad.start_date;
    document.getElementById('adEnd').value = ad.end_date;
    document.getElementById('adStatus').value = ad.status;
    new bootstrap.Modal(document.getElementById('adModal')).show();
}
</script>
<?php include '../includes/footer.php'; ?>