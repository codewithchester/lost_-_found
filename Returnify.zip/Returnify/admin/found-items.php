<?php
require_once '../config/init.php';
requireLogin();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $itemName = sanitize($_POST['item_name']);
        $category = sanitize($_POST['category']);
        $color = sanitize($_POST['color'] ?? '');
        $brand = sanitize($_POST['brand'] ?? '');
        $locationFound = sanitize($_POST['location_found']);
        $dateFound = sanitize($_POST['date_found']);
        $description = sanitize($_POST['description'] ?? '');
        $finderName = sanitize($_POST['finder_name']);
        $contactNumber = sanitize($_POST['contact_number']);
        $finderRole = sanitize($_POST['finder_role'] ?? 'student');

        $imageName = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = '../assets/uploads/found/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
                $imageName = 'found_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName);
            }
        }

        if ($action === 'create') {
            $stmt = $db->prepare("
                INSERT INTO found_items (item_name, category, color, brand, location_found, date_found, description, finder_name, contact_number, finder_role, image)
                VALUES (:name, :cat, :color, :brand, :location, :date, :desc, :finder, :contact, :role, :image)
            ");
            $stmt->execute([
                ':name' => $itemName, ':cat' => $category, ':color' => $color,
                ':brand' => $brand, ':location' => $locationFound,
                ':date' => $dateFound, ':desc' => $description,
                ':finder' => $finderName, ':contact' => $contactNumber,
                ':role' => $finderRole, ':image' => $imageName
            ]);

            $engine = new MatchEngine();
            $engine->findMatchesForFound($db->lastInsertId());

            $notif = new Notification();
            $notif->create('new_found', 'New Found Item Reported', "{$itemName} found at {$locationFound}");

            setFlash('success', 'Found item recorded successfully!');
        } elseif ($action === 'update') {
            $id = (int)$_POST['id'];
            $sql = "UPDATE found_items SET item_name=:name, category=:cat, color=:color, brand=:brand, location_found=:location, date_found=:date, description=:desc, finder_name=:finder, contact_number=:contact, finder_role=:role";
            $params = [
                ':name' => $itemName, ':cat' => $category, ':color' => $color,
                ':brand' => $brand, ':location' => $locationFound,
                ':date' => $dateFound, ':desc' => $description,
                ':finder' => $finderName, ':contact' => $contactNumber,
                ':role' => $finderRole, ':id' => $id
            ];
            if ($imageName) {
                $sql .= ", image=:image";
                $params[':image'] = $imageName;
            }
            $sql .= " WHERE id=:id";
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            setFlash('success', 'Found item updated!');
        }
        header('Location: found-items.php');
        exit;
    }

    if ($action === 'delete') {
        $id = (int)$_POST['id'];
        $stmt = $db->prepare("DELETE FROM found_items WHERE id = :id");
        $stmt->execute([':id' => $id]);
        setFlash('success', 'Found item deleted.');
        header('Location: found-items.php');
        exit;
    }
}

$items = $db->query("SELECT * FROM found_items ORDER BY created_at DESC")->fetchAll();
$pageTitle = 'Found Items';
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<main class="main-content" id="mainContent">
<?php include '../includes/navbar.php'; ?>

<div class="container-fluid p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1"><i class="fas fa-hand-holding-heart text-success me-2"></i>Found Items</h2>
            <p class="text-muted mb-0">Manage all reported found items</p>
        </div>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#foundModal" onclick="resetFoundForm()">
            <i class="fas fa-plus me-1"></i>Report Found Item
        </button>
    </div>

    <div class="glass-card p-3">
        <div class="table-responsive">
            <table class="table table-glass datatable">
                <thead>
                    <tr>
                        <th>ID</th><th>Image</th><th>Item Name</th><th>Category</th>
                        <th>Color</th><th>Brand</th><th>Location Found</th>
                        <th>Date Found</th><th>Finder</th><th>Contact</th>
                        <th>Status</th><th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                    <tr>
                        <td>#<?= $item['id'] ?></td>
                        <td>
                            <?php if ($item['image']): ?>
                                <img src="../assets/uploads/found/<?= $item['image'] ?>" width="50" height="50" class="rounded" style="object-fit:cover;">
                            <?php else: ?>
                                <div class="bg-light rounded d-flex align-items-center justify-content-center" style="width:50px;height:50px;">
                                    <i class="fas fa-image text-muted"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td><strong><?= htmlspecialchars($item['item_name']) ?></strong></td>
                        <td><span class="badge bg-info"><?= htmlspecialchars($item['category']) ?></span></td>
                        <td><?= htmlspecialchars($item['color'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($item['brand'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($item['location_found']) ?></td>
                        <td><?= date('M d, Y', strtotime($item['date_found'])) ?></td>
                        <td><?= htmlspecialchars($item['finder_name']) ?></td>
                        <td><?= htmlspecialchars($item['contact_number']) ?></td>
                        <td>
                            <?php
                            $statusClass = ['found' => 'info', 'matched' => 'primary', 'claimed' => 'warning', 'resolved' => 'success', 'unclaimed' => 'secondary'];
                            ?>
                            <span class="badge badge-status bg-<?= $statusClass[$item['status']] ?? 'secondary' ?>">
                                <?= ucfirst($item['status']) ?>
                            </span>
                        </td>
                        <td>
                            <div class="btn-group">
                                <button class="btn btn-sm btn-outline-primary" onclick="editFoundItem(<?= htmlspecialchars(json_encode($item)) ?>)">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Delete?')">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                    <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Found Item Modal -->
<div class="modal fade" id="foundModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content glass-card">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-hand-holding-heart me-2"></i><span id="foundModalTitle">Report Found Item</span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" enctype="multipart/form-data" id="foundForm">
                <div class="modal-body">
                    <input type="hidden" name="action" id="foundAction" value="create">
                    <input type="hidden" name="id" id="foundId">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Item Name *</label>
                            <input type="text" class="form-control" name="item_name" id="foundName" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Category *</label>
                            <select class="form-select" name="category" id="foundCategory" required>
                                <option value="">Select...</option>
                                <option>Electronics</option><option>Clothing</option><option>Books</option>
                                <option>ID Cards</option><option>Keys</option><option>Bags</option>
                                <option>Jewelry</option><option>Other</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Color</label>
                            <input type="text" class="form-control" name="color" id="foundColor">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Brand</label>
                            <input type="text" class="form-control" name="brand" id="foundBrand">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Location Found *</label>
                            <input type="text" class="form-control" name="location_found" id="foundLocation" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Date Found *</label>
                            <input type="date" class="form-control" name="date_found" id="foundDate" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Finder Role</label>
                            <select class="form-select" name="finder_role" id="foundRole">
                                <option value="student">Student</option>
                                <option value="staff">Staff</option>
                                <option value="security">Security</option>
                                <option value="visitor">Visitor</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" id="foundDesc" rows="2"></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Finder Name *</label>
                            <input type="text" class="form-control" name="finder_name" id="foundFinder" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Contact Number *</label>
                            <input type="text" class="form-control" name="contact_number" id="foundContact" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Image</label>
                            <input type="file" class="form-control image-upload" name="image" accept=".jpg,.jpeg,.png,.webp">
                            <img class="image-preview mt-2 rounded" style="max-width:200px;display:none;">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success"><i class="fas fa-save me-1"></i>Save Item</button>
                </div>
            </form>
        </div>
    </div>
</div>
</main>

<script>
function resetFoundForm() {
    document.getElementById('foundAction').value = 'create';
    document.getElementById('foundId').value = '';
    document.getElementById('foundModalTitle').textContent = 'Report Found Item';
    document.getElementById('foundForm').reset();
}
function editFoundItem(item) {
    document.getElementById('foundAction').value = 'update';
    document.getElementById('foundId').value = item.id;
    document.getElementById('foundModalTitle').textContent = 'Edit Found Item';
    document.getElementById('foundName').value = item.item_name;
    document.getElementById('foundCategory').value = item.category;
    document.getElementById('foundColor').value = item.color || '';
    document.getElementById('foundBrand').value = item.brand || '';
    document.getElementById('foundLocation').value = item.location_found;
    document.getElementById('foundDate').value = item.date_found;
    document.getElementById('foundDesc').value = item.description || '';
    document.getElementById('foundFinder').value = item.finder_name;
    document.getElementById('foundContact').value = item.contact_number;
    document.getElementById('foundRole').value = item.finder_role;
    new bootstrap.Modal(document.getElementById('foundModal')).show();
}
</script>

<?php include '../includes/footer.php'; ?>