<?php
require_once '../config/init.php';
requireLogin();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $stmt = $db->prepare("
            INSERT INTO rewards (finder_name, lost_item_id, match_id, reward_amount, reward_date, notes)
            VALUES (:finder, :lid, :mid, :amount, :date, :notes)
        ");
        $stmt->execute([
            ':finder' => sanitize($_POST['finder_name']),
            ':lid' => $_POST['lost_item_id'] ? (int)$_POST['lost_item_id'] : null,
            ':mid' => $_POST['match_id'] ? (int)$_POST['match_id'] : null,
            ':amount' => (float)$_POST['reward_amount'],
            ':date' => $_POST['reward_date'],
            ':notes' => sanitize($_POST['notes'] ?? '')
        ]);
        setFlash('success', 'Reward recorded!');
    } elseif ($action === 'mark_paid') {
        $stmt = $db->prepare("UPDATE rewards SET status = 'paid' WHERE id = :id");
        $stmt->execute([':id' => (int)$_POST['id']]);
        setFlash('success', 'Reward marked as paid.');
    }

    header('Location: rewards.php');
    exit;
}

$rewards = $db->query("SELECT r.*, li.item_name FROM rewards r LEFT JOIN lost_items li ON r.lost_item_id = li.id ORDER BY r.created_at DESC")->fetchAll();
$totalRewards = $db->query("SELECT COALESCE(SUM(reward_amount),0) FROM rewards")->fetchColumn();
$paidRewards = $db->query("SELECT COALESCE(SUM(reward_amount),0) FROM rewards WHERE status='paid'")->fetchColumn();

$pageTitle = 'Rewards';
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<main class="main-content" id="mainContent">
<?php include '../includes/navbar.php'; ?>

<div class="container-fluid p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1"><i class="fas fa-trophy text-warning me-2"></i>Reward Management</h2>
            <p class="text-muted mb-0">Track rewards issued to finders</p>
        </div>
        <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#rewardModal">
            <i class="fas fa-plus me-1"></i>Issue Reward
        </button>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="glass-card p-4 text-center">
                <i class="fas fa-coins text-warning mb-2" style="font-size:32px;"></i>
                <h3 class="fw-bold">$<?= number_format($totalRewards, 2) ?></h3>
                <small class="text-muted">Total Rewards</small>
            </div>
        </div>
        <div class="col-md-4">
            <div class="glass-card p-4 text-center">
                <i class="fas fa-check-circle text-success mb-2" style="font-size:32px;"></i>
                <h3 class="fw-bold">$<?= number_format($paidRewards, 2) ?></h3>
                <small class="text-muted">Paid Rewards</small>
            </div>
        </div>
        <div class="col-md-4">
            <div class="glass-card p-4 text-center">
                <i class="fas fa-user-check text-primary mb-2" style="font-size:32px;"></i>
                <h3 class="fw-bold"><?= count($rewards) ?></h3>
                <small class="text-muted">Total Recipients</small>
            </div>
        </div>
    </div>

    <div class="glass-card p-3">
        <table class="table table-glass datatable">
            <thead>
                <tr><th>ID</th><th>Finder</th><th>Item</th><th>Amount</th><th>Date</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php foreach ($rewards as $r): ?>
                <tr>
                    <td>#<?= $r['id'] ?></td>
                    <td><?= htmlspecialchars($r['finder_name']) ?></td>
                    <td><?= htmlspecialchars($r['item_name'] ?? 'N/A') ?></td>
                    <td><strong>$<?= number_format($r['reward_amount'], 2) ?></strong></td>
                    <td><?= $r['reward_date'] ?></td>
                    <td><span class="badge bg-<?= $r['status'] === 'paid' ? 'success' : 'warning' ?>"><?= ucfirst($r['status']) ?></span></td>
                    <td>
                        <?php if ($r['status'] === 'pending'): ?>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="action" value="mark_paid">
                            <input type="hidden" name="id" value="<?= $r['id'] ?>">
                            <button class="btn btn-sm btn-success">Mark Paid</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="rewardModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content glass-card">
            <div class="modal-header"><h5 class="modal-title">Issue Reward</h5></div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="create">
                    <div class="mb-3">
                        <label>Finder Name *</label>
                        <input type="text" class="form-control" name="finder_name" required>
                    </div>
                    <div class="mb-3">
                        <label>Item (optional)</label>
                        <select class="form-select" name="lost_item_id">
                            <option value="">Select...</option>
                            <?php
                            $items = $db->query("SELECT id, item_name FROM lost_items WHERE status='resolved'")->fetchAll();
                            foreach ($items as $it): ?>
                                <option value="<?= $it['id'] ?>"><?= htmlspecialchars($it['item_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Amount *</label>
                        <input type="number" step="0.01" class="form-control" name="reward_amount" required>
                    </div>
                    <div class="mb-3">
                        <label>Date *</label>
                        <input type="date" class="form-control" name="reward_date" required>
                    </div>
                    <div class="mb-3">
                        <label>Notes</label>
                        <textarea class="form-control" name="notes" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">Issue Reward</button>
                </div>
            </form>
        </div>
    </div>
</div>
</main>
<?php include '../includes/footer.php'; ?>