<?php
require_once '../config/init.php';
requireLogin();

$db = getDB();
$message = '';

// Handle CRUD operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $itemName = sanitize($_POST['item_name']);
        $category = sanitize($_POST['category']);
        $color = sanitize($_POST['color'] ?? '');
        $brand = sanitize($_POST['brand'] ?? '');
        $uniqueFeatures = sanitize($_POST['unique_features'] ?? '');
        $locationLost = sanitize($_POST['location_lost']);
        $dateLost = sanitize($_POST['date_lost']);
        $description = sanitize($_POST['description'] ?? '');
        $ownerName = sanitize($_POST['owner_name']);
        $studentId = sanitize($_POST['student_id'] ?? '');
        $contactNumber = sanitize($_POST['contact_number']);
        $email = sanitize($_POST['email'] ?? '');

        // Handle image upload
        $imageName = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = '../assets/uploads/lost/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
                $imageName = 'lost_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName);
            }
        }

        if ($action === 'create') {
            $stmt = $db->prepare("
                INSERT INTO lost_items (item_name, category, color, brand, unique_features, location_lost, date_lost, description, owner_name, student_id, contact_number, email, image)
                VALUES (:name, :cat, :color, :brand, :features, :location, :date, :desc, :owner, :sid, :contact, :email, :image)
            ");
            $stmt->execute([
                ':name' => $itemName, ':cat' => $category, ':color' => $color,
                ':brand' => $brand, ':features' => $uniqueFeatures,
                ':location' => $locationLost, ':date' => $dateLost,
                ':desc' => $description, ':owner' => $ownerName,
                ':sid' => $studentId, ':contact' => $contactNumber,
                ':email' => $email, ':image' => $imageName
            ]);

            // Run matching engine
            $engine = new MatchEngine();
            $engine->findMatches($db->lastInsertId());

            $notif = new Notification();
            $notif->create('new_lost', 'New Lost Item Reported', "{$itemName} reported lost at {$locationLost}");

            $logger = new ActivityLogger();
            $logger->log('create', 'lost_items', $db->lastInsertId(), "Created lost item: {$itemName}");

            setFlash('success', 'Lost item reported successfully!');
        } elseif ($action === 'update') {
            $id = (int)$_POST['id'];
            $sql = "UPDATE lost_items SET item_name=:name, category=:cat, color=:color, brand=:brand, unique_features=:features, location_lost=:location, date_lost=:date, description=:desc, owner_name=:owner, student_id=:sid, contact_number=:contact, email=:email";
            $params = [
                ':name' => $itemName, ':cat' => $category, ':color' => $color,
                ':brand' => $brand, ':features' => $uniqueFeatures,
                ':location' => $locationLost, ':date' => $dateLost,
                ':desc' => $description, ':owner' => $ownerName,
                ':sid' => $studentId, ':contact' => $contactNumber,
                ':email' => $email, ':id' => $id
            ];
            if ($imageName) {
                $sql .= ", image=:image";
                $params[':image'] = $imageName;
            }
            $sql .= " WHERE id=:id";
            $stmt = $db->prepare($sql);
            $stmt->execute($params);

            setFlash('success', 'Lost item updated successfully!');
        }
        header('Location: lost-items.php');
        exit;
    }

    if ($action === 'delete') {
        $id = (int)$_POST['id'];
        $stmt = $db->prepare("DELETE FROM lost_items WHERE id = :id");
        $stmt->execute([':id' => $id]);
        setFlash('success', 'Lost item deleted.');
        header('Location: lost-items.php');
        exit;
    }
}

// Fetch all lost items
$items = $db->query("SELECT * FROM lost_items ORDER BY created_at DESC")->fetchAll();
$pageTitle = 'Lost Items';
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<main class="main-content" id="mainContent">
<?php include '../includes/navbar.php'; ?>

<div class="container-fluid p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1"><i class="fas fa-box-open text-primary me-2"></i>Lost Items</h2>
            <p class="text-muted mb-0">Manage all reported lost items</p>
        </div>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#itemModal" onclick="resetForm()">
            <i class="fas fa-plus me-1"></i>Report Lost Item
        </button>
    </div>

    <!-- Filters -->
    <div class="glass-card p-3 mb-4">
        <div class="row g-2">
            <div class="col-md-3">
                <select class="form-select" id="filterCategory" onchange="applyFilters()">
                    <option value="">All Categories</option>
                    <option>Electronics</option><option>Clothing</option><option>Books</option>
                    <option>ID Cards</option><option>Keys</option><option>Bags</option>
                    <option>Jewelry</option><option>Other</option>
                </select>
            </div>
            <div class="col-md-3">
                <select class="form-select" id="filterStatus" onchange="applyFilters()">
                    <option value="">All Status</option>
                    <option value="lost">Lost</option>
                    <option value="matched">Matched</option>
                    <option value="claimed">Claimed</option>
                    <option value="resolved">Resolved</option>
                </select>
            </div>
            <div class="col-md-3">
                <input type="date" class="form-control" id="filterDate" onchange="applyFilters()">
            </div>
            <div class="col-md-3">
                <input type="text" class="form-control" id="filterSearch" placeholder="Search items..." onkeyup="applyFilters()">
            </div>
        </div>
    </div>

    <!-- Items Table -->
    <div class="glass-card p-3">
        <div class="table-responsive">
            <table class="table table-glass datatable" id="lostItemsTable">
                <thead>
                    <tr>
                        <th>ID</th><th>Image</th><th>Item Name</th><th>Category</th>
                        <th>Color</th><th>Brand</th><th>Location Lost</th>
                        <th>Date Lost</th><th>Owner</th><th>Contact</th>
                        <th>Status</th><th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                    <tr>
                        <td>#<?= $item['id'] ?></td>
                        <td>
                            <?php if ($item['image']): ?>
                                <img src="../assets/uploads/lost/<?= $item['image'] ?>" width="50" height="50" class="rounded" style="object-fit:cover;">
                            <?php else: ?>
                                <div class="bg-light rounded d-flex align-items-center justify-content-center" style="width:50px;height:50px;">
                                    <i class="fas fa-image text-muted"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td><strong><?= htmlspecialchars($item['item_name']) ?></strong></td>
                        <td><span class="badge bg-info"><?= htmlspecialchars($item['category']) ?></span></td>
                        <td><?= htmlspecialchars($item['color'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($item['brand'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($item['location_lost']) ?></td>
                        <td><?= date('M d, Y', strtotime($item['date_lost'])) ?></td>
                        <td><?= htmlspecialchars($item['owner_name']) ?></td>
                        <td><?= htmlspecialchars($item['contact_number']) ?></td>
                        <td>
                            <?php
                            $statusClass = [
                                'lost' => 'danger', 'matched' => 'info',
                                'claimed' => 'warning', 'resolved' => 'success'
                            ];
                            ?>
                            <span class="badge badge-status bg-<?= $statusClass[$item['status']] ?? 'secondary' ?>">
                                <?= ucfirst($item['status']) ?>
                            </span>
                        </td>
                        <td>
                            <div class="btn-group">
                                <button class="btn btn-sm btn-outline-primary" onclick="editItem(<?= htmlspecialchars(json_encode($item)) ?>)">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <a href="matches.php?lost_id=<?= $item['id'] ?>" class="btn btn-sm btn-outline-info" title="Find Matches">
                                    <i class="fas fa-magic"></i>
                                </a>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this item?')">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                    <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal - FIXED with proper scrolling -->
<div class="modal fade" id="itemModal" tabindex="-1" aria-labelledby="itemModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="itemModalLabel">
                    <i class="fas fa-box-open me-2"></i><span id="modalTitle">Report Lost Item</span>
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" enctype="multipart/form-data" id="itemForm">
                <div class="modal-body" style="max-height: 70vh; overflow-y: auto;">
                    <input type="hidden" name="action" id="formAction" value="create">
                    <input type="hidden" name="id" id="itemId">
                    
                    <!-- Item Information Section -->
                    <h6 class="fw-bold text-primary mb-3">
                        <i class="fas fa-info-circle me-1"></i>Item Information
                    </h6>
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Item Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="item_name" id="itemName" required placeholder="e.g., Dell Laptop XPS 15">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Category <span class="text-danger">*</span></label>
                            <select class="form-select" name="category" id="itemCategory" required>
                                <option value="">Select category...</option>
                                <option>Electronics</option><option>Clothing</option>
                                <option>Books</option><option>ID Cards</option>
                                <option>Keys</option><option>Bags</option>
                                <option>Jewelry</option><option>Water Bottle</option>
                                <option>Other</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Color</label>
                            <input type="text" class="form-control" name="color" id="itemColor" placeholder="e.g., Silver">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Brand</label>
                            <input type="text" class="form-control" name="brand" id="itemBrand" placeholder="e.g., Dell">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Unique Features</label>
                            <input type="text" class="form-control" name="unique_features" id="itemFeatures" placeholder="Stickers, scratches...">
                        </div>
                    </div>

                    <!-- Location & Date Section -->
                    <h6 class="fw-bold text-primary mb-3">
                        <i class="fas fa-map-marker-alt me-1"></i>Location & Date
                    </h6>
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Location Lost <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="location_lost" id="itemLocation" required placeholder="e.g., Library 2nd Floor">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Date Lost <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="date_lost" id="itemDate" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Description</label>
                            <textarea class="form-control" name="description" id="itemDesc" rows="3" placeholder="Describe your item in detail (size, condition, distinguishing marks)..."></textarea>
                        </div>
                    </div>

                    <!-- Owner Information Section -->
                    <h6 class="fw-bold text-primary mb-3">
                        <i class="fas fa-user me-1"></i>Owner Information
                    </h6>
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Owner Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="owner_name" id="itemOwner" required placeholder="Full name">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Student/Staff ID</label>
                            <input type="text" class="form-control" name="student_id" id="itemStudentId" placeholder="e.g., STU-2024-001">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Contact Number <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="contact_number" id="itemContact" required placeholder="e.g., +233 XX XXX XXXX">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Email</label>
                            <input type="email" class="form-control" name="email" id="itemEmail" placeholder="your@email.com">
                        </div>
                    </div>

                    <!-- Image Upload Section -->
                    <h6 class="fw-bold text-primary mb-3">
                        <i class="fas fa-camera me-1"></i>Image Upload
                    </h6>
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label fw-semibold">Upload Image</label>
                            <input type="file" class="form-control image-upload" name="image" accept=".jpg,.jpeg,.png,.webp">
                            <small class="text-muted">Max 5MB. Accepted formats: JPG, PNG, WEBP</small>
                            <div class="image-upload-wrapper mt-2">
                                <img class="image-preview rounded" style="max-width:200px; display:none;">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i>Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i>Save Item
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
</main>

<script>
function resetForm() {
    document.getElementById('formAction').value = 'create';
    document.getElementById('itemId').value = '';
    document.getElementById('modalTitle').textContent = 'Report Lost Item';
    document.getElementById('itemForm').reset();
    // Hide image preview
    const preview = document.querySelector('.image-preview');
    if (preview) preview.style.display = 'none';
}

function editItem(item) {
    document.getElementById('formAction').value = 'update';
    document.getElementById('itemId').value = item.id;
    document.getElementById('modalTitle').textContent = 'Edit Lost Item';
    document.getElementById('itemName').value = item.item_name || '';
    document.getElementById('itemCategory').value = item.category || '';
    document.getElementById('itemColor').value = item.color || '';
    document.getElementById('itemBrand').value = item.brand || '';
    document.getElementById('itemFeatures').value = item.unique_features || '';
    document.getElementById('itemLocation').value = item.location_lost || '';
    document.getElementById('itemDate').value = item.date_lost || '';
    document.getElementById('itemDesc').value = item.description || '';
    document.getElementById('itemOwner').value = item.owner_name || '';
    document.getElementById('itemStudentId').value = item.student_id || '';
    document.getElementById('itemContact').value = item.contact_number || '';
    document.getElementById('itemEmail').value = item.email || '';

    const modal = new bootstrap.Modal(document.getElementById('itemModal'));
    modal.show();
}

function applyFilters() {
    const category = document.getElementById('filterCategory').value.toLowerCase();
    const status = document.getElementById('filterStatus').value.toLowerCase();
    const date = document.getElementById('filterDate').value;
    const search = document.getElementById('filterSearch').value.toLowerCase();

    document.querySelectorAll('#lostItemsTable tbody tr').forEach(function(row) {
        const cells = row.cells;
        const cat = cells[3] ? cells[3].textContent.toLowerCase() : '';
        const stat = cells[10] ? cells[10].textContent.toLowerCase() : '';
        const rowDate = cells[7] ? cells[7].textContent : '';
        const rowText = row.textContent.toLowerCase();

        var show = true;
        if (category && cat.indexOf(category) === -1) show = false;
        if (status && stat.indexOf(status) === -1) show = false;
        if (date && rowDate.indexOf(date) === -1) show = false;
        if (search && rowText.indexOf(search) === -1) show = false;

        row.style.display = show ? '' : 'none';
    });
}
</script>

<?php include '../includes/footer.php'; ?>