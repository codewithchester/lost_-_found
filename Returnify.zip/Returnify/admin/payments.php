<?php
require_once '../config/init.php';
requireLogin();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $txnId = 'TXN-' . date('YmdHis') . '-' . rand(100, 999);
        $stmt = $db->prepare("
            INSERT INTO payments (transaction_id, recipient, amount, payment_method, payment_date, status, notes)
            VALUES (:txn, :rec, :amt, :method, :date, :status, :notes)
        ");
        $stmt->execute([
            ':txn' => $txnId, ':rec' => sanitize($_POST['recipient']),
            ':amt' => (float)$_POST['amount'], ':method' => $_POST['payment_method'],
            ':date' => $_POST['payment_date'], ':status' => $_POST['status'] ?? 'pending',
            ':notes' => sanitize($_POST['notes'] ?? '')
        ]);
        setFlash('success', 'Payment recorded!');
        header('Location: payments.php');
        exit;
    }

    if ($action === 'update_status') {
        $stmt = $db->prepare("UPDATE payments SET status = :status WHERE id = :id");
        $stmt->execute([':status' => $_POST['status'], ':id' => (int)$_POST['id']]);
        setFlash('success', 'Payment status updated.');
        header('Location: payments.php');
        exit;
    }
}

$payments = $db->query("SELECT * FROM payments ORDER BY created_at DESC")->fetchAll();
$totalRevenue = $db->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='completed'")->fetchColumn();
$pendingPayments = $db->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='pending'")->fetchColumn();

$pageTitle = 'Payments';
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<main class="main-content" id="mainContent">
<?php include '../includes/navbar.php'; ?>

<div class="container-fluid p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1"><i class="fas fa-money-bill-wave text-success me-2"></i>Payments</h2>
            <p class="text-muted mb-0">Track all financial transactions</p>
        </div>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#paymentModal">
            <i class="fas fa-plus me-1"></i>Record Payment
        </button>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="glass-card p-4 text-center">
                <h3 class="fw-bold text-success">$<?= number_format($totalRevenue, 2) ?></h3>
                <small class="text-muted">Total Revenue</small>
            </div>
        </div>
        <div class="col-md-4">
            <div class="glass-card p-4 text-center">
                <h3 class="fw-bold text-warning">$<?= number_format($pendingPayments, 2) ?></h3>
                <small class="text-muted">Pending</small>
            </div>
        </div>
        <div class="col-md-4">
            <div class="glass-card p-4 text-center">
                <h3 class="fw-bold"><?= count($payments) ?></h3>
                <small class="text-muted">Total Transactions</small>
            </div>
        </div>
    </div>

    <div class="glass-card p-3">
        <table class="table table-glass datatable">
            <thead>
                <tr><th>Transaction ID</th><th>Recipient</th><th>Amount</th><th>Method</th><th>Date</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php foreach ($payments as $p): ?>
                <tr>
                    <td><strong><?= $p['transaction_id'] ?></strong></td>
                    <td><?= htmlspecialchars($p['recipient']) ?></td>
                    <td>$<?= number_format($p['amount'], 2) ?></td>
                    <td><?= ucfirst(str_replace('_', ' ', $p['payment_method'])) ?></td>
                    <td><?= $p['payment_date'] ?></td>
                    <td><span class="badge bg-<?= $p['status'] === 'completed' ? 'success' : ($p['status'] === 'pending' ? 'warning' : 'danger') ?>"><?= ucfirst($p['status']) ?></span></td>
                    <td>
                        <?php if ($p['status'] === 'pending'): ?>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="action" value="update_status">
                            <input type="hidden" name="id" value="<?= $p['id'] ?>">
                            <input type="hidden" name="status" value="completed">
                            <button class="btn btn-sm btn-success">Complete</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Payment Modal -->
<div class="modal fade" id="paymentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content glass-card">
            <div class="modal-header"><h5>Record Payment</h5></div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="create">
                    <div class="mb-3"><label>Recipient *</label><input type="text" class="form-control" name="recipient" required></div>
                    <div class="mb-3"><label>Amount *</label><input type="number" step="0.01" class="form-control" name="amount" required></div>
                    <div class="mb-3"><label>Method</label>
                        <select class="form-select" name="payment_method">
                            <option value="cash">Cash</option>
                            <option value="mobile_money">Mobile Money</option>
                            <option value="bank_transfer">Bank Transfer</option>
                        </select>
                    </div>
                    <div class="mb-3"><label>Date *</label><input type="date" class="form-control" name="payment_date" required></div>
                    <div class="mb-3"><label>Status</label>
                        <select class="form-select" name="status">
                            <option value="pending">Pending</option><option value="completed">Completed</option>
                        </select>
                    </div>
                    <div class="mb-3"><label>Notes</label><textarea class="form-control" name="notes" rows="2"></textarea></div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Record Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>
</main>
<?php include '../includes/footer.php'; ?>