<?php
require_once '../config/init.php';
requireLogin();

$notif = new Notification();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_all'])) {
    $notif->markAllAsRead();
    setFlash('success', 'All notifications marked as read.');
    header('Location: notifications.php');
    exit;
}

$notifications = $notif->getAll(100);
$unreadCount = $notif->getUnreadCount();

$pageTitle = 'Notifications';
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<main class="main-content" id="mainContent">
<?php include '../includes/navbar.php'; ?>

<div class="container-fluid p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1"><i class="fas fa-bell text-info me-2"></i>Notifications</h2>
            <p class="text-muted"><?= $unreadCount ?> unread notifications</p>
        </div>
        <?php if ($unreadCount > 0): ?>
        <form method="POST">
            <input type="hidden" name="mark_all" value="1">
            <button class="btn btn-outline-primary"><i class="fas fa-check-double me-1"></i>Mark All Read</button>
        </form>
        <?php endif; ?>
    </div>

    <div class="glass-card p-3">
        <?php foreach ($notifications as $n): ?>
        <div class="d-flex align-items-center p-3 border-bottom <?= !$n['is_read'] ? 'bg-primary bg-opacity-10 rounded' : '' ?>">
            <i class="fas <?= !$n['is_read'] ? 'fa-circle text-primary' : 'fa-circle text-muted' ?> me-3" style="font-size:8px;"></i>
            <div class="flex-grow-1">
                <strong><?= htmlspecialchars($n['title']) ?></strong>
                <p class="mb-0 small text-muted"><?= htmlspecialchars($n['message'] ?? '') ?></p>
            </div>
            <small class="text-muted"><?= date('M d, H:i', strtotime($n['created_at'])) ?></small>
        </div>
        <?php endforeach; ?>
    </div>
</div>
</main>
<?php include '../includes/footer.php'; ?>