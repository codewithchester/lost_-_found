<?php
require_once '../config/init.php';
requireLogin();

$db = getDB();
$engine = new MatchEngine();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $matchId = (int)($_POST['match_id'] ?? 0);

    if ($action === 'approve') {
        $engine->approveMatch($matchId, $_SESSION['admin_id']);
        $notif = new Notification();
        $notif->create('match_found', 'Match Approved', "Match #{$matchId} has been approved.");
        setFlash('success', 'Match approved! Items linked successfully.');
    } elseif ($action === 'reject') {
        $engine->rejectMatch($matchId, $_SESSION['admin_id']);
        setFlash('info', 'Match rejected.');
    } elseif ($action === 'run_matching') {
        $total = $engine->runFullMatching();
        setFlash('success', "Matching engine ran successfully. {$total} new matches found!");
    }

    header('Location: matches.php');
    exit;
}

$matches = $engine->getAllMatches();
$stats = $engine->getMatchStats();

$pageTitle = 'Matches';
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<main class="main-content" id="mainContent">
<?php include '../includes/navbar.php'; ?>

<div class="container-fluid p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1"><i class="fas fa-magic text-info me-2"></i>Smart Matches</h2>
            <p class="text-muted mb-0">AI-powered matching between lost and found items</p>
        </div>
        <form method="POST" style="display:inline;">
            <input type="hidden" name="action" value="run_matching">
            <button class="btn btn-info"><i class="fas fa-play me-1"></i>Run Matching Engine</button>
        </form>
    </div>

    <!-- Match Stats -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="glass-card p-3 text-center">
                <h5 class="fw-bold"><?= $stats['total'] ?></h5><small class="text-muted">Total Matches</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="glass-card p-3 text-center">
                <h5 class="fw-bold text-success"><?= $stats['approved'] ?></h5><small class="text-muted">Approved</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="glass-card p-3 text-center">
                <h5 class="fw-bold text-warning"><?= $stats['pending'] ?></h5><small class="text-muted">Pending</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="glass-card p-3 text-center">
                <h5 class="fw-bold"><?= $stats['avg_score'] ?>%</h5><small class="text-muted">Avg Score</small>
            </div>
        </div>
    </div>

    <!-- Matches Table -->
    <div class="glass-card p-3">
        <div class="table-responsive">
            <table class="table table-glass datatable">
                <thead>
                    <tr>
                        <th>Match ID</th><th>Lost Item</th><th>Found Item</th>
                        <th>Match Score</th><th>Confidence</th>
                        <th>Status</th><th>Date</th><th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($matches as $match): ?>
                    <tr>
                        <td>#<?= $match['id'] ?></td>
                        <td>
                            <strong><?= htmlspecialchars($match['lost_item_name']) ?></strong><br>
                            <small class="text-muted"><?= htmlspecialchars($match['lost_category']) ?> | <?= htmlspecialchars($match['location_lost']) ?></small>
                        </td>
                        <td>
                            <strong><?= htmlspecialchars($match['found_item_name']) ?></strong><br>
                            <small class="text-muted"><?= htmlspecialchars($match['found_category']) ?> | <?= htmlspecialchars($match['location_found']) ?></small>
                        </td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="match-score-bar flex-grow-1" style="width:80px;">
                                    <div class="match-score-fill" style="width:<?= $match['match_score'] ?>%;
                                        background:<?= $match['match_score'] >= 80 ? '#10B981' : ($match['match_score'] >= 60 ? '#F59E0B' : '#EF4444') ?>;">
                                    </div>
                                </div>
                                <strong><?= $match['match_score'] ?>%</strong>
                            </div>
                        </td>
                        <td>
                            <span class="badge badge-status bg-<?= $match['confidence_level'] === 'very_high' ? 'success' : ($match['confidence_level'] === 'high' ? 'info' : ($match['confidence_level'] === 'medium' ? 'warning' : 'danger')) ?>">
                                <?= ucfirst(str_replace('_', ' ', $match['confidence_level'])) ?>
                            </span>
                        </td>
                        <td>
                            <span class="badge badge-status bg-<?= $match['status'] === 'approved' ? 'success' : ($match['status'] === 'pending' ? 'warning' : 'danger') ?>">
                                <?= ucfirst($match['status']) ?>
                            </span>
                        </td>
                        <td><?= date('M d, Y', strtotime($match['matched_at'])) ?></td>
                        <td>
                            <?php if ($match['status'] === 'pending'): ?>
                            <div class="btn-group">
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="approve">
                                    <input type="hidden" name="match_id" value="<?= $match['id'] ?>">
                                    <button class="btn btn-sm btn-success" title="Approve Match"><i class="fas fa-check"></i></button>
                                </form>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="reject">
                                    <input type="hidden" name="match_id" value="<?= $match['id'] ?>">
                                    <button class="btn btn-sm btn-danger" title="Reject Match"><i class="fas fa-times"></i></button>
                                </form>
                            </div>
                            <?php endif; ?>
                            <button class="btn btn-sm btn-outline-info" data-bs-toggle="modal" data-bs-target="#matchDetail<?= $match['id'] ?>">
                                <i class="fas fa-eye"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</main>

<?php include '../includes/footer.php'; ?>