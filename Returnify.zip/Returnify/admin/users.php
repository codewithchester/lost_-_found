<?php
require_once '../config/init.php';
requireLogin();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'create') {
    $stmt = $db->prepare("INSERT INTO admins (fullname, username, email, password, role) VALUES (:name, :user, :email, :pass, :role)");
    $stmt->execute([
        ':name' => sanitize($_POST['fullname']),
        ':user' => sanitize($_POST['username']),
        ':email' => sanitize($_POST['email']),
        ':pass' => password_hash($_POST['password'], PASSWORD_BCRYPT, ['cost' => 12]),
        ':role' => $_POST['role']
    ]);
    setFlash('success', 'Admin user created!');
    header('Location: users.php');
    exit;
}

$admins = $db->query("SELECT id, fullname, username, email, role, last_login, status, created_at FROM admins")->fetchAll();
$pageTitle = 'Users';
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<main class="main-content" id="mainContent">
<?php include '../includes/navbar.php'; ?>

<div class="container-fluid p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold"><i class="fas fa-users text-primary me-2"></i>Admin Users</h2>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#userModal"><i class="fas fa-plus me-1"></i>Add Admin</button>
    </div>

    <div class="glass-card p-3">
        <table class="table table-glass datatable">
            <thead>
                <tr><th>ID</th><th>Name</th><th>Username</th><th>Email</th><th>Role</th><th>Last Login</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php foreach ($admins as $a): ?>
                <tr>
                    <td>#<?= $a['id'] ?></td>
                    <td><?= htmlspecialchars($a['fullname']) ?></td>
                    <td><?= htmlspecialchars($a['username']) ?></td>
                    <td><?= htmlspecialchars($a['email']) ?></td>
                    <td><span class="badge bg-info"><?= ucfirst($a['role']) ?></span></td>
                    <td><?= $a['last_login'] ? date('M d, H:i', strtotime($a['last_login'])) : 'Never' ?></td>
                    <td><span class="badge bg-<?= $a['status'] ? 'success' : 'danger' ?>"><?= $a['status'] ? 'Active' : 'Inactive' ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="userModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content glass-card">
            <div class="modal-header"><h5>Add Admin User</h5></div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="create">
                    <div class="mb-3"><label>Full Name *</label><input type="text" class="form-control" name="fullname" required></div>
                    <div class="mb-3"><label>Username *</label><input type="text" class="form-control" name="username" required></div>
                    <div class="mb-3"><label>Email *</label><input type="email" class="form-control" name="email" required></div>
                    <div class="mb-3"><label>Password *</label><input type="password" class="form-control" name="password" required minlength="8"></div>
                    <div class="mb-3"><label>Role</label>
                        <select class="form-select" name="role">
                            <option value="admin">Admin</option><option value="moderator">Moderator</option><option value="super_admin">Super Admin</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create User</button>
                </div>
            </form>
        </div>
    </div>
</div>
</main>
<?php include '../includes/footer.php'; ?>