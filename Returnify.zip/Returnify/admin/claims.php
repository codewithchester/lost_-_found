<?php
require_once '../config/init.php';
requireLogin();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $claimId = (int)($_POST['claim_id'] ?? 0);

    if ($action === 'approve') {
        $stmt = $db->prepare("UPDATE claims SET status = 'approved', reviewed_by = :admin, reviewed_at = NOW() WHERE id = :id");
        $stmt->execute([':admin' => $_SESSION['admin_id'], ':id' => $claimId]);
        $notif = new Notification();
        $notif->create('claim_approved', 'Claim Approved', "Claim #{$claimId} has been approved.");
        setFlash('success', 'Claim approved!');
    } elseif ($action === 'reject') {
        $stmt = $db->prepare("UPDATE claims SET status = 'rejected', reviewed_by = :admin, reviewed_at = NOW() WHERE id = :id");
        $stmt->execute([':admin' => $_SESSION['admin_id'], ':id' => $claimId]);
        $notif = new Notification();
        $notif->create('claim_rejected', 'Claim Rejected', "Claim #{$claimId} has been rejected.");
        setFlash('info', 'Claim rejected.');
    } elseif ($action === 'release') {
        $stmt = $db->prepare("UPDATE claims SET status = 'released', release_date = NOW() WHERE id = :id");
        $stmt->execute([':id' => $claimId]);
        // Update lost item status
        $claim = $db->prepare("SELECT lost_item_id FROM claims WHERE id = :id");
        $claim->execute([':id' => $claimId]);
        $lostId = $claim->fetchColumn();
        if ($lostId) {
            $db->prepare("UPDATE lost_items SET status = 'resolved' WHERE id = :id")->execute([':id' => $lostId]);
        }
        setFlash('success', 'Item released to owner!');
    } elseif ($action === 'create') {
        $claimIdStr = 'CLM-' . date('Ymd') . '-' . rand(1000, 9999);
        $stmt = $db->prepare("
            INSERT INTO claims (claim_id, lost_item_id, match_id, claimed_by, student_id, contact_number, email, ownership_evidence, additional_notes)
            VALUES (:cid, :lid, :mid, :name, :sid, :contact, :email, :evidence, :notes)
        ");
        $stmt->execute([
            ':cid' => $claimIdStr, ':lid' => (int)$_POST['lost_item_id'],
            ':mid' => $_POST['match_id'] ? (int)$_POST['match_id'] : null,
            ':name' => sanitize($_POST['claimed_by']), ':sid' => sanitize($_POST['student_id'] ?? ''),
            ':contact' => sanitize($_POST['contact_number']), ':email' => sanitize($_POST['email'] ?? ''),
            ':evidence' => sanitize($_POST['ownership_evidence'] ?? ''),
            ':notes' => sanitize($_POST['additional_notes'] ?? '')
        ]);
        $notif = new Notification();
        $notif->create('claim_submitted', 'New Claim Submitted', "{$claimIdStr} submitted for review.");
        setFlash('success', 'Claim submitted successfully!');
    }

    header('Location: claims.php');
    exit;
}

$claims = $db->query("
    SELECT c.*, li.item_name AS lost_item_name, li.category AS lost_category
    FROM claims c
    JOIN lost_items li ON c.lost_item_id = li.id
    ORDER BY c.created_at DESC
")->fetchAll();

$pageTitle = 'Claims';
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<main class="main-content" id="mainContent">
<?php include '../includes/navbar.php'; ?>

<div class="container-fluid p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1"><i class="fas fa-clipboard-check text-warning me-2"></i>Claim Verification</h2>
            <p class="text-muted mb-0">Review and verify ownership claims</p>
        </div>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#claimModal">
            <i class="fas fa-plus me-1"></i>New Claim
        </button>
    </div>

    <div class="glass-card p-3">
        <div class="table-responsive">
            <table class="table table-glass datatable">
                <thead>
                    <tr>
                        <th>Claim ID</th><th>Lost Item</th><th>Claimed By</th>
                        <th>Student ID</th><th>Contact</th><th>Status</th>
                        <th>Date</th><th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($claims as $claim): ?>
                    <tr>
                        <td><strong><?= $claim['claim_id'] ?></strong></td>
                        <td><?= htmlspecialchars($claim['lost_item_name']) ?></td>
                        <td><?= htmlspecialchars($claim['claimed_by']) ?></td>
                        <td><?= htmlspecialchars($claim['student_id'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($claim['contact_number']) ?></td>
                        <td>
                            <?php
                            $sClass = ['pending'=>'warning','under_review'=>'info','approved'=>'primary','rejected'=>'danger','released'=>'success'];
                            ?>
                            <span class="badge badge-status bg-<?= $sClass[$claim['status']] ?? 'secondary' ?>">
                                <?= ucfirst(str_replace('_', ' ', $claim['status'])) ?>
                            </span>
                        </td>
                        <td><?= date('M d, Y', strtotime($claim['created_at'])) ?></td>
                        <td>
                            <div class="btn-group">
                                <?php if ($claim['status'] === 'pending' || $claim['status'] === 'under_review'): ?>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="approve">
                                    <input type="hidden" name="claim_id" value="<?= $claim['id'] ?>">
                                    <button class="btn btn-sm btn-success" title="Approve"><i class="fas fa-check"></i></button>
                                </form>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="reject">
                                    <input type="hidden" name="claim_id" value="<?= $claim['id'] ?>">
                                    <button class="btn btn-sm btn-danger" title="Reject"><i class="fas fa-times"></i></button>
                                </form>
                                <?php endif; ?>
                                <?php if ($claim['status'] === 'approved'): ?>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="release">
                                    <input type="hidden" name="claim_id" value="<?= $claim['id'] ?>">
                                    <button class="btn btn-sm btn-success" title="Release Item"><i class="fas fa-box-open"></i> Release</button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Claim Modal -->
<div class="modal fade" id="claimModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content glass-card">
            <div class="modal-header">
                <h5 class="modal-title">New Claim</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="create">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Lost Item *</label>
                            <select class="form-select" name="lost_item_id" required>
                                <option value="">Select lost item...</option>
                                <?php
                                $lostItems = $db->query("SELECT id, item_name FROM lost_items WHERE status != 'resolved'")->fetchAll();
                                foreach ($lostItems as $li):
                                ?>
                                    <option value="<?= $li['id'] ?>">#<?= $li['id'] ?> - <?= htmlspecialchars($li['item_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Match (optional)</label>
                            <select class="form-select" name="match_id">
                                <option value="">None</option>
                                <?php
                                $approvedMatches = $db->query("SELECT id FROM matches WHERE status = 'approved'")->fetchAll();
                                foreach ($approvedMatches as $m):
                                ?>
                                    <option value="<?= $m['id'] ?>">Match #<?= $m['id'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Claimed By *</label>
                            <input type="text" class="form-control" name="claimed_by" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Student ID</label>
                            <input type="text" class="form-control" name="student_id">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Contact Number *</label>
                            <input type="text" class="form-control" name="contact_number" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" name="email">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Ownership Evidence</label>
                            <textarea class="form-control" name="ownership_evidence" rows="3" placeholder="Describe how you can prove ownership..."></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Additional Notes</label>
                            <textarea class="form-control" name="additional_notes" rows="2"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Submit Claim</button>
                </div>
            </form>
        </div>
    </div>
</div>
</main>

<?php include '../includes/footer.php'; ?>