<?php
require_once '../config/init.php';
requireLogin();

$db = getDB();

// Fetch statistics
$totalLost = $db->query("SELECT COUNT(*) FROM lost_items")->fetchColumn();
$totalFound = $db->query("SELECT COUNT(*) FROM found_items")->fetchColumn();
$totalMatches = $db->query("SELECT COUNT(*) FROM matches")->fetchColumn();
$pendingClaims = $db->query("SELECT COUNT(*) FROM claims WHERE status = 'pending'")->fetchColumn();
$approvedClaims = $db->query("SELECT COUNT(*) FROM claims WHERE status IN ('approved','released')")->fetchColumn();
$unresolvedCases = $db->query("SELECT COUNT(*) FROM lost_items WHERE status NOT IN ('resolved')")->fetchColumn();
$totalRewards = $db->query("SELECT COALESCE(SUM(reward_amount),0) FROM rewards WHERE status = 'paid'")->fetchColumn();
$totalRevenue = $db->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status = 'completed'")->fetchColumn();
$matchSuccessRate = $totalLost > 0 ? round(($totalMatches / $totalLost) * 100, 1) : 0;

// Monthly chart data
$monthlyLost = $db->query("
    SELECT MONTH(created_at) as month, COUNT(*) as count
    FROM lost_items WHERE YEAR(created_at) = YEAR(CURDATE())
    GROUP BY MONTH(created_at) ORDER BY month
")->fetchAll();

$monthlyFound = $db->query("
    SELECT MONTH(created_at) as month, COUNT(*) as count
    FROM found_items WHERE YEAR(created_at) = YEAR(CURDATE())
    GROUP BY MONTH(created_at) ORDER BY month
")->fetchAll();

// Recent activities
$recentActivities = $db->query("
    SELECT al.*, a.fullname FROM activity_logs al
    LEFT JOIN admins a ON al.admin_id = a.id
    ORDER BY al.created_at DESC LIMIT 10
")->fetchAll();

// Category distribution
$categoryDist = $db->query("
    SELECT category, COUNT(*) as count FROM lost_items GROUP BY category
")->fetchAll();

// Prepare chart data
$months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
$lostData = array_fill(0, 12, 0);
$foundData = array_fill(0, 12, 0);
foreach ($monthlyLost as $row) { $lostData[$row['month']-1] = (int)$row['count']; }
foreach ($monthlyFound as $row) { $foundData[$row['month']-1] = (int)$row['count']; }

$pageTitle = 'Dashboard';
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<!-- Main Content -->
<main class="main-content" id="mainContent">
    <?php include '../includes/navbar.php'; ?>

    <div class="container-fluid p-4">
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="fw-bold mb-1">Dashboard</h2>
                <p class="text-muted mb-0">Welcome back, <?= htmlspecialchars($_SESSION['admin_name']) ?>!</p>
            </div>
            <div>
                <button class="btn btn-outline-primary me-2" onclick="location.reload()">
                    <i class="fas fa-sync-alt me-1"></i>Refresh
                </button>
                <button class="btn btn-primary" onclick="window.print()">
                    <i class="fas fa-download me-1"></i>Export Summary
                </button>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="row g-3 mb-4">
            <div class="col-xl-3 col-md-6">
                <div class="stat-card glass-card p-3">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-muted mb-1 small">Total Lost Items</p>
                            <h3 class="fw-bold counter" data-target="<?= $totalLost ?>">0</h3>
                            <small class="text-danger"><i class="fas fa-arrow-up me-1"></i>Active cases</small>
                        </div>
                        <div class="stat-icon bg-primary-subtle">
                            <i class="fas fa-box-open text-primary"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="stat-card glass-card p-3">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-muted mb-1 small">Total Found Items</p>
                            <h3 class="fw-bold counter" data-target="<?= $totalFound ?>">0</h3>
                            <small class="text-success"><i class="fas fa-check-circle me-1"></i>Recovered</small>
                        </div>
                        <div class="stat-icon bg-success-subtle">
                            <i class="fas fa-hand-holding-heart text-success"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="stat-card glass-card p-3">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-muted mb-1 small">Match Success Rate</p>
                            <h3 class="fw-bold counter" data-target="<?= $matchSuccessRate ?>" data-suffix="%">0</h3>
                            <small class="text-info"><i class="fas fa-percentage me-1"></i><?= $totalMatches ?> matches</small>
                        </div>
                        <div class="stat-icon bg-info-subtle">
                            <i class="fas fa-magic text-info"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="stat-card glass-card p-3">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-muted mb-1 small">Pending Claims</p>
                            <h3 class="fw-bold counter" data-target="<?= $pendingClaims ?>">0</h3>
                            <small class="text-warning"><i class="fas fa-clock me-1"></i>Awaiting review</small>
                        </div>
                        <div class="stat-icon bg-warning-subtle">
                            <i class="fas fa-clipboard-list text-warning"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Second Row Stats -->
        <div class="row g-3 mb-4">
            <div class="col-xl-2 col-md-4 col-6">
                <div class="stat-card glass-card p-3 text-center">
                    <i class="fas fa-check-double text-success mb-2" style="font-size:24px;"></i>
                    <h5 class="fw-bold counter" data-target="<?= $approvedClaims ?>">0</h5>
                    <small class="text-muted">Approved Claims</small>
                </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6">
                <div class="stat-card glass-card p-3 text-center">
                    <i class="fas fa-exclamation-triangle text-danger mb-2" style="font-size:24px;"></i>
                    <h5 class="fw-bold counter" data-target="<?= $unresolvedCases ?>">0</h5>
                    <small class="text-muted">Unresolved</small>
                </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6">
                <div class="stat-card glass-card p-3 text-center">
                    <i class="fas fa-trophy text-warning mb-2" style="font-size:24px;"></i>
                    <h5 class="fw-bold">$<?= number_format($totalRewards, 2) ?></h5>
                    <small class="text-muted">Rewards Paid</small>
                </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6">
                <div class="stat-card glass-card p-3 text-center">
                    <i class="fas fa-dollar-sign text-success mb-2" style="font-size:24px;"></i>
                    <h5 class="fw-bold">$<?= number_format($totalRevenue, 2) ?></h5>
                    <small class="text-muted">Revenue</small>
                </div>
            </div>
        </div>

        <!-- Charts Row -->
        <div class="row g-3 mb-4">
            <div class="col-lg-8">
                <div class="glass-card p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-chart-line me-2"></i>Monthly Trends</h5>
                    <canvas id="trendsChart" height="300"></canvas>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="glass-card p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-chart-pie me-2"></i>Lost Items by Category</h5>
                    <canvas id="categoryChart" height="300"></canvas>
                </div>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="row g-3">
            <div class="col-lg-6">
                <div class="glass-card p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-history me-2"></i>Recent Activity</h5>
                    <div class="activity-list">
                        <?php foreach ($recentActivities as $activity): ?>
                            <div class="activity-item d-flex align-items-center py-2 border-bottom">
                                <div class="activity-icon me-3">
                                    <?php
                                    $iconMap = [
                                        'login_success' => 'fa-sign-in-alt text-success',
                                        'logout' => 'fa-sign-out-alt text-muted',
                                        'failed_login' => 'fa-exclamation-circle text-danger',
                                        'create' => 'fa-plus-circle text-primary',
                                        'update' => 'fa-edit text-warning',
                                        'delete' => 'fa-trash text-danger',
                                        'match' => 'fa-magic text-info'
                                    ];
                                    $icon = $iconMap[$activity['action']] ?? 'fa-circle text-muted';
                                    ?>
                                    <i class="fas <?= $icon ?>"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <small class="d-block"><?= htmlspecialchars($activity['details'] ?: $activity['action']) ?></small>
                                    <small class="text-muted"><?= date('M d, H:i', strtotime($activity['created_at'])) ?></small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="glass-card p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-bell me-2"></i>Recent Notifications</h5>
                    <div class="notification-list">
                        <?php
                        $recentNotifs = $db->query("SELECT * FROM notifications ORDER BY created_at DESC LIMIT 8")->fetchAll();
                        foreach ($recentNotifs as $notif):
                        ?>
                            <div class="d-flex align-items-center py-2 border-bottom <?= !$notif['is_read'] ? 'bg-light rounded px-2' : '' ?>">
                                <i class="fas fa-bell <?= !$notif['is_read'] ? 'text-primary' : 'text-muted' ?> me-3"></i>
                                <div>
                                    <small class="d-block fw-semibold"><?= htmlspecialchars($notif['title']) ?></small>
                                    <small class="text-muted"><?= date('M d, H:i', strtotime($notif['created_at'])) ?></small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
// Animated counters
function animateCounters() {
    document.querySelectorAll('.counter').forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'));
        const suffix = counter.getAttribute('data-suffix') || '';
        const duration = 1500;
        const start = performance.now();

        function update(now) {
            const elapsed = now - start;
            const progress = Math.min(elapsed / duration, 1);
            const easeOut = 1 - Math.pow(1 - progress, 3);
            const current = Math.round(target * easeOut);
            counter.textContent = suffix ? current + suffix : current;
            if (progress < 1) requestAnimationFrame(update);
        }
        requestAnimationFrame(update);
    });
}

// Trends Chart
const trendsCtx = document.getElementById('trendsChart').getContext('2d');
new Chart(trendsCtx, {
    type: 'line',
    data: {
        labels: <?= json_encode($months) ?>,
        datasets: [{
            label: 'Lost Items',
            data: <?= json_encode($lostData) ?>,
            borderColor: '#EF4444',
            backgroundColor: 'rgba(239,68,68,0.1)',
            fill: true,
            tension: 0.4,
            borderWidth: 2,
            pointRadius: 4
        }, {
            label: 'Found Items',
            data: <?= json_encode($foundData) ?>,
            borderColor: '#10B981',
            backgroundColor: 'rgba(16,185,129,0.1)',
            fill: true,
            tension: 0.4,
            borderWidth: 2,
            pointRadius: 4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: 'top' } },
        scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
    }
});

// Category Chart
const catCtx = document.getElementById('categoryChart').getContext('2d');
const catData = <?= json_encode($categoryDist) ?>;
new Chart(catCtx, {
    type: 'doughnut',
    data: {
        labels: catData.map(c => c.category),
        datasets: [{
            data: catData.map(c => c.count),
            backgroundColor: ['#2563EB','#0EA5E9','#10B981','#F59E0B','#EF4444','#8B5CF6','#EC4899','#6366F1']
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom' } }
    }
});

// Init
document.addEventListener('DOMContentLoaded', animateCounters);
</script>

<?php include '../includes/footer.php'; ?>