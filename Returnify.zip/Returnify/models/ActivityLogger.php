<?php
class ActivityLogger {
    private $db;

    public function __construct() {
        $this->db = getDB();
    }

    public function log($action, $module = 'system', $referenceId = null, $details = '') {
        $adminId = $_SESSION['admin_id'] ?? null;
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

        $stmt = $this->db->prepare("
            INSERT INTO activity_logs (admin_id, action, module, reference_id, details, ip_address, user_agent)
            VALUES (:admin_id, :action, :module, :ref_id, :details, :ip, :user_agent)
        ");
        return $stmt->execute([
            ':admin_id' => $adminId,
            ':action' => $action,
            ':module' => $module,
            ':ref_id' => $referenceId,
            ':details' => $details,
            ':ip' => $ip,
            ':user_agent' => $userAgent
        ]);
    }
}