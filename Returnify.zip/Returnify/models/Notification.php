<?php
class Notification {
    private $db;

    public function __construct() {
        $this->db = getDB();
    }

    public function create($type, $title, $message, $refId = null, $refType = null) {
        $stmt = $this->db->prepare("
            INSERT INTO notifications (type, title, message, reference_id, reference_type)
            VALUES (:type, :title, :message, :ref_id, :ref_type)
        ");
        return $stmt->execute([
            ':type' => $type,
            ':title' => $title,
            ':message' => $message,
            ':ref_id' => $refId,
            ':ref_type' => $refType
        ]);
    }

    public function getAll($limit = 50) {
        $stmt = $this->db->prepare("SELECT * FROM notifications ORDER BY created_at DESC LIMIT :limit");
        $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getUnreadCount() {
        $stmt = $this->db->query("SELECT COUNT(*) FROM notifications WHERE is_read = 0");
        return $stmt->fetchColumn();
    }

    public function markAsRead($id) {
        $stmt = $this->db->prepare("UPDATE notifications SET is_read = 1 WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    public function markAllAsRead() {
        return $this->db->exec("UPDATE notifications SET is_read = 1 WHERE is_read = 0");
    }

    public function getRecent($limit = 5) {
        $stmt = $this->db->prepare("SELECT * FROM notifications ORDER BY created_at DESC LIMIT :limit");
        $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM notifications WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }
}