<?php
class MatchEngine {
    private $db;
    private $threshold = 60;

    public function __construct() {
        $this->db = getDB();
        $this->loadThreshold();
    }

    private function loadThreshold() {
        $stmt = $this->db->query("SELECT setting_value FROM settings WHERE setting_key = 'match_threshold'");
        $val = $stmt->fetchColumn();
        if ($val) $this->threshold = (int)$val;
    }

    /**
     * Calculate Levenshtein similarity between two strings
     */
    private function stringSimilarity($str1, $str2) {
        $str1 = strtolower(trim($str1));
        $str2 = strtolower(trim($str2));
        if (empty($str1) || empty($str2)) return 0;
        $maxLen = max(strlen($str1), strlen($str2));
        if ($maxLen == 0) return 100;
        $lev = levenshtein($str1, $str2);
        return (1 - ($lev / $maxLen)) * 100;
    }

    /**
     * Extract keywords from description
     */
    private function extractKeywords($text) {
        $text = strtolower($text);
        $stopWords = ['the', 'a', 'an', 'is', 'was', 'were', 'it', 'and', 'or', 'in', 'on', 'at', 'to', 'for', 'of', 'with'];
        $words = preg_split('/\s+/', preg_replace('/[^a-zA-Z0-9\s]/', '', $text));
        $words = array_diff($words, $stopWords);
        return array_filter($words, function($w) { return strlen($w) > 2; });
    }

    /**
     * Calculate keyword overlap score
     */
    private function keywordOverlap($desc1, $desc2) {
        $kw1 = $this->extractKeywords($desc1);
        $kw2 = $this->extractKeywords($desc2);
        if (empty($kw1) || empty($kw2)) return 0;
        $intersection = array_intersect($kw1, $kw2);
        $union = array_unique(array_merge($kw1, $kw2));
        return (count($intersection) / count($union)) * 100;
    }

    /**
     * Calculate date proximity score
     */
    private function dateProximity($dateLost, $dateFound) {
        if (empty($dateLost) || empty($dateFound)) return 50;
        $lost = new DateTime($dateLost);
        $found = new DateTime($dateFound);
        $diff = abs($found->diff($lost)->days);
        if ($diff <= 1) return 100;
        if ($diff <= 3) return 90;
        if ($diff <= 7) return 75;
        if ($diff <= 14) return 60;
        if ($diff <= 30) return 40;
        return 20;
    }

    /**
     * Location similarity (simple string match)
     */
    private function locationSimilarity($loc1, $loc2) {
        return $this->stringSimilarity($loc1, $loc2);
    }

    /**
     * Main matching function - compares lost item with all found items
     */
    public function findMatches($lostItemId) {
        $lost = $this->getLostItem($lostItemId);
        if (!$lost) return [];

        $foundItems = $this->getAllUnmatchedFoundItems();
        $matches = [];

        foreach ($foundItems as $found) {
            $score = $this->calculateMatchScore($lost, $found);
            if ($score['total'] >= $this->threshold) {
                $matches[] = [
                    'lost_item_id' => $lost['id'],
                    'found_item_id' => $found['id'],
                    'score' => $score['total'],
                    'details' => $score,
                    'confidence' => $this->getConfidenceLevel($score['total'])
                ];
            }
        }

        // Store matches in database
        $this->storeMatches($matches);

        return $matches;
    }

    /**
     * Find matches for a found item
     */
    public function findMatchesForFound($foundItemId) {
        $found = $this->getFoundItem($foundItemId);
        if (!$found) return [];

        $lostItems = $this->getAllUnmatchedLostItems();
        $matches = [];

        foreach ($lostItems as $lost) {
            $score = $this->calculateMatchScore($lost, $found);
            if ($score['total'] >= $this->threshold) {
                $matches[] = [
                    'lost_item_id' => $lost['id'],
                    'found_item_id' => $found['id'],
                    'score' => $score['total'],
                    'details' => $score,
                    'confidence' => $this->getConfidenceLevel($score['total'])
                ];
            }
        }

        $this->storeMatches($matches);
        return $matches;
    }

    /**
     * Run matching for all unmatched items
     */
    public function runFullMatching() {
        $lostItems = $this->getAllUnmatchedLostItems();
        $totalMatches = 0;

        foreach ($lostItems as $lost) {
            $matches = $this->findMatches($lost['id']);
            $totalMatches += count($matches);
        }

        return $totalMatches;
    }

    /**
     * Calculate comprehensive match score
     */
    public function calculateMatchScore($lost, $found) {
        $scores = [
            'item_name' => $this->stringSimilarity($lost['item_name'], $found['item_name']),
            'category' => ($lost['category'] === $found['category']) ? 100 : 0,
            'color' => $this->stringSimilarity($lost['color'] ?? '', $found['color'] ?? ''),
            'brand' => $this->stringSimilarity($lost['brand'] ?? '', $found['brand'] ?? ''),
            'location' => $this->locationSimilarity($lost['location_lost'] ?? '', $found['location_found'] ?? ''),
            'description' => $this->keywordOverlap($lost['description'] ?? '', $found['description'] ?? ''),
            'date_proximity' => $this->dateProximity($lost['date_lost'] ?? null, $found['date_found'] ?? null)
        ];

        // Weighted scoring
        $weightedScore =
            ($scores['item_name'] * 0.35) +
            ($scores['category'] * 0.20) +
            ($scores['color'] * 0.10) +
            ($scores['brand'] * 0.10) +
            ($scores['location'] * 0.10) +
            ($scores['description'] * 0.10) +
            ($scores['date_proximity'] * 0.05);

        return [
            'total' => round($weightedScore, 2),
            'breakdown' => $scores
        ];
    }

    private function getConfidenceLevel($score) {
        if ($score >= 90) return 'very_high';
        if ($score >= 75) return 'high';
        if ($score >= 60) return 'medium';
        return 'low';
    }

    private function getLostItem($id) {
        $stmt = $this->db->prepare("SELECT * FROM lost_items WHERE id = :id");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    private function getFoundItem($id) {
        $stmt = $this->db->prepare("SELECT * FROM found_items WHERE id = :id");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    private function getAllUnmatchedFoundItems() {
        return $this->db->query("SELECT * FROM found_items WHERE status IN ('found', 'unclaimed')")->fetchAll();
    }

    private function getAllUnmatchedLostItems() {
        return $this->db->query("SELECT * FROM lost_items WHERE status = 'lost'")->fetchAll();
    }

    private function storeMatches($matches) {
        foreach ($matches as $match) {
            // Check if match already exists
            $stmt = $this->db->prepare("
                SELECT id FROM matches WHERE lost_item_id = :lid AND found_item_id = :fid
            ");
            $stmt->execute([':lid' => $match['lost_item_id'], ':fid' => $match['found_item_id']]);
            if ($stmt->fetch()) continue;

            // Insert new match
            $stmt = $this->db->prepare("
                INSERT INTO matches (lost_item_id, found_item_id, match_score, confidence_level, match_details)
                VALUES (:lid, :fid, :score, :confidence, :details)
            ");
            $stmt->execute([
                ':lid' => $match['lost_item_id'],
                ':fid' => $match['found_item_id'],
                ':score' => $match['score'],
                ':confidence' => $match['confidence'],
                ':details' => json_encode($match['details'])
            ]);

            // Create notification
            $notif = new Notification();
            $notif->create('match_found', 'New Match Found',
                "Match found between Lost Item #{$match['lost_item_id']} and Found Item #{$match['found_item_id']} with {$match['score']}% confidence.",
                $this->db->lastInsertId(), 'match');
        }
    }

    public function getAllMatches() {
        $stmt = $this->db->query("
            SELECT m.*,
                   li.item_name AS lost_item_name, li.category AS lost_category,
                   li.color AS lost_color, li.brand AS lost_brand,
                   li.location_lost, li.date_lost, li.image AS lost_image,
                   fi.item_name AS found_item_name, fi.category AS found_category,
                   fi.color AS found_color, fi.brand AS found_brand,
                   fi.location_found, fi.date_found, fi.image AS found_image
            FROM matches m
            JOIN lost_items li ON m.lost_item_id = li.id
            JOIN found_items fi ON m.found_item_id = fi.id
            ORDER BY m.match_score DESC, m.matched_at DESC
        ");
        return $stmt->fetchAll();
    }

    public function getMatchById($id) {
        $stmt = $this->db->prepare("
            SELECT m.*,
                   li.*, fi.*,
                   li.id AS lost_id, fi.id AS found_id,
                   li.item_name AS lost_item_name, fi.item_name AS found_item_name
            FROM matches m
            JOIN lost_items li ON m.lost_item_id = li.id
            JOIN found_items fi ON m.found_item_id = fi.id
            WHERE m.id = :id
        ");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    public function approveMatch($matchId, $adminId) {
        $stmt = $this->db->prepare("
            UPDATE matches SET status = 'approved', reviewed_by = :admin_id, reviewed_at = NOW()
            WHERE id = :id
        ");
        $result = $stmt->execute([':id' => $matchId, ':admin_id' => $adminId]);

        // Update related items
        $match = $this->getMatchById($matchId);
        if ($match) {
            $this->db->prepare("UPDATE lost_items SET status = 'matched' WHERE id = :id")
                ->execute([':id' => $match['lost_item_id']]);
            $this->db->prepare("UPDATE found_items SET status = 'matched' WHERE id = :id")
                ->execute([':id' => $match['found_item_id']]);
        }

        return $result;
    }

    public function rejectMatch($matchId, $adminId) {
        $stmt = $this->db->prepare("
            UPDATE matches SET status = 'rejected', reviewed_by = :admin_id, reviewed_at = NOW()
            WHERE id = :id
        ");
        return $stmt->execute([':id' => $matchId, ':admin_id' => $adminId]);
    }

    public function getMatchStats() {
        $total = $this->db->query("SELECT COUNT(*) FROM matches")->fetchColumn();
        $approved = $this->db->query("SELECT COUNT(*) FROM matches WHERE status = 'approved'")->fetchColumn();
        $rejected = $this->db->query("SELECT COUNT(*) FROM matches WHERE status = 'rejected'")->fetchColumn();
        $pending = $this->db->query("SELECT COUNT(*) FROM matches WHERE status = 'pending'")->fetchColumn();
        $avgScore = $this->db->query("SELECT AVG(match_score) FROM matches")->fetchColumn();

        return [
            'total' => $total,
            'approved' => $approved,
            'rejected' => $rejected,
            'pending' => $pending,
            'avg_score' => round($avgScore ?? 0, 2)
        ];
    }
}