<?php
require_once '../config/init.php';
header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$notif = new Notification();
$notif->markAllAsRead();
echo json_encode(['success' => true]);