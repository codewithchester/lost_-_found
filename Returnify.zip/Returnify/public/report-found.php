<?php
require_once __DIR__ . '/../config/init.php';
$db = getDB();

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $itemName = sanitize($_POST['item_name']);
    $category = sanitize($_POST['category']);
    $color = sanitize($_POST['color'] ?? '');
    $brand = sanitize($_POST['brand'] ?? '');
    $locationFound = sanitize($_POST['location_found']);
    $dateFound = sanitize($_POST['date_found']);
    $description = sanitize($_POST['description'] ?? '');
    $finderName = sanitize($_POST['finder_name']);
    $contactNumber = sanitize($_POST['contact_number']);
    $finderRole = sanitize($_POST['finder_role'] ?? 'student');

    $imageName = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../assets/uploads/found/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp']) && $_FILES['image']['size'] <= 5 * 1024 * 1024) {
            $imageName = 'found_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
            move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName);
        }
    }

    if (empty($error)) {
        $stmt = $db->prepare("
            INSERT INTO found_items (item_name, category, color, brand, location_found, date_found, description, finder_name, contact_number, finder_role, image)
            VALUES (:name, :cat, :color, :brand, :loc, :date, :desc, :finder, :contact, :role, :image)
        ");
        $stmt->execute([
            ':name' => $itemName, ':cat' => $category, ':color' => $color,
            ':brand' => $brand, ':loc' => $locationFound, ':date' => $dateFound,
            ':desc' => $description, ':finder' => $finderName,
            ':contact' => $contactNumber, ':role' => $finderRole, ':image' => $imageName
        ]);

        $engine = new MatchEngine();
        $engine->findMatchesForFound($db->lastInsertId());

        $notif = new Notification();
        $notif->create('new_found', 'New Found Item Reported', "{$itemName} found at {$locationFound}");

        $success = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Report Found Item - Returnify</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    
    <style>
        :root { --primary: #2563EB; --purple: #8B5CF6; --success: #10B981; }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            background: #f0f4ff;
            color: #1e293b;
            overflow-x: hidden;
            min-height: 100vh;
            -webkit-font-smoothing: antialiased;
        }

        [data-bs-theme="dark"] body {
            background: #0a0e1a;
            color: #e2e8f0;
        }

        .bg-animation {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            pointer-events: none; z-index: 0; overflow: hidden;
        }
        .bg-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.25;
            animation: blobFloat 20s infinite ease-in-out;
        }
        .bg-blob:nth-child(1) {
            width: 500px; height: 500px;
            background: #10B981;
            top: -100px; left: -100px;
        }
        .bg-blob:nth-child(2) {
            width: 400px; height: 400px;
            background: #0EA5E9;
            bottom: -100px; right: -100px;
            animation-delay: -7s;
        }
        .bg-blob:nth-child(3) {
            width: 300px; height: 300px;
            background: #2563EB;
            top: 50%; left: 50%;
            animation-delay: -14s;
        }

        @keyframes blobFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(80px, -40px) scale(1.1); }
            66% { transform: translate(-40px, 60px) scale(0.9); }
        }

        [data-bs-theme="dark"] .bg-blob { opacity: 0.12; }

        .navbar {
            position: fixed;
            top: 15px;
            left: 50%;
            transform: translateX(-50%);
            width: 92%;
            max-width: 1200px;
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 20px;
            padding: 12px 20px;
            z-index: 1000;
        }

        [data-bs-theme="dark"] .navbar {
            background: rgba(15, 23, 42, 0.75);
            border-color: rgba(255, 255, 255, 0.08);
        }

        .navbar-brand {
            font-size: 1.25rem;
            font-weight: 800;
            background: linear-gradient(135deg, #2563EB, #8B5CF6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-decoration: none;
            white-space: nowrap;
        }

        .navbar-brand i {
            background: linear-gradient(135deg, #2563EB, #0EA5E9);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .nav-link {
            color: #64748b !important;
            font-weight: 500;
            font-size: 0.9rem;
            padding: 10px 16px !important;
            border-radius: 12px;
            transition: all 0.3s ease;
            white-space: nowrap;
        }

        .nav-link:hover, .nav-link.active {
            color: #10B981 !important;
            background: rgba(16, 185, 129, 0.08);
        }

        [data-bs-theme="dark"] .nav-link { color: #94a3b8 !important; }
        [data-bs-theme="dark"] .nav-link:hover { color: #34D399 !important; background: rgba(52, 211, 153, 0.1); }

        .navbar-toggler {
            border: none !important;
            padding: 8px;
            border-radius: 10px;
            background: rgba(16, 185, 129, 0.08);
            box-shadow: none !important;
        }

        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(16, 185, 129, 1)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e") !important;
        }

        @media (max-width: 991px) {
            .navbar-collapse {
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(20px);
                border-radius: 16px;
                padding: 16px;
                margin-top: 12px;
                max-height: 80vh;
                overflow-y: auto;
            }
        }

        .theme-btn {
            width: 40px; height: 40px; min-width: 40px;
            border-radius: 12px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            background: rgba(255, 255, 255, 0.5);
            color: #64748b;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .form-wrapper {
            position: relative;
            z-index: 1;
            padding: 120px 16px 60px;
            max-width: 800px;
            margin: 0 auto;
        }

        .glass-card {
            background: rgba(255, 255, 255, 0.55);
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.5);
            border-radius: 24px;
            padding: 32px 24px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.06);
        }

        [data-bs-theme="dark"] .glass-card {
            background: rgba(30, 41, 59, 0.55);
            border-color: rgba(255, 255, 255, 0.06);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        @media (min-width: 768px) { .glass-card { padding: 40px 36px; } }

        .form-header { text-align: center; margin-bottom: 32px; }
        .form-header .icon-circle {
            width: 72px; height: 72px;
            border-radius: 24px;
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.15), rgba(14, 165, 233, 0.15));
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            font-size: 30px;
            color: #10B981;
        }
        .form-header h2 { font-weight: 800; font-size: clamp(1.5rem, 3vw, 1.8rem); letter-spacing: -0.5px; margin-bottom: 4px; }
        .form-header p { color: #64748b; font-size: 0.9rem; }

        .form-section-title {
            font-weight: 700;
            font-size: 0.95rem;
            color: #10B981;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
            padding-bottom: 12px;
            border-bottom: 1px solid rgba(16, 185, 129, 0.15);
        }

        .form-label { font-weight: 600; font-size: 0.85rem; color: #475569; margin-bottom: 6px; }
        [data-bs-theme="dark"] .form-label { color: #cbd5e1; }
        .form-label .required { color: #10B981; }

        .form-control, .form-select {
            border-radius: 12px;
            border: 1.5px solid rgba(0, 0, 0, 0.1);
            padding: 12px 16px;
            font-size: 0.9rem;
            font-family: 'Inter', sans-serif;
            background: rgba(255, 255, 255, 0.7);
            transition: all 0.3s ease;
        }

        [data-bs-theme="dark"] .form-control,
        [data-bs-theme="dark"] .form-select {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(255, 255, 255, 0.1);
            color: #e2e8f0;
        }

        .form-control:focus, .form-select:focus {
            border-color: #10B981;
            box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.1);
            background: rgba(255, 255, 255, 0.9);
        }

        textarea.form-control { resize: vertical; min-height: 80px; }

        .btn-submit {
            width: 100%;
            padding: 14px 24px;
            border-radius: 14px;
            background: linear-gradient(135deg, #10B981, #0EA5E9);
            color: #fff;
            border: none;
            font-weight: 700;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 35px rgba(16, 185, 129, 0.4);
        }

        .success-card { text-align: center; padding: 40px 20px; }
        .success-icon { font-size: 64px; color: #10B981; animation: scaleIn 0.6s ease; }

        @keyframes scaleIn {
            0% { transform: scale(0); opacity: 0; }
            70% { transform: scale(1.15); }
            100% { transform: scale(1); opacity: 1; }
        }

        .success-card h3 { font-weight: 800; margin: 20px 0 8px; }
        .success-card p { color: #64748b; margin-bottom: 24px; }

        .btn-group-custom { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }

        .btn-outline-glass {
            background: rgba(255, 255, 255, 0.5);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(16, 185, 129, 0.3);
            color: #10B981;
            padding: 12px 24px;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .alert { border-radius: 14px; border: none; font-weight: 500; }

        @media (max-width: 480px) {
            .navbar { width: 95%; top: 8px; padding: 10px 14px; border-radius: 16px; }
            .navbar-brand { font-size: 1.1rem; }
            .form-wrapper { padding: 100px 10px 40px; }
            .glass-card { padding: 24px 16px; border-radius: 20px; }
        }
    </style>
</head>
<body>

    <div class="bg-animation">
        <div class="bg-blob"></div>
        <div class="bg-blob"></div>
        <div class="bg-blob"></div>
    </div>

    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid px-0">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-search-location"></i> Returnify
            </a>
            <div class="d-flex align-items-center gap-2 d-lg-none">
                <button class="theme-btn" onclick="toggleTheme()" aria-label="Toggle theme">
                    <i class="fas fa-moon" id="themeIconMobile"></i>
                </button>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto gap-1">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="found-items.php">Browse Items</a></li>
                    <li class="nav-item"><a class="nav-link" href="report-lost.php">Report Lost</a></li>
                    <li class="nav-item"><a class="nav-link active" href="report-found.php">Report Found</a></li>
                    <li class="nav-item"><a class="nav-link" href="track-claim.php">Track Claim</a></li>
                </ul>
                <div class="d-none d-lg-flex align-items-center gap-2">
                    <button class="theme-btn" onclick="toggleTheme()" aria-label="Toggle theme">
                        <i class="fas fa-moon" id="themeIcon"></i>
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <div class="form-wrapper">
        <?php if ($success): ?>
            <div class="glass-card success-card">
                <i class="fas fa-check-circle success-icon"></i>
                <h3>Thank You!</h3>
                <p>Your found item has been recorded. It will be matched against our lost items database. The owner will be notified if a match is found.</p>
                <div class="btn-group-custom">
                    <a href="index.php" class="btn-submit" style="width:auto;padding:12px 28px;text-decoration:none;">
                        <i class="fas fa-home me-1"></i> Back to Home
                    </a>
                    <a href="report-found.php" class="btn-outline-glass">
                        <i class="fas fa-plus me-1"></i> Report Another
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="glass-card">
                <div class="form-header">
                    <div class="icon-circle">
                        <i class="fas fa-hand-holding-heart"></i>
                    </div>
                    <h2>Report Found Item</h2>
                    <p>Help someone recover their lost item</p>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-danger"><i class="fas fa-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>

                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-4">
                        <h6 class="form-section-title"><i class="fas fa-info-circle"></i> Item Information</h6>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Item Name <span class="required">*</span></label>
                                <input type="text" class="form-control" name="item_name" required placeholder="e.g., iPhone 14 Pro">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Category <span class="required">*</span></label>
                                <select class="form-select" name="category" required>
                                    <option value="">Select category...</option>
                                    <option>Electronics</option><option>Clothing</option><option>Books</option>
                                    <option>ID Cards</option><option>Keys</option><option>Bags</option>
                                    <option>Jewelry</option><option>Water Bottle</option><option>Other</option>
                                </select>
                            </div>
                            <div class="col-sm-4">
                                <label class="form-label">Color</label>
                                <input type="text" class="form-control" name="color" placeholder="e.g., Black">
                            </div>
                            <div class="col-sm-4">
                                <label class="form-label">Brand</label>
                                <input type="text" class="form-control" name="brand" placeholder="e.g., Apple">
                            </div>
                            <div class="col-sm-4">
                                <label class="form-label">Date Found <span class="required">*</span></label>
                                <input type="date" class="form-control" name="date_found" required>
                            </div>
                        </div>
                    </div>

                    <div class="mb-4">
                        <h6 class="form-section-title"><i class="fas fa-map-marker-alt"></i> Location</h6>
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label">Where did you find it? <span class="required">*</span></label>
                                <input type="text" class="form-control" name="location_found" required placeholder="e.g., Cafeteria, near the entrance">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Description</label>
                                <textarea class="form-control" name="description" rows="3" placeholder="Describe the item you found..."></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="mb-4">
                        <h6 class="form-section-title"><i class="fas fa-user"></i> Your Information</h6>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Your Name <span class="required">*</span></label>
                                <input type="text" class="form-control" name="finder_name" required placeholder="Full name">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">You are a:</label>
                                <select class="form-select" name="finder_role">
                                    <option value="student">Student</option>
                                    <option value="staff">Staff</option>
                                    <option value="security">Security</option>
                                    <option value="visitor">Visitor</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Contact Number <span class="required">*</span></label>
                                <input type="text" class="form-control" name="contact_number" required placeholder="e.g., +233 50 123 4567">
                            </div>
                        </div>
                    </div>

                    <div class="mb-4">
                        <h6 class="form-section-title"><i class="fas fa-camera"></i> Upload Image</h6>
                        <div class="row">
                            <div class="col-12">
                                <label class="form-label">Photo of Item (optional)</label>
                                <input type="file" class="form-control" name="image" accept=".jpg,.jpeg,.png,.webp">
                                <small class="text-muted d-block mt-1">Max 5MB. Accepted: JPG, PNG, WEBP</small>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn-submit">
                        <i class="fas fa-paper-plane"></i> Submit Found Item
                    </button>
                </form>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleTheme() {
            var html = document.documentElement;
            var icons = document.querySelectorAll('#themeIcon, #themeIconMobile');
            var isDark = html.getAttribute('data-bs-theme') === 'dark';
            if (isDark) {
                html.setAttribute('data-bs-theme', 'light');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-moon'; });
                localStorage.setItem('theme', 'light');
            } else {
                html.setAttribute('data-bs-theme', 'dark');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-sun'; });
                localStorage.setItem('theme', 'dark');
            }
        }

        (function() {
            var saved = localStorage.getItem('theme');
            var prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            var icons = document.querySelectorAll('#themeIcon, #themeIconMobile');
            if (saved === 'dark' || (!saved && prefersDark)) {
                document.documentElement.setAttribute('data-bs-theme', 'dark');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-sun'; });
            }
        })();

        document.querySelectorAll('.navbar-nav .nav-link').forEach(function(link) {
            link.addEventListener('click', function() {
                var collapse = document.getElementById('navbarNav');
                if (collapse.classList.contains('show')) {
                    bootstrap.Collapse.getInstance(collapse).hide();
                }
            });
        });
    </script>
</body>
</html>