<?php
require_once __DIR__ . '/../config/init.php';
$db = getDB();

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $itemName = sanitize($_POST['item_name']);
    $category = sanitize($_POST['category']);
    $color = sanitize($_POST['color'] ?? '');
    $brand = sanitize($_POST['brand'] ?? '');
    $locationLost = sanitize($_POST['location_lost']);
    $dateLost = sanitize($_POST['date_lost']);
    $description = sanitize($_POST['description'] ?? '');
    $ownerName = sanitize($_POST['owner_name']);
    $studentId = sanitize($_POST['student_id'] ?? '');
    $contactNumber = sanitize($_POST['contact_number']);
    $email = sanitize($_POST['email'] ?? '');

    // Handle image upload
    $imageName = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../assets/uploads/lost/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
            if ($_FILES['image']['size'] <= 5 * 1024 * 1024) {
                $imageName = 'lost_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName);
            } else {
                $error = 'Image must be under 5MB.';
            }
        } else {
            $error = 'Invalid image format. Use JPG, PNG, or WEBP.';
        }
    }

    if (empty($error)) {
        $stmt = $db->prepare("
            INSERT INTO lost_items (item_name, category, color, brand, location_lost, date_lost, description, owner_name, student_id, contact_number, email, image)
            VALUES (:name, :cat, :color, :brand, :location, :date, :desc, :owner, :sid, :contact, :email, :image)
        ");
        $stmt->execute([
            ':name' => $itemName, ':cat' => $category, ':color' => $color,
            ':brand' => $brand, ':location' => $locationLost,
            ':date' => $dateLost, ':desc' => $description,
            ':owner' => $ownerName, ':sid' => $studentId,
            ':contact' => $contactNumber, ':email' => $email,
            ':image' => $imageName
        ]);

        // Run matching engine
        $engine = new MatchEngine();
        $engine->findMatches($db->lastInsertId());

        // Notify admins
        $notif = new Notification();
        $notif->create('new_lost', 'New Lost Item Reported', "{$itemName} reported lost at {$locationLost} by {$ownerName}");

        $success = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Report Lost Item - Returnify</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #2563EB;
            --purple: #8B5CF6;
            --success: #10B981;
            --danger: #EF4444;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            background: #f0f4ff;
            color: #1e293b;
            overflow-x: hidden;
            min-height: 100vh;
            -webkit-font-smoothing: antialiased;
        }

        [data-bs-theme="dark"] body {
            background: #0a0e1a;
            color: #e2e8f0;
        }

        /* Background Blobs */
        .bg-animation {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            pointer-events: none; z-index: 0; overflow: hidden;
        }
        .bg-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.25;
            animation: blobFloat 20s infinite ease-in-out;
        }
        .bg-blob:nth-child(1) {
            width: 500px; height: 500px;
            background: #EF4444;
            top: -100px; right: -100px;
            animation-delay: 0s;
        }
        .bg-blob:nth-child(2) {
            width: 400px; height: 400px;
            background: #2563EB;
            bottom: -100px; left: -100px;
            animation-delay: -7s;
        }
        .bg-blob:nth-child(3) {
            width: 300px; height: 300px;
            background: #8B5CF6;
            top: 50%; left: 50%;
            animation-delay: -14s;
        }

        @keyframes blobFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(80px, -40px) scale(1.1); }
            66% { transform: translate(-40px, 60px) scale(0.9); }
        }

        [data-bs-theme="dark"] .bg-blob { opacity: 0.12; }

        /* ============ NAVBAR ============ */
        .navbar {
            position: fixed;
            top: 15px;
            left: 50%;
            transform: translateX(-50%);
            width: 92%;
            max-width: 1200px;
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 20px;
            padding: 12px 20px;
            z-index: 1000;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.06);
        }

        [data-bs-theme="dark"] .navbar {
            background: rgba(15, 23, 42, 0.75);
            border-color: rgba(255, 255, 255, 0.08);
        }

        .navbar-brand {
            font-size: 1.25rem;
            font-weight: 800;
            background: linear-gradient(135deg, #2563EB, #8B5CF6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-decoration: none;
            white-space: nowrap;
        }

        .navbar-brand i {
            background: linear-gradient(135deg, #2563EB, #0EA5E9);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .nav-link {
            color: #64748b !important;
            font-weight: 500;
            font-size: 0.9rem;
            padding: 10px 16px !important;
            border-radius: 12px;
            transition: all 0.3s ease;
            white-space: nowrap;
        }

        .nav-link:hover, .nav-link.active {
            color: #EF4444 !important;
            background: rgba(239, 68, 68, 0.08);
        }

        [data-bs-theme="dark"] .nav-link {
            color: #94a3b8 !important;
        }

        [data-bs-theme="dark"] .nav-link:hover {
            color: #F87171 !important;
            background: rgba(248, 113, 113, 0.1);
        }

        .navbar-toggler {
            border: none !important;
            padding: 8px;
            border-radius: 10px;
            background: rgba(239, 68, 68, 0.08);
            box-shadow: none !important;
        }

        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(239, 68, 68, 1)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e") !important;
        }

        @media (max-width: 991px) {
            .navbar-collapse {
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(20px);
                border-radius: 16px;
                padding: 16px;
                margin-top: 12px;
                border: 1px solid rgba(255, 255, 255, 0.3);
                max-height: 80vh;
                overflow-y: auto;
            }
            [data-bs-theme="dark"] .navbar-collapse {
                background: rgba(15, 23, 42, 0.95);
                border-color: rgba(255, 255, 255, 0.08);
            }
        }

        .theme-btn {
            width: 40px; height: 40px; min-width: 40px;
            border-radius: 12px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            background: rgba(255, 255, 255, 0.5);
            color: #64748b;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        [data-bs-theme="dark"] .theme-btn {
            border-color: rgba(255, 255, 255, 0.1);
            background: rgba(255, 255, 255, 0.05);
            color: #e2e8f0;
        }

        /* ============ FORM CONTAINER ============ */
        .form-wrapper {
            position: relative;
            z-index: 1;
            padding: 120px 16px 60px;
            max-width: 800px;
            margin: 0 auto;
        }

        /* Glass Card */
        .glass-card {
            background: rgba(255, 255, 255, 0.55);
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.5);
            border-radius: 24px;
            padding: 32px 24px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.06);
        }

        [data-bs-theme="dark"] .glass-card {
            background: rgba(30, 41, 59, 0.55);
            border-color: rgba(255, 255, 255, 0.06);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        @media (min-width: 768px) {
            .glass-card {
                padding: 40px 36px;
            }
        }

        /* Header */
        .form-header {
            text-align: center;
            margin-bottom: 32px;
        }

        .form-header .icon-circle {
            width: 72px; height: 72px;
            border-radius: 24px;
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.15), rgba(245, 158, 11, 0.15));
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            font-size: 30px;
            color: #EF4444;
        }

        .form-header h2 {
            font-weight: 800;
            font-size: clamp(1.5rem, 3vw, 1.8rem);
            letter-spacing: -0.5px;
            margin-bottom: 4px;
        }

        .form-header p {
            color: #64748b;
            font-size: 0.9rem;
        }

        [data-bs-theme="dark"] .form-header p {
            color: #94a3b8;
        }

        /* Section Titles */
        .form-section-title {
            font-weight: 700;
            font-size: 0.95rem;
            color: #EF4444;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
            padding-bottom: 12px;
            border-bottom: 1px solid rgba(239, 68, 68, 0.15);
        }

        [data-bs-theme="dark"] .form-section-title {
            border-bottom-color: rgba(248, 113, 113, 0.15);
        }

        /* Form Controls */
        .form-label {
            font-weight: 600;
            font-size: 0.85rem;
            color: #475569;
            margin-bottom: 6px;
        }

        [data-bs-theme="dark"] .form-label {
            color: #cbd5e1;
        }

        .form-label .required {
            color: #EF4444;
        }

        .form-control, .form-select {
            border-radius: 12px;
            border: 1.5px solid rgba(0, 0, 0, 0.1);
            padding: 12px 16px;
            font-size: 0.9rem;
            font-family: 'Inter', sans-serif;
            background: rgba(255, 255, 255, 0.7);
            transition: all 0.3s ease;
        }

        [data-bs-theme="dark"] .form-control,
        [data-bs-theme="dark"] .form-select {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(255, 255, 255, 0.1);
            color: #e2e8f0;
        }

        .form-control:focus, .form-select:focus {
            border-color: #EF4444;
            box-shadow: 0 0 0 4px rgba(239, 68, 68, 0.1);
            background: rgba(255, 255, 255, 0.9);
        }

        [data-bs-theme="dark"] .form-control:focus,
        [data-bs-theme="dark"] .form-select:focus {
            background: rgba(255, 255, 255, 0.08);
            box-shadow: 0 0 0 4px rgba(239, 68, 68, 0.15);
        }

        .form-control::placeholder {
            color: #94a3b8;
        }

        textarea.form-control {
            resize: vertical;
            min-height: 80px;
        }

        /* Submit Button */
        .btn-submit {
            width: 100%;
            padding: 14px 24px;
            border-radius: 14px;
            background: linear-gradient(135deg, #EF4444, #F59E0B);
            color: #fff;
            border: none;
            font-weight: 700;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 8px 25px rgba(239, 68, 68, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 35px rgba(239, 68, 68, 0.4);
        }

        /* Success State */
        .success-card {
            text-align: center;
            padding: 40px 20px;
        }

        .success-icon {
            font-size: 64px;
            color: #10B981;
            animation: scaleIn 0.6s ease;
        }

        @keyframes scaleIn {
            0% { transform: scale(0); opacity: 0; }
            70% { transform: scale(1.15); }
            100% { transform: scale(1); opacity: 1; }
        }

        .success-card h3 {
            font-weight: 800;
            margin: 20px 0 8px;
        }

        .success-card p {
            color: #64748b;
            margin-bottom: 24px;
        }

        .btn-group-custom {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn-outline-glass {
            background: rgba(255, 255, 255, 0.5);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(37, 99, 235, 0.3);
            color: #2563EB;
            padding: 12px 24px;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        [data-bs-theme="dark"] .btn-outline-glass {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(96, 165, 250, 0.3);
            color: #60A5FA;
        }

        .btn-outline-glass:hover {
            background: rgba(37, 99, 235, 0.1);
            transform: translateY(-2px);
        }

        /* Alert */
        .alert {
            border-radius: 14px;
            border: none;
            font-weight: 500;
        }

        /* ============ RESPONSIVE ============ */
        @media (max-width: 480px) {
            .navbar {
                width: 95%;
                top: 8px;
                padding: 10px 14px;
                border-radius: 16px;
            }
            .navbar-brand {
                font-size: 1.1rem;
            }
            .form-wrapper {
                padding: 100px 10px 40px;
            }
            .glass-card {
                padding: 24px 16px;
                border-radius: 20px;
            }
            .form-header .icon-circle {
                width: 56px; height: 56px;
                border-radius: 18px;
                font-size: 24px;
            }
        }
    </style>
</head>
<body>

    <!-- Background Blobs -->
    <div class="bg-animation">
        <div class="bg-blob"></div>
        <div class="bg-blob"></div>
        <div class="bg-blob"></div>
    </div>

    <!-- Glass Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid px-0">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-search-location"></i> Returnify
            </a>
            <div class="d-flex align-items-center gap-2 d-lg-none">
                <button class="theme-btn" onclick="toggleTheme()" aria-label="Toggle theme">
                    <i class="fas fa-moon" id="themeIconMobile"></i>
                </button>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto gap-1">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="found-items.php">Browse Items</a></li>
                    <li class="nav-item"><a class="nav-link active" href="report-lost.php">Report Lost</a></li>
                    <li class="nav-item"><a class="nav-link" href="report-found.php">Report Found</a></li>
                    <li class="nav-item"><a class="nav-link" href="track-claim.php">Track Claim</a></li>
                </ul>
                <div class="d-none d-lg-flex align-items-center gap-2">
                    <button class="theme-btn" onclick="toggleTheme()" id="themeIconWrapper" aria-label="Toggle theme">
                        <i class="fas fa-moon" id="themeIcon"></i>
                    </button>
                    <a href="../auth/login.php" class="btn btn-sm text-white" style="background:linear-gradient(135deg,#2563EB,#8B5CF6);border-radius:12px;padding:8px 16px;font-weight:600;text-decoration:none;">
                        <i class="fas fa-lock me-1"></i>Admin
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Form Wrapper -->
    <div class="form-wrapper">
        <?php if ($success): ?>
            <!-- Success State -->
            <div class="glass-card success-card">
                <i class="fas fa-check-circle success-icon"></i>
                <h3>Item Reported Successfully!</h3>
                <p>Your lost item has been recorded. Our AI system will automatically search for matches with found items. We'll notify you if a match is found.</p>
                <div class="btn-group-custom">
                    <a href="index.php" class="btn-submit" style="width:auto;padding:12px 28px;text-decoration:none;">
                        <i class="fas fa-home me-1"></i> Back to Home
                    </a>
                    <a href="report-lost.php" class="btn-outline-glass">
                        <i class="fas fa-plus me-1"></i> Report Another
                    </a>
                </div>
            </div>
        <?php else: ?>
            <!-- Form -->
            <div class="glass-card">
                <div class="form-header">
                    <div class="icon-circle">
                        <i class="fas fa-box-open"></i>
                    </div>
                    <h2>Report Lost Item</h2>
                    <p>Fill in the details below to report your missing item</p>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>

                <form method="POST" enctype="multipart/form-data">
                    <!-- Item Information -->
                    <div class="mb-4">
                        <h6 class="form-section-title">
                            <i class="fas fa-info-circle"></i> Item Information
                        </h6>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Item Name <span class="required">*</span></label>
                                <input type="text" class="form-control" name="item_name" required placeholder="e.g., Dell XPS 15 Laptop">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Category <span class="required">*</span></label>
                                <select class="form-select" name="category" required>
                                    <option value="">Select category...</option>
                                    <option>Electronics</option>
                                    <option>Clothing</option>
                                    <option>Books</option>
                                    <option>ID Cards</option>
                                    <option>Keys</option>
                                    <option>Bags</option>
                                    <option>Jewelry</option>
                                    <option>Water Bottle</option>
                                    <option>Other</option>
                                </select>
                            </div>
                            <div class="col-sm-4">
                                <label class="form-label">Color</label>
                                <input type="text" class="form-control" name="color" placeholder="e.g., Silver">
                            </div>
                            <div class="col-sm-4">
                                <label class="form-label">Brand</label>
                                <input type="text" class="form-control" name="brand" placeholder="e.g., Dell">
                            </div>
                            <div class="col-sm-4">
                                <label class="form-label">Unique Features</label>
                                <input type="text" class="form-control" name="unique_features" placeholder="Stickers, scratches...">
                            </div>
                        </div>
                    </div>

                    <!-- Location & Date -->
                    <div class="mb-4">
                        <h6 class="form-section-title">
                            <i class="fas fa-map-marker-alt"></i> Location & Date
                        </h6>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Location Lost <span class="required">*</span></label>
                                <input type="text" class="form-control" name="location_lost" required placeholder="e.g., Library 2nd Floor">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Date Lost <span class="required">*</span></label>
                                <input type="date" class="form-control" name="date_lost" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Description</label>
                                <textarea class="form-control" name="description" rows="3" placeholder="Describe your item in detail (size, condition, distinguishing marks)..."></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- Your Information -->
                    <div class="mb-4">
                        <h6 class="form-section-title">
                            <i class="fas fa-user"></i> Your Contact Information
                        </h6>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Full Name <span class="required">*</span></label>
                                <input type="text" class="form-control" name="owner_name" required placeholder="Your full name">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Student/Staff ID</label>
                                <input type="text" class="form-control" name="student_id" placeholder="e.g., STU-2024-001">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Contact Number <span class="required">*</span></label>
                                <input type="text" class="form-control" name="contact_number" required placeholder="e.g., +233 50 123 4567">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" name="email" placeholder="your@email.com">
                            </div>
                        </div>
                    </div>

                    <!-- Image Upload -->
                    <div class="mb-4">
                        <h6 class="form-section-title">
                            <i class="fas fa-camera"></i> Upload Image
                        </h6>
                        <div class="row">
                            <div class="col-12">
                                <label class="form-label">Photo of Item (optional)</label>
                                <input type="file" class="form-control" name="image" accept=".jpg,.jpeg,.png,.webp">
                                <small class="text-muted d-block mt-1">Max 5MB. Accepted: JPG, PNG, WEBP</small>
                            </div>
                        </div>
                    </div>

                    <!-- Submit -->
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-paper-plane"></i> Submit Report
                    </button>
                </form>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleTheme() {
            var html = document.documentElement;
            var icons = document.querySelectorAll('#themeIcon, #themeIconMobile');
            var isDark = html.getAttribute('data-bs-theme') === 'dark';
            if (isDark) {
                html.setAttribute('data-bs-theme', 'light');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-moon'; });
                localStorage.setItem('theme', 'light');
            } else {
                html.setAttribute('data-bs-theme', 'dark');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-sun'; });
                localStorage.setItem('theme', 'dark');
            }
        }

        (function() {
            var saved = localStorage.getItem('theme');
            var prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            var icons = document.querySelectorAll('#themeIcon, #themeIconMobile');
            if (saved === 'dark' || (!saved && prefersDark)) {
                document.documentElement.setAttribute('data-bs-theme', 'dark');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-sun'; });
            }
        })();

        document.querySelectorAll('.navbar-nav .nav-link').forEach(function(link) {
            link.addEventListener('click', function() {
                var collapse = document.getElementById('navbarNav');
                if (collapse.classList.contains('show')) {
                    bootstrap.Collapse.getInstance(collapse).hide();
                }
            });
        });
    </script>
</body>
</html>