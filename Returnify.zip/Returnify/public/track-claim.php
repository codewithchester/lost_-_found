<?php
require_once __DIR__ . '/../config/init.php';
$db = getDB();

$claim = null;
$error = '';
$searched = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $searched = true;
    $claimId = sanitize($_POST['claim_id'] ?? '');
    $email = sanitize($_POST['email'] ?? '');

    if (empty($claimId) || empty($email)) {
        $error = 'Please enter both Claim ID and Email.';
    } else {
        $stmt = $db->prepare("
            SELECT c.*, li.item_name AS lost_item_name, fi.item_name AS found_item_name
            FROM claims c
            LEFT JOIN lost_items li ON c.lost_item_id = li.id
            LEFT JOIN matches m ON c.match_id = m.id
            LEFT JOIN found_items fi ON m.found_item_id = fi.id
            WHERE c.claim_id = :cid AND c.email = :email
        ");
        $stmt->execute([':cid' => $claimId, ':email' => $email]);
        $claim = $stmt->fetch();

        if (!$claim) {
            $error = 'No claim found with that ID and email combination. Please check and try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Track Your Claim - Returnify</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    
    <style>
        :root { --primary: #2563EB; --purple: #8B5CF6; --success: #10B981; --warning: #F59E0B; --danger: #EF4444; }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            background: #f0f4ff;
            color: #1e293b;
            overflow-x: hidden;
            min-height: 100vh;
            -webkit-font-smoothing: antialiased;
        }

        [data-bs-theme="dark"] body {
            background: #0a0e1a;
            color: #e2e8f0;
        }

        /* Background Blobs */
        .bg-animation {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            pointer-events: none; z-index: 0; overflow: hidden;
        }
        .bg-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.25;
            animation: blobFloat 20s infinite ease-in-out;
        }
        .bg-blob:nth-child(1) {
            width: 500px; height: 500px;
            background: #8B5CF6;
            top: -100px; right: -100px;
        }
        .bg-blob:nth-child(2) {
            width: 400px; height: 400px;
            background: #2563EB;
            bottom: -100px; left: -100px;
            animation-delay: -7s;
        }
        .bg-blob:nth-child(3) {
            width: 300px; height: 300px;
            background: #F59E0B;
            top: 50%; left: 50%;
            animation-delay: -14s;
        }

        @keyframes blobFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(80px, -40px) scale(1.1); }
            66% { transform: translate(-40px, 60px) scale(0.9); }
        }

        [data-bs-theme="dark"] .bg-blob { opacity: 0.12; }

        /* ============ NAVBAR ============ */
        .navbar {
            position: fixed;
            top: 15px;
            left: 50%;
            transform: translateX(-50%);
            width: 92%;
            max-width: 1200px;
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 20px;
            padding: 12px 20px;
            z-index: 1000;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.06);
        }

        [data-bs-theme="dark"] .navbar {
            background: rgba(15, 23, 42, 0.75);
            border-color: rgba(255, 255, 255, 0.08);
        }

        .navbar-brand {
            font-size: 1.25rem;
            font-weight: 800;
            background: linear-gradient(135deg, #2563EB, #8B5CF6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-decoration: none;
            white-space: nowrap;
        }

        .navbar-brand i {
            background: linear-gradient(135deg, #2563EB, #0EA5E9);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .nav-link {
            color: #64748b !important;
            font-weight: 500;
            font-size: 0.9rem;
            padding: 10px 16px !important;
            border-radius: 12px;
            transition: all 0.3s ease;
            white-space: nowrap;
        }

        .nav-link:hover, .nav-link.active {
            color: #8B5CF6 !important;
            background: rgba(139, 92, 246, 0.08);
        }

        [data-bs-theme="dark"] .nav-link { color: #94a3b8 !important; }
        [data-bs-theme="dark"] .nav-link:hover { color: #A78BFA !important; background: rgba(167, 139, 250, 0.1); }

        .navbar-toggler {
            border: none !important;
            padding: 8px;
            border-radius: 10px;
            background: rgba(139, 92, 246, 0.08);
            box-shadow: none !important;
        }

        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(139, 92, 246, 1)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e") !important;
        }

        @media (max-width: 991px) {
            .navbar-collapse {
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(20px);
                border-radius: 16px;
                padding: 16px;
                margin-top: 12px;
                max-height: 80vh;
                overflow-y: auto;
            }
        }

        .theme-btn {
            width: 40px; height: 40px; min-width: 40px;
            border-radius: 12px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            background: rgba(255, 255, 255, 0.5);
            color: #64748b;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* ============ PAGE CONTENT ============ */
        .page-wrapper {
            position: relative;
            z-index: 1;
            padding: 120px 16px 60px;
            max-width: 700px;
            margin: 0 auto;
        }

        .glass-card {
            background: rgba(255, 255, 255, 0.55);
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.5);
            border-radius: 24px;
            padding: 32px 24px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.06);
            margin-bottom: 24px;
        }

        [data-bs-theme="dark"] .glass-card {
            background: rgba(30, 41, 59, 0.55);
            border-color: rgba(255, 255, 255, 0.06);
        }

        @media (min-width: 768px) { .glass-card { padding: 40px 36px; } }

        /* Header */
        .page-header { text-align: center; margin-bottom: 0; }
        .page-header .icon-circle {
            width: 72px; height: 72px;
            border-radius: 24px;
            background: linear-gradient(135deg, rgba(139, 92, 246, 0.15), rgba(37, 99, 235, 0.15));
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            font-size: 30px;
            color: #8B5CF6;
        }
        .page-header h2 {
            font-weight: 800;
            font-size: clamp(1.5rem, 3vw, 1.8rem);
            letter-spacing: -0.5px;
            margin-bottom: 4px;
        }
        .page-header p { color: #64748b; font-size: 0.9rem; }
        [data-bs-theme="dark"] .page-header p { color: #94a3b8; }

        /* Form */
        .form-label {
            font-weight: 600;
            font-size: 0.85rem;
            color: #475569;
            margin-bottom: 6px;
        }
        [data-bs-theme="dark"] .form-label { color: #cbd5e1; }

        .form-control {
            border-radius: 12px;
            border: 1.5px solid rgba(0, 0, 0, 0.1);
            padding: 12px 16px;
            font-size: 0.9rem;
            font-family: 'Inter', sans-serif;
            background: rgba(255, 255, 255, 0.7);
            transition: all 0.3s ease;
        }

        [data-bs-theme="dark"] .form-control {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(255, 255, 255, 0.1);
            color: #e2e8f0;
        }

        .form-control:focus {
            border-color: #8B5CF6;
            box-shadow: 0 0 0 4px rgba(139, 92, 246, 0.1);
        }

        .btn-submit {
            width: 100%;
            padding: 14px 24px;
            border-radius: 14px;
            background: linear-gradient(135deg, #8B5CF6, #2563EB);
            color: #fff;
            border: none;
            font-weight: 700;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 8px 25px rgba(139, 92, 246, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 35px rgba(139, 92, 246, 0.4);
        }

        .alert {
            border-radius: 14px;
            border: none;
            font-weight: 500;
            padding: 14px 18px;
        }

        /* Status Timeline */
        .status-timeline {
            position: relative;
            padding-left: 40px;
        }

        .status-timeline::before {
            content: '';
            position: absolute;
            left: 18px;
            top: 0;
            bottom: 0;
            width: 3px;
            background: #e2e8f0;
            border-radius: 2px;
        }

        [data-bs-theme="dark"] .status-timeline::before {
            background: #334155;
        }

        .status-step {
            position: relative;
            padding-bottom: 24px;
        }

        .status-step:last-child { padding-bottom: 0; }

        .status-dot {
            position: absolute;
            left: -40px;
            top: 2px;
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            color: #fff;
            z-index: 1;
        }

        .status-dot.completed {
            background: #10B981;
        }

        .status-dot.active {
            background: #8B5CF6;
            animation: pulse 2s infinite;
        }

        .status-dot.pending {
            background: #94a3b8;
        }

        .status-dot.rejected {
            background: #EF4444;
        }

        @keyframes pulse {
            0%, 100% { box-shadow: 0 0 0 0 rgba(139, 92, 246, 0.4); }
            50% { box-shadow: 0 0 0 12px rgba(139, 92, 246, 0); }
        }

        .status-step h6 {
            font-weight: 700;
            font-size: 0.9rem;
            margin-bottom: 2px;
        }

        .status-step p {
            font-size: 0.8rem;
            color: #64748b;
            margin: 0;
        }

        [data-bs-theme="dark"] .status-step p { color: #94a3b8; }

        /* Claim Details */
        .claim-detail-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }

        [data-bs-theme="dark"] .claim-detail-row {
            border-bottom-color: rgba(255,255,255,0.05);
        }

        .claim-detail-row:last-child { border-bottom: none; }

        .claim-detail-label {
            font-size: 0.85rem;
            color: #64748b;
            font-weight: 500;
        }

        .claim-detail-value {
            font-size: 0.85rem;
            font-weight: 600;
            text-align: right;
        }

        .badge-status {
            display: inline-block;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 700;
        }

        .badge-status.pending { background: rgba(245, 158, 11, 0.15); color: #F59E0B; }
        .badge-status.under_review { background: rgba(37, 99, 235, 0.15); color: #2563EB; }
        .badge-status.approved { background: rgba(16, 185, 129, 0.15); color: #10B981; }
        .badge-status.rejected { background: rgba(239, 68, 68, 0.15); color: #EF4444; }
        .badge-status.released { background: rgba(16, 185, 129, 0.2); color: #10B981; }

        .btn-back {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 10px 20px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.5);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(139, 92, 246, 0.3);
            color: #8B5CF6;
            font-weight: 600;
            font-size: 0.9rem;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .btn-back:hover {
            background: rgba(139, 92, 246, 0.1);
            transform: translateY(-2px);
            color: #8B5CF6;
        }

        .help-text {
            text-align: center;
            margin-top: 16px;
            font-size: 0.85rem;
            color: #94a3b8;
        }

        .help-text a {
            color: #8B5CF6;
            text-decoration: none;
            font-weight: 600;
        }

        .help-text a:hover { text-decoration: underline; }

        @media (max-width: 480px) {
            .navbar { width: 95%; top: 8px; padding: 10px 14px; border-radius: 16px; }
            .navbar-brand { font-size: 1.1rem; }
            .page-wrapper { padding: 100px 10px 40px; }
            .glass-card { padding: 24px 16px; border-radius: 20px; }
            .status-timeline { padding-left: 32px; }
            .status-dot { left: -32px; width: 24px; height: 24px; font-size: 10px; }
        }
    </style>
</head>
<body>

    <div class="bg-animation">
        <div class="bg-blob"></div>
        <div class="bg-blob"></div>
        <div class="bg-blob"></div>
    </div>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid px-0">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-search-location"></i> Returnify
            </a>
            <div class="d-flex align-items-center gap-2 d-lg-none">
                <button class="theme-btn" onclick="toggleTheme()" aria-label="Toggle theme">
                    <i class="fas fa-moon" id="themeIconMobile"></i>
                </button>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto gap-1">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="found-items.php">Browse Items</a></li>
                    <li class="nav-item"><a class="nav-link" href="report-lost.php">Report Lost</a></li>
                    <li class="nav-item"><a class="nav-link" href="report-found.php">Report Found</a></li>
                    <li class="nav-item"><a class="nav-link active" href="track-claim.php">Track Claim</a></li>
                </ul>
                <div class="d-none d-lg-flex align-items-center gap-2">
                    <button class="theme-btn" onclick="toggleTheme()" aria-label="Toggle theme">
                        <i class="fas fa-moon" id="themeIcon"></i>
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <!-- Page Content -->
    <div class="page-wrapper">

        <?php if ($claim): ?>
            <!-- Claim Found - Show Status -->
            <div class="glass-card">
                <div class="page-header">
                    <div class="icon-circle">
                        <i class="fas fa-clipboard-check"></i>
                    </div>
                    <h2>Claim Status</h2>
                    <p>Tracking your claim progress</p>
                </div>
            </div>

            <!-- Claim Details Card -->
            <div class="glass-card">
                <h6 class="fw-bold mb-3" style="font-size:0.9rem;color:#8B5CF6;">
                    <i class="fas fa-info-circle me-1"></i> Claim Information
                </h6>
                <div class="claim-detail-row">
                    <span class="claim-detail-label">Claim ID</span>
                    <span class="claim-detail-value"><?= htmlspecialchars($claim['claim_id']) ?></span>
                </div>
                <div class="claim-detail-row">
                    <span class="claim-detail-label">Status</span>
                    <span class="claim-detail-value">
                        <span class="badge-status <?= $claim['status'] ?>">
                            <?= ucfirst(str_replace('_', ' ', $claim['status'])) ?>
                        </span>
                    </span>
                </div>
                <div class="claim-detail-row">
                    <span class="claim-detail-label">Claimed By</span>
                    <span class="claim-detail-value"><?= htmlspecialchars($claim['claimed_by']) ?></span>
                </div>
                <?php if ($claim['lost_item_name']): ?>
                <div class="claim-detail-row">
                    <span class="claim-detail-label">Lost Item</span>
                    <span class="claim-detail-value"><?= htmlspecialchars($claim['lost_item_name']) ?></span>
                </div>
                <?php endif; ?>
                <?php if ($claim['found_item_name']): ?>
                <div class="claim-detail-row">
                    <span class="claim-detail-label">Found Item</span>
                    <span class="claim-detail-value"><?= htmlspecialchars($claim['found_item_name']) ?></span>
                </div>
                <?php endif; ?>
                <div class="claim-detail-row">
                    <span class="claim-detail-label">Contact</span>
                    <span class="claim-detail-value"><?= htmlspecialchars($claim['contact_number']) ?></span>
                </div>
                <div class="claim-detail-row">
                    <span class="claim-detail-label">Submitted</span>
                    <span class="claim-detail-value"><?= date('M d, Y - h:i A', strtotime($claim['created_at'])) ?></span>
                </div>
                <?php if ($claim['reviewed_at']): ?>
                <div class="claim-detail-row">
                    <span class="claim-detail-label">Reviewed</span>
                    <span class="claim-detail-value"><?= date('M d, Y', strtotime($claim['reviewed_at'])) ?></span>
                </div>
                <?php endif; ?>
            </div>

            <!-- Status Timeline -->
            <div class="glass-card">
                <h6 class="fw-bold mb-4" style="font-size:0.9rem;color:#8B5CF6;">
                    <i class="fas fa-timeline me-1"></i> Progress Timeline
                </h6>
                <div class="status-timeline">
                    <?php
                    $steps = [
                        ['id' => 'pending', 'label' => 'Claim Submitted', 'desc' => 'Your claim has been received and is awaiting review.'],
                        ['id' => 'under_review', 'label' => 'Under Review', 'desc' => 'Our team is reviewing your ownership evidence.'],
                        ['id' => 'approved', 'label' => 'Claim Approved', 'desc' => 'Your claim has been verified. You can collect your item.'],
                        ['id' => 'released', 'label' => 'Item Released', 'desc' => 'Item has been handed over to you. Case closed!'],
                    ];

                    $statusOrder = ['pending', 'under_review', 'approved', 'released'];
                    $currentIndex = array_search($claim['status'], $statusOrder);
                    if ($currentIndex === false) $currentIndex = 0;
                    if ($claim['status'] === 'rejected') $currentIndex = -1;

                    foreach ($steps as $i => $step):
                        $stepIndex = array_search($step['id'], $statusOrder);
                        if ($claim['status'] === 'rejected'):
                            $dotClass = 'pending';
                        elseif ($stepIndex < $currentIndex):
                            $dotClass = 'completed';
                        elseif ($stepIndex === $currentIndex):
                            $dotClass = 'active';
                        else:
                            $dotClass = 'pending';
                        endif;
                    ?>
                    <div class="status-step">
                        <div class="status-dot <?= $dotClass ?>">
                            <?php if ($dotClass === 'completed'): ?>
                                <i class="fas fa-check"></i>
                            <?php elseif ($dotClass === 'active'): ?>
                                <i class="fas fa-spinner fa-spin"></i>
                            <?php else: ?>
                                <i class="fas fa-circle"></i>
                            <?php endif; ?>
                        </div>
                        <h6><?= $step['label'] ?></h6>
                        <p><?= $step['desc'] ?></p>
                    </div>
                    <?php endforeach; ?>

                    <?php if ($claim['status'] === 'rejected'): ?>
                    <div class="status-step">
                        <div class="status-dot rejected">
                            <i class="fas fa-times"></i>
                        </div>
                        <h6>Claim Rejected</h6>
                        <p>Unfortunately, your claim could not be verified. Please contact the lost & found office for more information.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($claim['status'] === 'approved'): ?>
            <div class="glass-card" style="background:rgba(16,185,129,0.08);border-color:rgba(16,185,129,0.2);">
                <div class="d-flex align-items-center gap-3">
                    <i class="fas fa-check-circle text-success" style="font-size:32px;"></i>
                    <div>
                        <h6 class="fw-bold mb-1 text-success">Your Claim is Approved!</h6>
                        <p class="mb-0 small" style="color:#64748b;">Please visit the Lost & Found office with your Student ID to collect your item.</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="text-center mt-3">
                <a href="index.php" class="btn-back">
                    <i class="fas fa-arrow-left"></i> Back to Home
                </a>
            </div>

        <?php else: ?>
            <!-- Search Form -->
            <div class="glass-card">
                <div class="page-header">
                    <div class="icon-circle">
                        <i class="fas fa-search"></i>
                    </div>
                    <h2>Track Your Claim</h2>
                    <p>Enter your Claim ID and email to check the status</p>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>

                <?php if ($searched && !$claim && !$error): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-2"></i>No claim found. Please check your details.
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-hashtag me-1"></i> Claim ID
                        </label>
                        <input type="text" class="form-control" name="claim_id" 
                               placeholder="e.g., CLM-20260119-1234" required
                               value="<?= htmlspecialchars($_POST['claim_id'] ?? '') ?>">
                        <small class="text-muted d-block mt-1">You received this when you submitted your claim.</small>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">
                            <i class="fas fa-envelope me-1"></i> Email Address
                        </label>
                        <input type="email" class="form-control" name="email" 
                               placeholder="The email you used in your claim" required
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                    </div>

                    <button type="submit" class="btn-submit">
                        <i class="fas fa-search"></i> Track My Claim
                    </button>
                </form>

                <p class="help-text mt-3">
                    <i class="fas fa-question-circle me-1"></i>
                    Don't have a Claim ID? 
                    <a href="found-items.php">Browse found items</a> to claim one.
                </p>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleTheme() {
            var html = document.documentElement;
            var icons = document.querySelectorAll('#themeIcon, #themeIconMobile');
            var isDark = html.getAttribute('data-bs-theme') === 'dark';
            if (isDark) {
                html.setAttribute('data-bs-theme', 'light');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-moon'; });
                localStorage.setItem('theme', 'light');
            } else {
                html.setAttribute('data-bs-theme', 'dark');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-sun'; });
                localStorage.setItem('theme', 'dark');
            }
        }

        (function() {
            var saved = localStorage.getItem('theme');
            var prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            var icons = document.querySelectorAll('#themeIcon, #themeIconMobile');
            if (saved === 'dark' || (!saved && prefersDark)) {
                document.documentElement.setAttribute('data-bs-theme', 'dark');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-sun'; });
            }
        })();

        document.querySelectorAll('.navbar-nav .nav-link').forEach(function(link) {
            link.addEventListener('click', function() {
                var collapse = document.getElementById('navbarNav');
                if (collapse.classList.contains('show')) {
                    bootstrap.Collapse.getInstance(collapse).hide();
                }
            });
        });
    </script>
</body>
</html>