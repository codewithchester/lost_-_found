<?php
require_once __DIR__ . '/../config/init.php';
$db = getDB();

$search = sanitize($_GET['search'] ?? '');
$category = sanitize($_GET['category'] ?? '');

$sql = "SELECT * FROM found_items WHERE status IN ('found', 'unclaimed')";
$params = [];
if ($search) { 
    $sql .= " AND (item_name LIKE :search OR description LIKE :search2 OR location_found LIKE :search3)"; 
    $params[':search'] = "%{$search}%"; 
    $params[':search2'] = "%{$search}%"; 
    $params[':search3'] = "%{$search}%"; 
}
if ($category) { 
    $sql .= " AND category = :cat"; 
    $params[':cat'] = $category; 
}
$sql .= " ORDER BY created_at DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

$categories = $db->query("SELECT DISTINCT category FROM found_items ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
$totalFound = $db->query("SELECT COUNT(*) FROM found_items WHERE status IN ('found', 'unclaimed')")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Browse Found Items - Returnify</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    
    <style>
        :root { --primary: #2563EB; --purple: #8B5CF6; --success: #10B981; --teal: #0EA5E9; }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            background: #f0f4ff;
            color: #1e293b;
            overflow-x: hidden;
            min-height: 100vh;
            -webkit-font-smoothing: antialiased;
        }

        [data-bs-theme="dark"] body {
            background: #0a0e1a;
            color: #e2e8f0;
        }

        .bg-animation {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            pointer-events: none; z-index: 0; overflow: hidden;
        }
        .bg-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.25;
            animation: blobFloat 20s infinite ease-in-out;
        }
        .bg-blob:nth-child(1) {
            width: 500px; height: 500px;
            background: #10B981;
            top: -100px; right: -100px;
        }
        .bg-blob:nth-child(2) {
            width: 400px; height: 400px;
            background: #0EA5E9;
            bottom: -100px; left: -100px;
            animation-delay: -7s;
        }
        .bg-blob:nth-child(3) {
            width: 300px; height: 300px;
            background: #8B5CF6;
            top: 60%; left: 60%;
            animation-delay: -14s;
        }

        @keyframes blobFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(80px, -40px) scale(1.1); }
            66% { transform: translate(-40px, 60px) scale(0.9); }
        }

        [data-bs-theme="dark"] .bg-blob { opacity: 0.12; }

        /* ============ NAVBAR ============ */
        .navbar {
            position: fixed;
            top: 15px;
            left: 50%;
            transform: translateX(-50%);
            width: 92%;
            max-width: 1200px;
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 20px;
            padding: 12px 20px;
            z-index: 1000;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.06);
        }

        [data-bs-theme="dark"] .navbar {
            background: rgba(15, 23, 42, 0.75);
            border-color: rgba(255, 255, 255, 0.08);
        }

        .navbar-brand {
            font-size: 1.25rem;
            font-weight: 800;
            background: linear-gradient(135deg, #2563EB, #8B5CF6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-decoration: none;
            white-space: nowrap;
        }

        .navbar-brand i {
            background: linear-gradient(135deg, #2563EB, #0EA5E9);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .nav-link {
            color: #64748b !important;
            font-weight: 500;
            font-size: 0.9rem;
            padding: 10px 16px !important;
            border-radius: 12px;
            transition: all 0.3s ease;
            white-space: nowrap;
        }

        .nav-link:hover, .nav-link.active {
            color: #10B981 !important;
            background: rgba(16, 185, 129, 0.08);
        }

        [data-bs-theme="dark"] .nav-link { color: #94a3b8 !important; }
        [data-bs-theme="dark"] .nav-link:hover { color: #34D399 !important; background: rgba(52, 211, 153, 0.1); }

        .navbar-toggler {
            border: none !important;
            padding: 8px;
            border-radius: 10px;
            background: rgba(16, 185, 129, 0.08);
            box-shadow: none !important;
        }

        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(16, 185, 129, 1)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e") !important;
        }

        @media (max-width: 991px) {
            .navbar-collapse {
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(20px);
                border-radius: 16px;
                padding: 16px;
                margin-top: 12px;
                max-height: 80vh;
                overflow-y: auto;
            }
        }

        .theme-btn {
            width: 40px; height: 40px; min-width: 40px;
            border-radius: 12px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            background: rgba(255, 255, 255, 0.5);
            color: #64748b;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* ============ PAGE CONTENT ============ */
        .page-wrapper {
            position: relative;
            z-index: 1;
            padding: 120px 16px 60px;
        }

        .page-header {
            text-align: center;
            margin-bottom: 32px;
        }

        .page-header .icon-circle {
            width: 72px; height: 72px;
            border-radius: 24px;
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.15), rgba(14, 165, 233, 0.15));
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            font-size: 30px;
            color: #10B981;
        }

        .page-header h2 {
            font-weight: 800;
            font-size: clamp(1.5rem, 3vw, 1.8rem);
            letter-spacing: -0.5px;
            margin-bottom: 4px;
        }

        .page-header p { color: #64748b; font-size: 0.9rem; }

        [data-bs-theme="dark"] .page-header p { color: #94a3b8; }

        .items-count {
            display: inline-block;
            background: rgba(16, 185, 129, 0.1);
            color: #10B981;
            padding: 6px 14px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.8rem;
            margin-top: 8px;
        }

        /* ============ GLASS CARD ============ */
        .glass-card {
            background: rgba(255, 255, 255, 0.55);
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.5);
            border-radius: 20px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
            transition: all 0.3s ease;
        }

        [data-bs-theme="dark"] .glass-card {
            background: rgba(30, 41, 59, 0.55);
            border-color: rgba(255, 255, 255, 0.06);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }

        /* Search Bar */
        .search-card {
            padding: 20px;
            margin-bottom: 24px;
        }

        .form-control, .form-select {
            border-radius: 12px;
            border: 1.5px solid rgba(0, 0, 0, 0.1);
            padding: 12px 16px;
            font-size: 0.9rem;
            font-family: 'Inter', sans-serif;
            background: rgba(255, 255, 255, 0.7);
            transition: all 0.3s ease;
        }

        [data-bs-theme="dark"] .form-control,
        [data-bs-theme="dark"] .form-select {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(255, 255, 255, 0.1);
            color: #e2e8f0;
        }

        .form-control:focus, .form-select:focus {
            border-color: #10B981;
            box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.1);
        }

        .btn-search {
            width: 100%;
            padding: 12px 20px;
            border-radius: 12px;
            background: linear-gradient(135deg, #10B981, #0EA5E9);
            color: #fff;
            border: none;
            font-weight: 600;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s ease;
            white-space: nowrap;
        }

        .btn-search:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(16, 185, 129, 0.3);
        }

        /* Item Cards */
        .item-card {
            padding: 0;
            overflow: hidden;
            height: 100%;
        }

        .item-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.08);
        }

        .item-card-image {
            width: 100%;
            height: 180px;
            object-fit: cover;
            background: linear-gradient(135deg, #f1f5f9, #e2e8f0);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #94a3b8;
            font-size: 40px;
        }

        [data-bs-theme="dark"] .item-card-image {
            background: linear-gradient(135deg, #1e293b, #334155);
        }

        .item-card-body { padding: 18px; }

        .item-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
            background: rgba(16, 185, 129, 0.1);
            color: #10B981;
            margin-bottom: 8px;
        }

        .item-card h6 {
            font-weight: 700;
            font-size: 0.95rem;
            margin-bottom: 8px;
        }

        .item-card .meta {
            font-size: 0.78rem;
            color: #94a3b8;
            display: flex;
            align-items: center;
            gap: 6px;
            margin-bottom: 4px;
        }

        .btn-claim {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 18px;
            border-radius: 10px;
            background: linear-gradient(135deg, #10B981, #0EA5E9);
            color: #fff;
            font-weight: 600;
            font-size: 0.85rem;
            text-decoration: none;
            transition: all 0.3s ease;
            margin-top: 12px;
        }

        .btn-claim:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(16, 185, 129, 0.3);
            color: #fff;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }

        .empty-state i {
            font-size: 64px;
            color: #94a3b8;
            opacity: 0.4;
            margin-bottom: 16px;
        }

        .empty-state h5 {
            font-weight: 700;
            margin-bottom: 8px;
        }

        .empty-state p {
            color: #94a3b8;
            margin-bottom: 20px;
        }

        .btn-empty-action {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            border-radius: 14px;
            background: linear-gradient(135deg, #10B981, #0EA5E9);
            color: #fff;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .btn-empty-action:hover {
            transform: translateY(-2px);
            color: #fff;
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.3);
        }

        @media (max-width: 480px) {
            .navbar { width: 95%; top: 8px; padding: 10px 14px; border-radius: 16px; }
            .navbar-brand { font-size: 1.1rem; }
            .page-wrapper { padding: 100px 10px 40px; }
            .item-card-image { height: 150px; }
        }
    </style>
</head>
<body>

    <div class="bg-animation">
        <div class="bg-blob"></div>
        <div class="bg-blob"></div>
        <div class="bg-blob"></div>
    </div>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid px-0">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-search-location"></i> Returnify
            </a>
            <div class="d-flex align-items-center gap-2 d-lg-none">
                <button class="theme-btn" onclick="toggleTheme()" aria-label="Toggle theme">
                    <i class="fas fa-moon" id="themeIconMobile"></i>
                </button>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto gap-1">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link active" href="found-items.php">Browse Items</a></li>
                    <li class="nav-item"><a class="nav-link" href="report-lost.php">Report Lost</a></li>
                    <li class="nav-item"><a class="nav-link" href="report-found.php">Report Found</a></li>
                    <li class="nav-item"><a class="nav-link" href="track-claim.php">Track Claim</a></li>
                </ul>
                <div class="d-none d-lg-flex align-items-center gap-2">
                    <button class="theme-btn" onclick="toggleTheme()" aria-label="Toggle theme">
                        <i class="fas fa-moon" id="themeIcon"></i>
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <!-- Page Content -->
    <div class="page-wrapper">
        <div class="container">
            <!-- Header -->
            <div class="page-header">
                <div class="icon-circle">
                    <i class="fas fa-hand-holding-heart"></i>
                </div>
                <h2>Browse Found Items</h2>
                <p>See if your lost item has been found by someone on campus</p>
                <span class="items-count">
                    <i class="fas fa-box me-1"></i><?= $totalFound ?> item<?= $totalFound !== 1 ? 's' : '' ?> waiting
                </span>
            </div>

            <!-- Search Bar -->
            <div class="glass-card search-card">
                <form method="GET" action="">
                    <div class="row g-2">
                        <div class="col-md-5">
                            <input type="text" class="form-control" name="search" 
                                   placeholder="Search by name or location..." 
                                   value="<?= htmlspecialchars($search) ?>">
                        </div>
                        <div class="col-md-5">
                            <select class="form-select" name="category">
                                <option value="">All Categories</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= htmlspecialchars($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($cat) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn-search">
                                <i class="fas fa-search me-1"></i> Filter
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Items Grid -->
            <?php if (empty($items)): ?>
                <div class="glass-card empty-state">
                    <i class="fas fa-box-open"></i>
                    <h5>No Items Found</h5>
                    <p>No found items match your search criteria.</p>
                    <a href="found-items.php" class="btn-empty-action">
                        <i class="fas fa-sync-alt me-1"></i> View All Items
                    </a>
                </div>
            <?php else: ?>
                <div class="row g-3">
                    <?php foreach ($items as $item): ?>
                    <div class="col-sm-6 col-lg-4">
                        <div class="glass-card item-card">
                            <?php if ($item['image']): ?>
                                <img src="../assets/uploads/found/<?= htmlspecialchars($item['image']) ?>" 
                                     class="item-card-image" alt="<?= htmlspecialchars($item['item_name']) ?>" loading="lazy">
                            <?php else: ?>
                                <div class="item-card-image">
                                    <i class="fas fa-box-open"></i>
                                </div>
                            <?php endif; ?>
                            <div class="item-card-body">
                                <span class="item-badge">Found Item</span>
                                <h6><?= htmlspecialchars($item['item_name']) ?></h6>
                                <?php if ($item['category']): ?>
                                    <div class="meta"><i class="fas fa-tag"></i> <?= htmlspecialchars($item['category']) ?></div>
                                <?php endif; ?>
                                <?php if ($item['color']): ?>
                                    <div class="meta"><i class="fas fa-palette"></i> <?= htmlspecialchars($item['color']) ?></div>
                                <?php endif; ?>
                                <div class="meta"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($item['location_found']) ?></div>
                                <div class="meta"><i class="fas fa-calendar"></i> <?= date('M d, Y', strtotime($item['date_found'])) ?></div>
                                <a href="claim-item.php?id=<?= $item['id'] ?>" class="btn-claim">
                                    <i class="fas fa-check-circle"></i> This is Mine
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleTheme() {
            var html = document.documentElement;
            var icons = document.querySelectorAll('#themeIcon, #themeIconMobile');
            var isDark = html.getAttribute('data-bs-theme') === 'dark';
            if (isDark) {
                html.setAttribute('data-bs-theme', 'light');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-moon'; });
                localStorage.setItem('theme', 'light');
            } else {
                html.setAttribute('data-bs-theme', 'dark');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-sun'; });
                localStorage.setItem('theme', 'dark');
            }
        }

        (function() {
            var saved = localStorage.getItem('theme');
            var prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            var icons = document.querySelectorAll('#themeIcon, #themeIconMobile');
            if (saved === 'dark' || (!saved && prefersDark)) {
                document.documentElement.setAttribute('data-bs-theme', 'dark');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-sun'; });
            }
        })();

        document.querySelectorAll('.navbar-nav .nav-link').forEach(function(link) {
            link.addEventListener('click', function() {
                var collapse = document.getElementById('navbarNav');
                if (collapse.classList.contains('show')) {
                    bootstrap.Collapse.getInstance(collapse).hide();
                }
            });
        });
    </script>
</body>
</html>