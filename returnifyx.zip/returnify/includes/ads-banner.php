<?php
// Fetch active advertisements
$ads = $db->query("SELECT * FROM advertisements WHERE status = 'active' AND start_date <= CURDATE() AND end_date >= CURDATE() ORDER BY created_at DESC LIMIT 5")->fetchAll();
?>

<?php if (!empty($ads)): ?>
<div class="ads-section my-4">
    <div class="container">
        <div class="row g-3">
            <?php foreach ($ads as $ad): ?>
            <div class="col-md-4 col-sm-6">
                <div class="ad-card glass-card p-0 overflow-hidden">
                    <?php if ($ad['banner_image']): ?>
                        <img src="../assets/uploads/ads/<?= htmlspecialchars($ad['banner_image']) ?>" 
                             class="w-100" style="height:160px; object-fit:cover;" alt="<?= htmlspecialchars($ad['title']) ?>">
                    <?php else: ?>
                        <div class="bg-light d-flex align-items-center justify-content-center" style="height:160px;">
                            <i class="fas fa-bullhorn fa-2x text-muted"></i>
                        </div>
                    <?php endif; ?>
                    <div class="p-3">
                        <h6 class="fw-bold mb-1"><?= htmlspecialchars($ad['title']) ?></h6>
                        <p class="small text-muted mb-0"><?= htmlspecialchars(substr($ad['description'] ?? '', 0, 100)) ?>...</p>
                        <?php if ($ad['end_date']): ?>
                            <small class="text-muted">Ends: <?= date('M d, Y', strtotime($ad['end_date'])) ?></small>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>