<?php
require_once __DIR__ . '/../config/init.php';

$error = '';
$db = getDB();

// Check for too many failed attempts
$ip = $_SERVER['REMOTE_ADDR'];
$lockoutDuration = 15; // minutes
$maxAttempts = 5;

$stmt = $db->prepare("SELECT COUNT(*) FROM activity_logs WHERE ip_address = :ip AND action = 'failed_login' AND created_at > DATE_SUB(NOW(), INTERVAL :duration MINUTE)");
$stmt->execute([':ip' => $ip, ':duration' => $lockoutDuration]);
$failedAttempts = $stmt->fetchColumn();

if ($failedAttempts >= $maxAttempts) {
    $error = "Too many failed login attempts. Please try again in {$lockoutDuration} minutes.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($error)) {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = "Invalid security token. Please refresh the page.";
    } else {
        $username = sanitize($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $remember = isset($_POST['remember']);

        if (empty($username) || empty($password)) {
            $error = "Please enter both username and password.";
        } else {
            $stmt = $db->prepare("SELECT * FROM admins WHERE (username = :username OR email = :email) AND status = 1");
            $stmt->execute([':username' => $username, ':email' => $username]);
            $admin = $stmt->fetch();

            if ($admin && password_verify($password, $admin['password'])) {
                // Successful login
                session_regenerate_id(true);
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_name'] = $admin['fullname'];
                $_SESSION['admin_role'] = $admin['role'];
                $_SESSION['last_activity'] = time();

                // Update last login
                $stmt = $db->prepare("UPDATE admins SET last_login = NOW() WHERE id = :id");
                $stmt->execute([':id' => $admin['id']]);

                // Log activity
                $logger = new ActivityLogger();
                $logger->log('login_success', 'auth', $admin['id'], 'Admin logged in successfully');

                // Remember me - set cookie for 30 days
                if ($remember) {
                    $token = generateRandomString(64);
                    setcookie('remember_token', $token, time() + (86400 * 30), '/', '', false, true);
                }

                header('Location: ../admin/index.php');
                exit;
            } else {
                $error = "Invalid username or password.";
                $logger = new ActivityLogger();
                $logger->log('failed_login', 'auth', null, "Failed login attempt for username: {$username}");
            }
        }
    }
}

$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - University Lost & Found</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #2563EB;
            --secondary: #0EA5E9;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        }
        [data-bs-theme="dark"] body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        }
        .login-container {
            width: 100%;
            max-width: 440px;
            padding: 20px;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.15), 0 0 0 1px rgba(255,255,255,0.3);
        }
        [data-bs-theme="dark"] .login-card {
            background: rgba(30, 30, 40, 0.95);
            box-shadow: 0 20px 60px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.1);
        }
        .login-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-logo i {
            font-size: 48px;
            color: var(--primary);
            background: linear-gradient(135deg, #2563EB, #0EA5E9);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .login-logo h2 {
            font-weight: 700;
            color: #1e293b;
            margin-top: 10px;
        }
        [data-bs-theme="dark"] .login-logo h2 { color: #e2e8f0; }

        /* Form */
        .form-floating > .form-control {
            border-radius: 12px;
            border: 2px solid #e2e8f0;
            transition: all 0.3s ease;
        }
        .form-floating > .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(37,99,235,0.1);
        }
        [data-bs-theme="dark"] .form-floating > .form-control {
            background: rgba(255,255,255,0.05);
            border-color: rgba(255,255,255,0.1);
            color: #e2e8f0;
        }

        /* Password toggle inside form-floating */
        .form-floating.password-field .form-control {
            padding-right: 50px; /* space for the eye icon */
        }
        .password-toggle {
            position: absolute;
            right: 6px;
            top: 50%;
            transform: translateY(-50%);
            width: 40px;
            height: 40px;
            border: none;
            background: transparent;
            color: #94a3b8;
            cursor: pointer;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
            z-index: 5;
            font-size: 16px;
        }
        .password-toggle:hover {
            color: #2563EB;
            background: rgba(37, 99, 235, 0.08);
        }

        .btn-login {
            width: 100%;
            padding: 14px;
            border-radius: 12px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border: none;
            font-weight: 600;
            font-size: 16px;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            color: #fff;
            cursor: pointer;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(37,99,235,0.4);
        }

        /* View Site Button */
        .btn-view-site {
            width: 100%;
            padding: 12px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.6);
            backdrop-filter: blur(10px);
            border: 1.5px solid rgba(37, 99, 235, 0.2);
            font-weight: 600;
            font-size: 0.9rem;
            color: #2563EB;
            text-decoration: none;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-top: 12px;
        }
        .btn-view-site:hover {
            background: rgba(37, 99, 235, 0.08);
            border-color: #2563EB;
            transform: translateY(-2px);
            color: #1D4ED8;
        }
        [data-bs-theme="dark"] .btn-view-site {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(96, 165, 250, 0.2);
            color: #60A5FA;
        }
        [data-bs-theme="dark"] .btn-view-site:hover {
            background: rgba(96, 165, 250, 0.1);
            border-color: #60A5FA;
            color: #93C5FD;
        }

        .alert { border-radius: 12px; border: none; }
        .theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(255,255,255,0.2);
            border: none;
            color: #fff;
            width: 44px;
            height: 44px;
            border-radius: 50%;
            cursor: pointer;
            backdrop-filter: blur(10px);
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }
        .theme-toggle:hover { background: rgba(255,255,255,0.3); }

        /* Back to site */
        .back-arrow {
            position: fixed;
            top: 20px;
            left: 20px;
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: #fff;
            width: 44px;
            height: 44px;
            border-radius: 50%;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10;
            text-decoration: none;
            font-size: 18px;
        }
        .back-arrow:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: scale(1.1);
            color: #fff;
        }

        @media (max-width: 480px) {
            .login-card { padding: 28px 20px; border-radius: 20px; }
        }
    </style>
</head>
<body>

    <!-- Back to Website -->
    <a href="../public/index.php" class="back-arrow" title="View Website">
        <i class="fas fa-arrow-left"></i>
    </a>

    <!-- Theme Toggle -->
    <button class="theme-toggle" onclick="toggleTheme()" title="Toggle theme">
        <i class="fas fa-moon"></i>
    </button>

    <div class="login-container">
        <div class="login-card">
            <div class="login-logo">
                <i class="fas fa-search-location"></i>
                <h2>Lost & Found</h2>
                <p class="text-muted">University Management System</p>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['msg']) && $_GET['msg'] === 'logged_out'): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>You have been logged out successfully.
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form method="POST" action="" autocomplete="off">
                <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

                <!-- Fake hidden fields to prevent browser autocomplete -->
                <input type="text" name="fake_username" style="display:none;" autocomplete="off">
                <input type="password" name="fake_password" style="display:none;" autocomplete="off">

                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="username" name="username" 
                           placeholder="Username or Email" required autofocus
                           autocomplete="off" value="">
                    <label for="username"><i class="fas fa-user me-2"></i>Username or Email</label>
                </div>

                <div class="form-floating mb-3 password-field">
                    <input type="password" class="form-control" id="password" name="password" 
                           placeholder="Password" required
                           autocomplete="new-password" value="">
                    <label for="password"><i class="fas fa-lock me-2"></i>Password</label>
                    <button type="button" class="password-toggle" id="togglePassword" tabindex="-1"
                            onclick="togglePasswordVisibility()" title="Show password">
                        <i class="fas fa-eye" id="toggleIcon"></i>
                    </button>
                </div>

                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="remember" name="remember" autocomplete="off">
                        <label class="form-check-label" for="remember">Remember me</label>
                    </div>
                    <a href="#" class="text-decoration-none" style="color: var(--primary);">Forgot password?</a>
                </div>

                <button type="submit" class="btn btn-login">
                    <i class="fas fa-sign-in-alt me-2"></i>Sign In
                </button>

                <!-- View Public Website -->
                <a href="../public/index.php" class="btn-view-site">
                    <i class="fas fa-globe"></i> View Public Website
                </a>
            </form>

            <div class="text-center mt-4">
                <small class="text-muted">
                    <i class="fas fa-shield-alt me-1"></i>Secure Admin Access
                </small>
            </div>
        </div>
    </div>

    <script>
        // Password show/hide toggle
        function togglePasswordVisibility() {
            var passwordField = document.getElementById('password');
            var toggleIcon = document.getElementById('toggleIcon');
            var toggleBtn = document.getElementById('togglePassword');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                toggleIcon.className = 'fas fa-eye-slash';
                toggleBtn.title = 'Hide password';
            } else {
                passwordField.type = 'password';
                toggleIcon.className = 'fas fa-eye';
                toggleBtn.title = 'Show password';
            }
        }

        // Clear autofill
        window.addEventListener('DOMContentLoaded', function() {
            var pwd = document.getElementById('password');
            var usr = document.getElementById('username');
            if (pwd) pwd.value = '';
            if (usr) usr.value = '';
            setTimeout(function() {
                if (pwd) pwd.value = '';
                if (usr) usr.value = '';
            }, 200);
        });

        // Theme toggle
        function toggleTheme() {
            var html = document.documentElement;
            var icon = document.querySelector('.theme-toggle i');
            if (html.getAttribute('data-bs-theme') === 'dark') {
                html.setAttribute('data-bs-theme', 'light');
                if (icon) icon.className = 'fas fa-moon';
                localStorage.setItem('theme', 'light');
            } else {
                html.setAttribute('data-bs-theme', 'dark');
                if (icon) icon.className = 'fas fa-sun';
                localStorage.setItem('theme', 'dark');
            }
        }

        (function() {
            var saved = localStorage.getItem('theme');
            var prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            var icon = document.querySelector('.theme-toggle i');
            if (saved === 'dark' || (!saved && prefersDark)) {
                document.documentElement.setAttribute('data-bs-theme', 'dark');
                if (icon) icon.className = 'fas fa-sun';
            }
        })();
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>