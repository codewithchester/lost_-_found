<?php
class Validator {
    private $errors = [];
    private $data = [];

    public function __construct($data) {
        $this->data = $data;
    }

    /**
     * Validate item name – 2–80 meaningful characters, no gibberish
     */
    public function validateItemName($field, $label = 'Item Name') {
        $value = trim($this->data[$field] ?? '');
        
        if (empty($value)) {
            $this->errors[$field] = "{$label} is required.";
            return $this;
        }

        if (strlen($value) < 2) {
            $this->errors[$field] = "{$label} must be at least 2 characters.";
            return $this;
        }

        if (strlen($value) > 80) {
            $this->errors[$field] = "{$label} must not exceed 80 characters.";
            return $this;
        }

        // Reject pure numbers
        if (preg_match('/^\d+$/', $value)) {
            $this->errors[$field] = "{$label} cannot be just numbers. Please describe your item.";
            return $this;
        }

        // Must contain at least one vowel (English)
        if (!preg_match('/[aeiou]/i', $value)) {
            $this->errors[$field] = "{$label} doesn't look like a real item name. Please enter a meaningful name.";
            return $this;
        }

        // Reject random keyboard mashing (more than 4 consonants in a row without a vowel)
        if (preg_match('/[bcdfghjklmnpqrstvwxyz]{5,}/i', $value)) {
            $this->errors[$field] = "{$label} appears to contain gibberish. Please enter a proper item name.";
            return $this;
        }

        // Must contain at least one letter
        if (!preg_match('/[a-zA-Z]/', $value)) {
            $this->errors[$field] = "{$label} must contain at least one letter.";
            return $this;
        }

        return $this;
    }

    /**
     * Validate person name – no numbers, no excessive symbols, no all-caps gibberish
     */
    public function validatePersonName($field, $label = 'Name') {
        $value = trim($this->data[$field] ?? '');
        
        if (empty($value)) {
            $this->errors[$field] = "{$label} is required.";
            return $this;
        }

        if (strlen($value) < 2) {
            $this->errors[$field] = "{$label} must be at least 2 characters.";
            return $this;
        }

        if (strlen($value) > 100) {
            $this->errors[$field] = "{$label} must not exceed 100 characters.";
            return $this;
        }

        if (preg_match('/\d/', $value)) {
            $this->errors[$field] = "{$label} should not contain numbers.";
            return $this;
        }

        if (!preg_match('/[a-zA-Z]{2,}/', $value)) {
            $this->errors[$field] = "{$label} must contain at least 2 letters.";
            return $this;
        }

        if (preg_match('/[!@#$%^&*()_+=\[\]{}|;:",.<>?\/\\\\]{3,}/', $value)) {
            $this->errors[$field] = "{$label} contains too many special characters.";
            return $this;
        }

        if (preg_match('/^[A-Z]{4,}$/', $value) && !preg_match('/[aeiou]/i', $value)) {
            $this->errors[$field] = "{$label} doesn't look like a real name. Please enter your actual name.";
            return $this;
        }

        return $this;
    }

    /**
     * Validate phone number – Ghana format
     */
    public function validatePhone($field, $label = 'Phone Number') {
        $value = trim($this->data[$field] ?? '');
        
        if (empty($value)) {
            $this->errors[$field] = "{$label} is required.";
            return $this;
        }

        $clean = preg_replace('/[\s\-\+]/', '', $value);

        if (preg_match('/^(0[2-9]\d{8})$/', $clean)) {
            return $this;
        } elseif (preg_match('/^(233[2-9]\d{8})$/', $clean)) {
            return $this;
        } elseif (preg_match('/^\+233[2-9]\d{8}$/', $clean)) {
            return $this;
        } else {
            $this->errors[$field] = "Please enter a valid phone number (e.g., 0244XXXXXX or +233XXXXXXXXX).";
        }

        return $this;
    }

    /**
     * Validate email – format + reject temporary domains
     */
    public function validateEmail($field, $label = 'Email') {
        $value = trim($this->data[$field] ?? '');
        
        if (empty($value)) {
            return $this; // optional field
        }

        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field] = "Please enter a valid {$label} address.";
            return $this;
        }

        $disposable = ['mailinator.com', 'guerrillamail.com', 'tempmail.com', '10minutemail.com', 'yopmail.com'];
        $domain = substr(strrchr($value, "@"), 1);
        if (in_array(strtolower($domain), $disposable)) {
            $this->errors[$field] = "Please use a valid email address, not a temporary one.";
        }

        return $this;
    }

    /**
     * Validate required email
     */
    public function validateRequiredEmail($field, $label = 'Email') {
        $value = trim($this->data[$field] ?? '');
        
        if (empty($value)) {
            $this->errors[$field] = "{$label} is required.";
            return $this;
        }

        return $this->validateEmail($field, $label);
    }

    /**
     * Validate date – cannot be in the future, not older than 1 year
     */
    public function validateDateNotFuture($field, $label = 'Date') {
        $value = trim($this->data[$field] ?? '');
        
        if (empty($value)) {
            $this->errors[$field] = "{$label} is required.";
            return $this;
        }

        $date = DateTime::createFromFormat('Y-m-d', $value);
        if (!$date || $date->format('Y-m-d') !== $value) {
            $this->errors[$field] = "Please enter a valid date.";
            return $this;
        }

        $today = new DateTime('today');
        if ($date > $today) {
            $this->errors[$field] = "{$label} cannot be in the future.";
            return $this;
        }

        $oneYearAgo = new DateTime('-1 year');
        if ($date < $oneYearAgo) {
            $this->errors[$field] = "{$label} cannot be more than 1 year ago. Please contact the office directly for older items.";
            return $this;
        }

        return $this;
    }

    /**
     * Validate category – must be from dropdown list
     */
    public function validateCategory($field, $label = 'Category') {
        $value = trim($this->data[$field] ?? '');
        $allowed = ['Electronics', 'Clothing', 'Books', 'ID Cards', 'Keys', 'Bags', 'Jewelry', 'Water Bottle', 'Other'];
        
        if (empty($value)) {
            $this->errors[$field] = "{$label} is required.";
            return $this;
        }

        if (!in_array($value, $allowed)) {
            $this->errors[$field] = "Please select a valid category.";
            return $this;
        }

        return $this;
    }

    /**
     * Validate color – must be from dropdown
     */
    public function validateColor($field, $label = 'Color') {
        $value = trim($this->data[$field] ?? '');
        
        if (empty($value)) {
            return $this; // optional
        }

        $allowed = ['Black', 'White', 'Silver', 'Gray', 'Red', 'Blue', 'Green', 'Yellow', 'Orange', 'Purple', 'Pink', 'Brown', 'Gold', 'Navy', 'Beige', 'Maroon', 'Other'];
        
        if (!in_array($value, $allowed)) {
            $this->errors[$field] = "Please select a valid color from the list.";
            return $this;
        }

        return $this;
    }

    /**
     * Validate description – minimum length and must contain actual words
     */
    public function validateDescription($field, $label = 'Description') {
        $value = trim($this->data[$field] ?? '');
        
        if (empty($value)) {
            return $this; // optional
        }

        if (strlen($value) < 5) {
            $this->errors[$field] = "{$label} must be at least 5 characters if provided.";
            return $this;
        }

        if (preg_match('/^[^a-zA-Z]*$/', $value) && strlen($value) > 10) {
            $this->errors[$field] = "{$label} must contain actual words, not just random characters.";
            return $this;
        }

        return $this;
    }

    /**
     * Validate ownership evidence – must be meaningful
     */
    public function validateEvidence($field, $label = 'Evidence') {
        $value = trim($this->data[$field] ?? '');
        
        if (empty($value)) {
            $this->errors[$field] = "{$label} is required.";
            return $this;
        }

        if (strlen($value) < 10) {
            $this->errors[$field] = "{$label} must be at least 10 characters. Please provide detailed proof of ownership.";
            return $this;
        }

        if (strlen($value) > 5000) {
            $this->errors[$field] = "{$label} must not exceed 5000 characters.";
            return $this;
        }

        $letterCount = preg_match_all('/[a-zA-Z]/', $value);
        if ($letterCount < 5) {
            $this->errors[$field] = "{$label} must contain actual words describing your proof.";
            return $this;
        }

        return $this;
    }

    /**
     * Validate student ID – must be 3–30 alphanumeric characters
     */
    public function validateStudentId($field, $label = 'Student ID') {
        $value = trim($this->data[$field] ?? '');
        
        if (empty($value)) {
            return $this; // optional
        }

        if (strlen($value) < 3) {
            $this->errors[$field] = "{$label} must be at least 3 characters.";
            return $this;
        }

        if (strlen($value) > 30) {
            $this->errors[$field] = "{$label} must not exceed 30 characters.";
            return $this;
        }

        if (!preg_match('/[a-zA-Z0-9]/', $value)) {
            $this->errors[$field] = "{$label} must contain letters or numbers.";
            return $this;
        }

        return $this;
    }

    /**
     * Get all errors
     */
    public function getErrors() {
        return $this->errors;
    }

    /**
     * Get first error message
     */
    public function getFirstError() {
        return !empty($this->errors) ? reset($this->errors) : '';
    }

    /**
     * Check if validation passed
     */
    public function passes() {
        return empty($this->errors);
    }

    /**
     * Check if validation failed
     */
    public function fails() {
        return !empty($this->errors);
    }

    /**
     * Get error for a specific field (useful for inline display)
     */
    public function error($field) {
        return $this->errors[$field] ?? '';
    }
}