<?php
require_once __DIR__ . '/../config/init.php';
$db = getDB();

// Fetch recent items
$recentFound = $db->query("SELECT * FROM found_items WHERE status IN ('found', 'unclaimed') ORDER BY created_at DESC LIMIT 6")->fetchAll();
$recentLost = $db->query("SELECT * FROM lost_items WHERE status = 'lost' ORDER BY created_at DESC LIMIT 6")->fetchAll();

// Stats
$totalResolved = $db->query("SELECT COUNT(*) FROM lost_items WHERE status = 'resolved'")->fetchColumn();
$totalLost = $db->query("SELECT COUNT(*) FROM lost_items")->fetchColumn();
$totalFound = $db->query("SELECT COUNT(*) FROM found_items")->fetchColumn();
$totalMatches = $db->query("SELECT COUNT(*) FROM matches WHERE status = 'approved'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Returnify - University Lost & Found System</title>
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #2563EB;
            --primary-dark: #1D4ED8;
            --primary-light: #3B82F6;
            --secondary: #0EA5E9;
            --success: #10B981;
            --danger: #EF4444;
            --warning: #F59E0B;
            --purple: #8B5CF6;
            --pink: #EC4899;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            background: #f0f4ff;
            color: #1e293b;
            overflow-x: hidden;
            transition: all 0.3s ease;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        [data-bs-theme="dark"] body {
            background: #0a0e1a;
            color: #e2e8f0;
        }

        /* ============ ANIMATED BACKGROUND ============ */
        .bg-animation {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            pointer-events: none; z-index: 0; overflow: hidden;
        }
        .bg-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.3;
            animation: blobFloat 20s infinite ease-in-out;
        }
        .bg-blob:nth-child(1) {
            width: 600px; height: 600px;
            background: #2563EB;
            top: -200px; left: -100px;
            animation-delay: 0s;
        }
        .bg-blob:nth-child(2) {
            width: 500px; height: 500px;
            background: #8B5CF6;
            top: 50%; right: -200px;
            animation-delay: -5s;
        }
        .bg-blob:nth-child(3) {
            width: 400px; height: 400px;
            background: #10B981;
            bottom: -100px; left: 40%;
            animation-delay: -10s;
        }
        .bg-blob:nth-child(4) {
            width: 350px; height: 350px;
            background: #F59E0B;
            top: 30%; left: 30%;
            animation-delay: -15s;
        }

        @keyframes blobFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            25% { transform: translate(100px, -50px) scale(1.1); }
            50% { transform: translate(-50px, 100px) scale(0.9); }
            75% { transform: translate(-100px, -100px) scale(1.05); }
        }

        [data-bs-theme="dark"] .bg-blob { opacity: 0.15; }

        /* ============ NAVBAR ============ */
        .navbar {
            position: fixed;
            top: 15px;
            left: 50%;
            transform: translateX(-50%);
            width: 92%;
            max-width: 1200px;
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 20px;
            padding: 12px 20px;
            z-index: 1000;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.06);
            transition: all 0.3s ease;
        }

        [data-bs-theme="dark"] .navbar {
            background: rgba(15, 23, 42, 0.75);
            border-color: rgba(255, 255, 255, 0.08);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .navbar.scrolled {
            top: 0;
            width: 100%;
            max-width: 100%;
            border-radius: 0;
            background: rgba(255, 255, 255, 0.9);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        [data-bs-theme="dark"] .navbar.scrolled {
            background: rgba(15, 23, 42, 0.9);
        }

        .navbar-brand {
            font-size: 1.25rem;
            font-weight: 800;
            background: linear-gradient(135deg, #2563EB, #8B5CF6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            letter-spacing: -0.5px;
            text-decoration: none;
            white-space: nowrap;
        }

        .navbar-brand i {
            background: linear-gradient(135deg, #2563EB, #0EA5E9);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-size: 1.3rem;
            margin-right: 4px;
        }

        /* Hamburger Toggler */
        .navbar-toggler {
            border: none !important;
            padding: 8px;
            border-radius: 10px;
            background: rgba(37, 99, 235, 0.08);
            box-shadow: none !important;
        }

        .navbar-toggler:focus {
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15) !important;
        }

        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(37, 99, 235, 1)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e") !important;
        }

        [data-bs-theme="dark"] .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(148, 163, 184, 1)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e") !important;
        }

        /* Mobile Nav */
        @media (max-width: 991px) {
            .navbar-collapse {
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(20px);
                -webkit-backdrop-filter: blur(20px);
                border-radius: 16px;
                padding: 16px;
                margin-top: 12px;
                border: 1px solid rgba(255, 255, 255, 0.3);
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                max-height: 80vh;
                overflow-y: auto;
            }
            [data-bs-theme="dark"] .navbar-collapse {
                background: rgba(15, 23, 42, 0.95);
                border-color: rgba(255, 255, 255, 0.08);
            }
        }

        .nav-link {
            color: #64748b !important;
            font-weight: 500;
            font-size: 0.9rem;
            padding: 10px 16px !important;
            border-radius: 12px;
            transition: all 0.3s ease;
            white-space: nowrap;
        }

        .nav-link:hover, .nav-link.active {
            color: #2563EB !important;
            background: rgba(37, 99, 235, 0.08);
        }

        [data-bs-theme="dark"] .nav-link {
            color: #94a3b8 !important;
        }

        [data-bs-theme="dark"] .nav-link:hover {
            color: #60A5FA !important;
            background: rgba(96, 165, 250, 0.1);
        }

        .btn-admin {
            background: linear-gradient(135deg, #2563EB, #8B5CF6);
            color: #fff !important;
            border: none;
            padding: 8px 20px !important;
            border-radius: 12px;
            font-weight: 600;
            font-size: 0.85rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(37, 99, 235, 0.25);
            text-decoration: none;
            white-space: nowrap;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-admin:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(37, 99, 235, 0.4);
            color: #fff !important;
        }

        .theme-btn {
            width: 40px; height: 40px; min-width: 40px;
            border-radius: 12px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            background: rgba(255, 255, 255, 0.5);
            color: #64748b;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
        }

        [data-bs-theme="dark"] .theme-btn {
            border-color: rgba(255, 255, 255, 0.1);
            background: rgba(255, 255, 255, 0.05);
            color: #e2e8f0;
        }

        .theme-btn:hover {
            background: rgba(37, 99, 235, 0.1);
            color: #2563EB;
        }

        /* Mobile Nav Actions */
        .nav-actions {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        @media (max-width: 991px) {
            .nav-actions {
                flex-direction: column;
                width: 100%;
                margin-top: 12px;
                gap: 10px;
            }
            .nav-actions .btn-admin {
                width: 100%;
                justify-content: center;
                padding: 12px !important;
            }
            .nav-actions .theme-btn {
                width: 100%;
            }
            .navbar-nav {
                gap: 4px !important;
            }
        }

        /* ============ HERO SECTION ============ */
        .hero {
            position: relative;
            z-index: 1;
            padding: 140px 0 60px;
            text-align: center;
        }

        .hero-badge {
            display: inline-block;
            background: rgba(37, 99, 235, 0.1);
            color: #2563EB;
            padding: 8px 20px;
            border-radius: 50px;
            font-weight: 600;
            font-size: 0.85rem;
            margin-bottom: 24px;
            border: 1px solid rgba(37, 99, 235, 0.2);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
        }

        [data-bs-theme="dark"] .hero-badge {
            background: rgba(96, 165, 250, 0.1);
            color: #60A5FA;
            border-color: rgba(96, 165, 250, 0.2);
        }

        .hero h1 {
            font-size: clamp(2rem, 5vw, 4.5rem);
            font-weight: 900;
            letter-spacing: -1.5px;
            line-height: 1.15;
            margin-bottom: 20px;
        }

        .hero h1 .line-one {
            display: block;
            color: #1e293b;
        }

        .hero h1 .highlight {
            display: block;
            background: linear-gradient(135deg, #2563EB, #8B5CF6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        [data-bs-theme="dark"] .hero h1 .line-one {
            color: #f1f5f9;
        }

        .hero p {
            font-size: clamp(1rem, 2vw, 1.2rem);
            color: #64748b;
            max-width: 600px;
            margin: 0 auto 32px;
            line-height: 1.7;
            padding: 0 16px;
        }

        [data-bs-theme="dark"] .hero p {
            color: #94a3b8;
        }

        .hero-buttons {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
            padding: 0 16px;
        }

        .btn-hero-primary {
            background: linear-gradient(135deg, #2563EB, #8B5CF6);
            color: #fff;
            padding: 14px 28px;
            border-radius: 16px;
            font-weight: 700;
            font-size: 0.95rem;
            border: none;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 8px 30px rgba(37, 99, 235, 0.3);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            white-space: nowrap;
        }

        .btn-hero-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(37, 99, 235, 0.45);
            color: #fff;
        }

        .btn-hero-secondary {
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            color: #2563EB;
            padding: 14px 28px;
            border-radius: 16px;
            font-weight: 700;
            font-size: 0.95rem;
            border: 2px solid rgba(37, 99, 235, 0.3);
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            white-space: nowrap;
        }

        [data-bs-theme="dark"] .btn-hero-secondary {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(96, 165, 250, 0.3);
            color: #60A5FA;
        }

        .btn-hero-secondary:hover {
            background: rgba(37, 99, 235, 0.1);
            border-color: #2563EB;
            transform: translateY(-3px);
            color: #2563EB;
        }

        /* Stats Grid */
        .hero-stats {
            display: flex;
            gap: 24px;
            justify-content: center;
            margin-top: 48px;
            flex-wrap: wrap;
            padding: 0 16px;
        }

        .hero-stat {
            background: rgba(255, 255, 255, 0.6);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.4);
            border-radius: 16px;
            padding: 20px 24px;
            min-width: 120px;
            flex: 1;
            max-width: 160px;
            text-align: center;
        }

        [data-bs-theme="dark"] .hero-stat {
            background: rgba(30, 41, 59, 0.6);
            border-color: rgba(255, 255, 255, 0.06);
        }

        .hero-stat-number {
            font-size: clamp(1.5rem, 3vw, 2rem);
            font-weight: 800;
            background: linear-gradient(135deg, #2563EB, #0EA5E9);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .hero-stat-label {
            font-size: 0.75rem;
            color: #64748b;
            font-weight: 500;
            margin-top: 4px;
        }

        [data-bs-theme="dark"] .hero-stat-label {
            color: #94a3b8;
        }

        /* ============ SECTIONS ============ */
        .section {
            position: relative;
            z-index: 1;
            padding: 60px 0;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 32px;
            flex-wrap: wrap;
            gap: 16px;
        }

        .section-title {
            font-size: clamp(1.4rem, 3vw, 1.8rem);
            font-weight: 800;
            letter-spacing: -0.5px;
            margin-bottom: 4px;
        }

        .section-subtitle {
            color: #64748b;
            font-size: 0.9rem;
        }

        [data-bs-theme="dark"] .section-subtitle {
            color: #94a3b8;
        }

        .btn-section-link {
            background: rgba(255, 255, 255, 0.6);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(37, 99, 235, 0.2);
            color: #2563EB;
            padding: 10px 20px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 0.85rem;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            white-space: nowrap;
            transition: all 0.3s ease;
        }

        [data-bs-theme="dark"] .btn-section-link {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(96, 165, 250, 0.2);
            color: #60A5FA;
        }

        .btn-section-link:hover {
            background: rgba(37, 99, 235, 0.1);
            transform: translateY(-2px);
            color: #2563EB;
        }

        /* ============ GLASS CARDS ============ */
        .glass-card {
            background: rgba(255, 255, 255, 0.55);
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.5);
            border-radius: 20px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
            transition: all 0.3s ease;
        }

        [data-bs-theme="dark"] .glass-card {
            background: rgba(30, 41, 59, 0.55);
            border-color: rgba(255, 255, 255, 0.06);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }

        .glass-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.08);
        }

        [data-bs-theme="dark"] .glass-card:hover {
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
        }

        /* Step Cards */
        .step-card {
            text-align: center;
            padding: 32px 20px;
            height: 100%;
        }

        .step-icon {
            width: 64px; height: 64px;
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            font-size: 26px;
            transition: all 0.3s ease;
        }

        @media (min-width: 768px) {
            .step-icon {
                width: 80px; height: 80px;
                border-radius: 24px;
                font-size: 32px;
            }
        }

        .step-icon.blue {
            background: linear-gradient(135deg, rgba(37, 99, 235, 0.15), rgba(14, 165, 233, 0.15));
            color: #2563EB;
        }

        .step-icon.purple {
            background: linear-gradient(135deg, rgba(139, 92, 246, 0.15), rgba(236, 72, 153, 0.15));
            color: #8B5CF6;
        }

        .step-icon.green {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.15), rgba(14, 165, 233, 0.15));
            color: #10B981;
        }

        .step-card h5 {
            font-weight: 700;
            font-size: 1.05rem;
            margin-bottom: 8px;
        }

        .step-card p {
            color: #64748b;
            font-size: 0.9rem;
            line-height: 1.6;
            margin: 0;
        }

        /* Item Cards */
        .item-card {
            padding: 0;
            overflow: hidden;
            height: 100%;
        }

        .item-card-image {
            width: 100%;
            height: 160px;
            object-fit: cover;
            background: linear-gradient(135deg, #f1f5f9, #e2e8f0);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #94a3b8;
            font-size: 40px;
        }

        @media (min-width: 768px) {
            .item-card-image {
                height: 200px;
            }
        }

        [data-bs-theme="dark"] .item-card-image {
            background: linear-gradient(135deg, #1e293b, #334155);
        }

        .item-card-body {
            padding: 14px;
        }

        @media (min-width: 768px) {
            .item-card-body {
                padding: 18px;
            }
        }

        .item-card-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .item-card-badge.lost {
            background: rgba(239, 68, 68, 0.1);
            color: #EF4444;
        }

        .item-card-badge.found {
            background: rgba(16, 185, 129, 0.1);
            color: #10B981;
        }

        .item-card h6 {
            font-weight: 700;
            font-size: 0.95rem;
            margin-bottom: 6px;
        }

        .item-card .meta {
            font-size: 0.78rem;
            color: #94a3b8;
            display: flex;
            align-items: center;
            gap: 4px;
            margin-bottom: 3px;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
        }

        .empty-state i {
            font-size: 40px;
            color: #94a3b8;
            opacity: 0.5;
            margin-bottom: 12px;
        }

        .empty-state p {
            color: #94a3b8;
            margin: 0;
        }

        /* ============ CTA SECTION ============ */
        .cta-section {
            position: relative;
            z-index: 1;
            padding: 60px 16px;
            text-align: center;
        }

        .cta-card {
            background: linear-gradient(135deg, #2563EB, #8B5CF6);
            border-radius: 24px;
            padding: 40px 24px;
            color: #fff;
            position: relative;
            overflow: hidden;
        }

        @media (min-width: 768px) {
            .cta-card {
                border-radius: 32px;
                padding: 60px 40px;
            }
        }

        .cta-card::before {
            content: '';
            position: absolute;
            top: -50%; left: -50%;
            width: 200%; height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: ctaGlow 8s infinite;
        }

        @keyframes ctaGlow {
            0%, 100% { transform: translate(0, 0); }
            50% { transform: translate(50px, 50px); }
        }

        .cta-card h3 {
            font-size: clamp(1.4rem, 3vw, 2rem);
            font-weight: 800;
            position: relative;
            z-index: 1;
            margin-bottom: 12px;
        }

        .cta-card p {
            font-size: 0.95rem;
            opacity: 0.9;
            position: relative;
            z-index: 1;
            margin-bottom: 24px;
        }

        .btn-cta {
            background: #fff;
            color: #2563EB;
            padding: 12px 28px;
            border-radius: 14px;
            font-weight: 700;
            font-size: 0.95rem;
            text-decoration: none;
            display: inline-block;
            position: relative;
            z-index: 1;
            transition: all 0.3s ease;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
        }

        .btn-cta:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.25);
            color: #1D4ED8;
        }

        /* ============ FOOTER ============ */
        .footer {
            position: relative;
            z-index: 1;
            background: rgba(255, 255, 255, 0.5);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            padding: 20px 16px;
            text-align: center;
            font-size: 0.85rem;
            color: #64748b;
        }

        [data-bs-theme="dark"] .footer {
            background: rgba(15, 23, 42, 0.5);
            border-color: rgba(255, 255, 255, 0.05);
            color: #94a3b8;
        }

        .footer .brand {
            font-weight: 700;
            background: linear-gradient(135deg, #2563EB, #8B5CF6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        /* ============ RESPONSIVE BREAKPOINTS ============ */

        /* Small phones: 320px - 480px */
        @media (max-width: 480px) {
            .navbar {
                width: 95%;
                top: 8px;
                padding: 10px 14px;
                border-radius: 16px;
            }
            .navbar-brand {
                font-size: 1.1rem;
            }
            .hero {
                padding: 110px 0 40px;
            }
            .hero h1 {
                font-size: 1.6rem;
                letter-spacing: -0.5px;
            }
            .hero p {
                font-size: 0.9rem;
            }
            .hero-buttons {
                flex-direction: column;
                align-items: stretch;
                gap: 10px;
            }
            .btn-hero-primary, .btn-hero-secondary {
                justify-content: center;
                padding: 14px 20px;
                font-size: 0.9rem;
            }
            .hero-stats {
                gap: 10px;
                margin-top: 32px;
            }
            .hero-stat {
                min-width: 70px;
                flex: 1 1 40%;
                max-width: none;
                padding: 14px 10px;
                border-radius: 12px;
            }
            .hero-stat-number {
                font-size: 1.3rem;
            }
            .hero-stat-label {
                font-size: 0.7rem;
            }
            .section {
                padding: 40px 0;
            }
            .section-header {
                flex-direction: column;
                gap: 12px;
            }
            .btn-section-link {
                width: 100%;
                justify-content: center;
            }
            .item-card-image {
                height: 140px;
            }
            .cta-card {
                padding: 30px 16px;
                border-radius: 20px;
            }
        }

        /* Medium phones / Small tablets: 481px - 768px */
        @media (min-width: 481px) and (max-width: 768px) {
            .hero h1 {
                font-size: 2rem;
            }
            .hero-stats {
                gap: 14px;
            }
            .hero-stat {
                min-width: 100px;
                flex: 1 1 30%;
                max-width: none;
            }
        }

        /* Tablets: 769px - 1024px */
        @media (min-width: 769px) and (max-width: 1024px) {
            .hero {
                padding: 150px 0 70px;
            }
            .hero h1 {
                font-size: 2.8rem;
            }
            .hero-stat {
                max-width: 150px;
            }
        }

        /* Desktop: 1025px+ */
        @media (min-width: 1025px) {
            .hero {
                padding: 160px 0 80px;
            }
            .hero h1 {
                font-size: 4rem;
                letter-spacing: -2px;
            }
            .hero-stat {
                max-width: 160px;
            }
            .section {
                padding: 80px 0;
            }
        }

        /* Touch device optimizations */
        @media (hover: none) and (pointer: coarse) {
            .glass-card:hover {
                transform: none;
            }
            .btn-hero-primary:hover, .btn-hero-secondary:hover {
                transform: none;
            }
        }
    </style>
</head>
<body>

    <!-- Animated Background Blobs -->
    <div class="bg-animation">
        <div class="bg-blob"></div>
        <div class="bg-blob"></div>
        <div class="bg-blob"></div>
        <div class="bg-blob"></div>
    </div>

    <!-- Glass Navbar -->
    <nav class="navbar navbar-expand-lg" id="navbar">
        <div class="container-fluid px-0">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-search-location"></i> Returnify
            </a>
            <div class="d-flex align-items-center gap-2 d-lg-none">
                <button class="theme-btn" onclick="toggleTheme()" title="Toggle Theme" aria-label="Toggle theme">
                    <i class="fas fa-moon" id="themeIconMobile"></i>
                </button>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto gap-1">
                    <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="found-items.php">Browse Items</a></li>
                    <li class="nav-item"><a class="nav-link" href="report-lost.php">Report Lost</a></li>
                    <li class="nav-item"><a class="nav-link" href="report-found.php">Report Found</a></li>
                    <li class="nav-item"><a class="nav-link" href="track-claim.php">Track Claim</a></li>
                </ul>
                <!-- Desktop Actions -->
                <div class="nav-actions d-none d-lg-flex">
                    <button class="theme-btn" onclick="toggleTheme()" title="Toggle Theme" aria-label="Toggle theme">
                        <i class="fas fa-moon" id="themeIcon"></i>
                    </button>
                    <a href="../auth/login.php" class="btn-admin">
                        <i class="fas fa-lock"></i> Admin
                    </a>
                </div>
                <!-- Mobile Actions -->
                <div class="nav-actions d-lg-none">
                    <a href="../auth/login.php" class="btn-admin">
                        <i class="fas fa-lock"></i> Admin Panel
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <span class="hero-badge">
                <i class="fas fa-sparkles me-1"></i>AI-Powered Item Recovery
            </span>
            <h1>
                <span class="line-one">Lost Something?</span>
                <span class="highlight">We'll Find It Fast.</span>
            </h1>
            <p>
                Our intelligent system automatically matches lost items with found ones across campus. 
                Report, match, and recover your belongings in minutes.
            </p>
            <div class="hero-buttons">
                <a href="report-lost.php" class="btn-hero-primary">
                    <i class="fas fa-box-open"></i> I Lost an Item
                </a>
                <a href="report-found.php" class="btn-hero-secondary">
                    <i class="fas fa-hand-holding-heart"></i> I Found an Item
                </a>
            </div>
            <div class="hero-stats">
                <div class="hero-stat">
                    <div class="hero-stat-number" id="statResolved">0</div>
                    <div class="hero-stat-label">Recovered</div>
                </div>
                <div class="hero-stat">
                    <div class="hero-stat-number" id="statLost">0</div>
                    <div class="hero-stat-label">Lost Items</div>
                </div>
                <div class="hero-stat">
                    <div class="hero-stat-number" id="statFound">0</div>
                    <div class="hero-stat-label">Found Items</div>
                </div>
                <div class="hero-stat">
                    <div class="hero-stat-number" id="statMatches">0</div>
                    <div class="hero-stat-label">Matches</div>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works -->
    <section class="section" style="padding-top: 0;">
        <div class="container">
            <h2 class="section-title text-center mb-2">How It Works</h2>
            <p class="section-subtitle text-center mb-4">Three simple steps to recover your lost items</p>
            <div class="row g-3">
                <div class="col-sm-6 col-lg-4">
                    <div class="glass-card step-card">
                        <div class="step-icon blue">
                            <i class="fas fa-clipboard-list"></i>
                        </div>
                        <h5>1. Report Item</h5>
                        <p>Tell us what you lost or found with details and a photo.</p>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="glass-card step-card">
                        <div class="step-icon purple">
                            <i class="fas fa-magic"></i>
                        </div>
                        <h5>2. Smart Matching</h5>
                        <p>Our AI finds potential matches between lost & found items.</p>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="glass-card step-card">
                        <div class="step-icon green">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <h5>3. Claim & Collect</h5>
                        <p>Verify ownership & collect your item from the office.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Recent Lost Items -->
    <section class="section" style="padding-top: 0;">
        <div class="container">
            <div class="section-header">
                <div>
                    <h3 class="section-title">
                        <i class="fas fa-box-open text-danger me-2"></i>Recently Lost
                    </h3>
                    <p class="section-subtitle mb-0">Items reported missing on campus</p>
                </div>
                <a href="report-lost.php" class="btn-section-link">
                    Report Lost <i class="fas fa-arrow-right ms-1"></i>
                </a>
            </div>
            <div class="row g-3">
                <?php if (empty($recentLost)): ?>
                    <div class="col-12">
                        <div class="glass-card empty-state">
                            <i class="fas fa-box-open"></i>
                            <p>No lost items reported yet. Be the first to report!</p>
                        </div>
                    </div>
                <?php endif; ?>
                <?php foreach ($recentLost as $item): ?>
                <div class="col-sm-6 col-lg-4">
                    <div class="glass-card item-card">
                        <?php if ($item['image']): ?>
                            <img src="../assets/uploads/lost/<?= htmlspecialchars($item['image']) ?>" class="item-card-image" alt="<?= htmlspecialchars($item['item_name']) ?>" loading="lazy">
                        <?php else: ?>
                            <div class="item-card-image">
                                <i class="fas fa-box-open"></i>
                            </div>
                        <?php endif; ?>
                        <div class="item-card-body">
                            <span class="item-card-badge lost">Lost</span>
                            <h6><?= htmlspecialchars($item['item_name']) ?></h6>
                            <div class="meta"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($item['location_lost']) ?></div>
                            <div class="meta"><i class="fas fa-calendar"></i> <?= date('M d, Y', strtotime($item['date_lost'])) ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Recent Found Items -->
    <section class="section" style="padding-top: 0;">
        <div class="container">
            <div class="section-header">
                <div>
                    <h3 class="section-title">
                        <i class="fas fa-hand-holding-heart text-success me-2"></i>Recently Found
                    </h3>
                    <p class="section-subtitle mb-0">Items waiting for their owners</p>
                </div>
                <a href="found-items.php" class="btn-section-link">
                    View All <i class="fas fa-arrow-right ms-1"></i>
                </a>
            </div>
            <div class="row g-3">
                <?php if (empty($recentFound)): ?>
                    <div class="col-12">
                        <div class="glass-card empty-state">
                            <i class="fas fa-hand-holding-heart"></i>
                            <p>No found items yet. Found something? Report it!</p>
                        </div>
                    </div>
                <?php endif; ?>
                <?php foreach ($recentFound as $item): ?>
                <div class="col-sm-6 col-lg-4">
                    <div class="glass-card item-card">
                        <?php if ($item['image']): ?>
                            <img src="../assets/uploads/found/<?= htmlspecialchars($item['image']) ?>" class="item-card-image" alt="<?= htmlspecialchars($item['item_name']) ?>" loading="lazy">
                        <?php else: ?>
                            <div class="item-card-image">
                                <i class="fas fa-box-open"></i>
                            </div>
                        <?php endif; ?>
                        <div class="item-card-body">
                            <span class="item-card-badge found">Found</span>
                            <h6><?= htmlspecialchars($item['item_name']) ?></h6>
                            <div class="meta"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($item['location_found']) ?></div>
                            <div class="meta"><i class="fas fa-calendar"></i> <?= date('M d, Y', strtotime($item['date_found'])) ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="container">
            <div class="cta-card">
                <h3>Ready to Find Your Lost Item?</h3>
                <p>Join hundreds of students who have recovered their belongings.</p>
                <a href="report-lost.php" class="btn-cta">
                    <i class="fas fa-search me-2"></i>Report Lost Item Now
                </a>
            </div>
        </div>
    </section>
    <?php $db = getDB(); include '../includes/ads-banner.php'; ?>
    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p class="mb-1"><span class="brand"><i class="fas fa-search-location me-1"></i>Returnify</span></p>
            <p class="mb-0 small">&copy; <?= date('Y') ?> University Lost & Found System</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ============ THEME TOGGLE ============
        function toggleTheme() {
            var html = document.documentElement;
            var icons = document.querySelectorAll('#themeIcon, #themeIconMobile');
            var isDark = html.getAttribute('data-bs-theme') === 'dark';
            
            if (isDark) {
                html.setAttribute('data-bs-theme', 'light');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-moon'; });
                localStorage.setItem('theme', 'light');
            } else {
                html.setAttribute('data-bs-theme', 'dark');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-sun'; });
                localStorage.setItem('theme', 'dark');
            }
        }

        // Init Theme
        (function() {
            var saved = localStorage.getItem('theme');
            var prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            var icons = document.querySelectorAll('#themeIcon, #themeIconMobile');
            if (saved === 'dark' || (!saved && prefersDark)) {
                document.documentElement.setAttribute('data-bs-theme', 'dark');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-sun'; });
            }
        })();

        // ============ NAVBAR SCROLL EFFECT ============
        var navbar = document.getElementById('navbar');
        var lastScroll = 0;
        
        window.addEventListener('scroll', function() {
            var currentScroll = window.pageYOffset;
            if (currentScroll > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
            lastScroll = currentScroll;
        });

        // ============ ANIMATED COUNTERS ============
        function animateCounter(id, target) {
            var el = document.getElementById(id);
            if (!el || target === 0) {
                if (el) el.textContent = '0';
                return;
            }
            var duration = 2000;
            var start = performance.now();
            
            function update(now) {
                var elapsed = now - start;
                var progress = Math.min(elapsed / duration, 1);
                var easeOut = 1 - Math.pow(1 - progress, 3);
                el.textContent = Math.round(target * easeOut);
                if (progress < 1) {
                    requestAnimationFrame(update);
                }
            }
            requestAnimationFrame(update);
        }

        // Start counters
        var countersStarted = false;
        var heroStats = document.querySelector('.hero-stats');
        
        function startCounters() {
            if (countersStarted) return;
            countersStarted = true;
            animateCounter('statResolved', <?= (int)$totalResolved ?>);
            animateCounter('statLost', <?= (int)$totalLost ?>);
            animateCounter('statFound', <?= (int)$totalFound ?>);
            animateCounter('statMatches', <?= (int)$totalMatches ?>);
        }

        // Use Intersection Observer
        if ('IntersectionObserver' in window && heroStats) {
            var observer = new IntersectionObserver(function(entries) {
                if (entries[0].isIntersecting) {
                    startCounters();
                    observer.disconnect();
                }
            }, { threshold: 0.3 });
            observer.observe(heroStats);
        }
        
        // Fallback
        setTimeout(startCounters, 300);

        // ============ CLOSE MOBILE MENU ON LINK CLICK ============
        document.querySelectorAll('.navbar-nav .nav-link').forEach(function(link) {
            link.addEventListener('click', function() {
                var navbarCollapse = document.getElementById('navbarNav');
                if (navbarCollapse.classList.contains('show')) {
                    var bsCollapse = bootstrap.Collapse.getInstance(navbarCollapse);
                    if (bsCollapse) bsCollapse.hide();
                }
            });
        });
    </script>
</body>
</html>