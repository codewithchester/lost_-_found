<?php
require_once __DIR__ . '/../config/init.php';
$db = getDB();

$foundId = (int)($_GET['id'] ?? 0);
$item = $db->prepare("SELECT * FROM found_items WHERE id = :id");
$item->execute([':id' => $foundId]);
$item = $item->fetch();

if (!$item) {
    header('Location: found-items.php');
    exit;
}

$errors = [];
$formData = $_POST; // Preserve entered values after error

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate all fields using the Validator class (already in models/)
    $validator = new Validator($_POST);

    $validator->validatePersonName('full_name', 'Full Name')
              ->validateStudentId('student_id', 'Student/Staff ID')
              ->validatePhone('contact_number', 'Phone Number')
              ->validateEmail('email', 'Email')
              ->validateEvidence('ownership_evidence', 'Ownership Evidence');

    $errors = $validator->getErrors();

    // If no validation errors, insert the claim
    if (empty($errors)) {
        $claimIdStr = 'CLM-' . date('Ymd') . '-' . rand(1000, 9999);

        $matchStmt = $db->prepare("SELECT lost_item_id FROM matches WHERE found_item_id = :fid AND status = 'approved' LIMIT 1");
        $matchStmt->execute([':fid' => $foundId]);
        $matchId = $matchStmt->fetchColumn();

        $stmt = $db->prepare("
            INSERT INTO claims (claim_id, lost_item_id, match_id, claimed_by, student_id, contact_number, email, ownership_evidence, additional_notes)
            VALUES (:cid, :lid, :mid, :name, :sid, :contact, :email, :evidence, :notes)
        ");
        $stmt->execute([
            ':cid'      => $claimIdStr,
            ':lid'      => null,
            ':mid'      => $matchId ?: null,
            ':name'     => sanitize($_POST['full_name']),
            ':sid'      => sanitize($_POST['student_id'] ?? ''),
            ':contact'  => sanitize($_POST['contact_number']),
            ':email'    => sanitize($_POST['email'] ?? ''),
            ':evidence' => sanitize($_POST['ownership_evidence']),
            ':notes'    => sanitize($_POST['additional_notes'] ?? '')
        ]);

        $notif = new Notification();
        $notif->create('claim_submitted', 'New Claim', "{$claimIdStr} - Someone claims {$item['item_name']}");

        // Redirect to payment page
        header('Location: pay-claim.php?claim_id=' . urlencode($claimIdStr));
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Claim Item - Returnify</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    
    <style>
        :root { --primary: #2563EB; --purple: #8B5CF6; --success: #10B981; --teal: #0EA5E9; --error: #EF4444; }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            background: #f0f4ff;
            color: #1e293b;
            overflow-x: hidden;
            min-height: 100vh;
            -webkit-font-smoothing: antialiased;
        }

        [data-bs-theme="dark"] body {
            background: #0a0e1a;
            color: #e2e8f0;
        }

        .bg-animation {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            pointer-events: none; z-index: 0; overflow: hidden;
        }
        .bg-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.25;
            animation: blobFloat 20s infinite ease-in-out;
        }
        .bg-blob:nth-child(1) {
            width: 500px; height: 500px;
            background: #8B5CF6;
            top: -100px; right: -100px;
        }
        .bg-blob:nth-child(2) {
            width: 400px; height: 400px;
            background: #2563EB;
            bottom: -100px; left: -100px;
            animation-delay: -7s;
        }
        .bg-blob:nth-child(3) {
            width: 300px; height: 300px;
            background: #10B981;
            top: 50%; left: 50%;
            animation-delay: -14s;
        }

        @keyframes blobFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(80px, -40px) scale(1.1); }
            66% { transform: translate(-40px, 60px) scale(0.9); }
        }

        [data-bs-theme="dark"] .bg-blob { opacity: 0.12; }

        /* ============ NAVBAR ============ */
        .navbar {
            position: fixed;
            top: 15px;
            left: 50%;
            transform: translateX(-50%);
            width: 92%;
            max-width: 1200px;
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 20px;
            padding: 12px 20px;
            z-index: 1000;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.06);
        }

        [data-bs-theme="dark"] .navbar {
            background: rgba(15, 23, 42, 0.75);
            border-color: rgba(255, 255, 255, 0.08);
        }

        .navbar-brand {
            font-size: 1.25rem;
            font-weight: 800;
            background: linear-gradient(135deg, #2563EB, #8B5CF6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-decoration: none;
            white-space: nowrap;
        }

        .navbar-brand i {
            background: linear-gradient(135deg, #2563EB, #0EA5E9);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .theme-btn {
            width: 40px; height: 40px; min-width: 40px;
            border-radius: 12px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            background: rgba(255, 255, 255, 0.5);
            color: #64748b;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* ============ FORM WRAPPER ============ */
        .form-wrapper {
            position: relative;
            z-index: 1;
            padding: 120px 16px 60px;
            max-width: 800px;
            margin: 0 auto;
        }

        .glass-card {
            background: rgba(255, 255, 255, 0.55);
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.5);
            border-radius: 24px;
            padding: 32px 24px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.06);
            margin-bottom: 20px;
        }

        [data-bs-theme="dark"] .glass-card {
            background: rgba(30, 41, 59, 0.55);
            border-color: rgba(255, 255, 255, 0.06);
        }

        @media (min-width: 768px) { .glass-card { padding: 40px 36px; } }

        /* Item Preview */
        .item-preview {
            display: flex;
            gap: 16px;
            align-items: center;
            flex-wrap: wrap;
        }

        .item-preview-image {
            width: 100px;
            height: 100px;
            border-radius: 16px;
            object-fit: cover;
            background: linear-gradient(135deg, #f1f5f9, #e2e8f0);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #94a3b8;
            font-size: 36px;
            flex-shrink: 0;
        }

        [data-bs-theme="dark"] .item-preview-image {
            background: linear-gradient(135deg, #1e293b, #334155);
        }

        .item-preview-info h5 {
            font-weight: 700;
            font-size: 1.1rem;
            margin-bottom: 4px;
        }

        .item-preview-info .meta {
            font-size: 0.85rem;
            color: #64748b;
            display: flex;
            align-items: center;
            gap: 6px;
            margin-bottom: 3px;
        }

        [data-bs-theme="dark"] .item-preview-info .meta {
            color: #94a3b8;
        }

        .item-preview-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            background: rgba(16, 185, 129, 0.1);
            color: #10B981;
        }

        /* Form Header */
        .form-header { text-align: center; margin-bottom: 28px; }
        .form-header .icon-circle {
            width: 72px; height: 72px;
            border-radius: 24px;
            background: linear-gradient(135deg, rgba(139, 92, 246, 0.15), rgba(37, 99, 235, 0.15));
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            font-size: 30px;
            color: #8B5CF6;
        }
        .form-header h2 { font-weight: 800; font-size: clamp(1.5rem, 3vw, 1.8rem); letter-spacing: -0.5px; margin-bottom: 4px; }
        .form-header p { color: #64748b; font-size: 0.9rem; }

        [data-bs-theme="dark"] .form-header p { color: #94a3b8; }

        /* Form */
        .form-section-title {
            font-weight: 700;
            font-size: 0.95rem;
            color: #8B5CF6;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
            padding-bottom: 12px;
            border-bottom: 1px solid rgba(139, 92, 246, 0.15);
        }

        .form-label {
            font-weight: 600;
            font-size: 0.85rem;
            color: #475569;
            margin-bottom: 6px;
        }
        [data-bs-theme="dark"] .form-label { color: #cbd5e1; }
        .form-label .required { color: #8B5CF6; }

        .form-control, .form-select {
            border-radius: 12px;
            border: 1.5px solid rgba(0, 0, 0, 0.1);
            padding: 12px 16px;
            font-size: 0.9rem;
            font-family: 'Inter', sans-serif;
            background: rgba(255, 255, 255, 0.7);
            transition: all 0.3s ease;
        }

        [data-bs-theme="dark"] .form-control,
        [data-bs-theme="dark"] .form-select {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(255, 255, 255, 0.1);
            color: #e2e8f0;
        }

        .form-control:focus, .form-select:focus {
            border-color: #8B5CF6;
            box-shadow: 0 0 0 4px rgba(139, 92, 246, 0.1);
        }

        /* Invalid state */
        .form-control.is-invalid, .form-select.is-invalid {
            border-color: #EF4444 !important;
            background-color: rgba(239, 68, 68, 0.02);
        }
        .invalid-feedback {
            color: #EF4444;
            font-size: 0.8rem;
            font-weight: 500;
            margin-top: 4px;
        }

        textarea.form-control { resize: vertical; min-height: 80px; }

        .btn-submit {
            width: 100%;
            padding: 14px 24px;
            border-radius: 14px;
            background: linear-gradient(135deg, #8B5CF6, #2563EB);
            color: #fff;
            border: none;
            font-weight: 700;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 8px 25px rgba(139, 92, 246, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 35px rgba(139, 92, 246, 0.4);
        }

        .alert { border-radius: 14px; border: none; font-weight: 500; }

        @media (max-width: 480px) {
            .navbar { width: 95%; top: 8px; padding: 10px 14px; border-radius: 16px; }
            .navbar-brand { font-size: 1.1rem; }
            .form-wrapper { padding: 100px 10px 40px; }
            .glass-card { padding: 24px 16px; border-radius: 20px; }
            .item-preview { flex-direction: column; align-items: flex-start; }
            .item-preview-image { width: 80px; height: 80px; }
        }
    </style>
</head>
<body>

    <div class="bg-animation">
        <div class="bg-blob"></div>
        <div class="bg-blob"></div>
        <div class="bg-blob"></div>
    </div>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid px-0">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-search-location"></i> Returnify
            </a>
            <div class="d-flex align-items-center gap-2 d-lg-none">
                <button class="theme-btn" onclick="toggleTheme()" aria-label="Toggle theme">
                    <i class="fas fa-moon" id="themeIconMobile"></i>
                </button>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto gap-1">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="found-items.php">Browse Items</a></li>
                    <li class="nav-item"><a class="nav-link" href="report-lost.php">Report Lost</a></li>
                    <li class="nav-item"><a class="nav-link" href="report-found.php">Report Found</a></li>
                    <li class="nav-item"><a class="nav-link" href="track-claim.php">Track Claim</a></li>
                </ul>
                <div class="d-none d-lg-flex align-items-center gap-2">
                    <button class="theme-btn" onclick="toggleTheme()" aria-label="Toggle theme">
                        <i class="fas fa-moon" id="themeIcon"></i>
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <!-- Page Content -->
    <div class="form-wrapper">

        <!-- Item Preview -->
        <div class="glass-card">
            <div class="item-preview">
                <?php if ($item['image']): ?>
                    <img src="../assets/uploads/found/<?= htmlspecialchars($item['image']) ?>" 
                         class="item-preview-image" alt="<?= htmlspecialchars($item['item_name']) ?>">
                <?php else: ?>
                    <div class="item-preview-image">
                        <i class="fas fa-box-open"></i>
                    </div>
                <?php endif; ?>
                <div class="item-preview-info">
                    <span class="item-preview-badge">Found Item</span>
                    <h5><?= htmlspecialchars($item['item_name']) ?></h5>
                    <div class="meta"><i class="fas fa-tag"></i> <?= htmlspecialchars($item['category']) ?></div>
                    <div class="meta"><i class="fas fa-map-marker-alt"></i> Found at: <?= htmlspecialchars($item['location_found']) ?></div>
                    <div class="meta"><i class="fas fa-calendar"></i> <?= date('M d, Y', strtotime($item['date_found'])) ?></div>
                    <?php if ($item['color']): ?>
                        <div class="meta"><i class="fas fa-palette"></i> Color: <?= htmlspecialchars($item['color']) ?></div>
                    <?php endif; ?>
                    <?php if ($item['brand']): ?>
                        <div class="meta"><i class="fas fa-trademark"></i> Brand: <?= htmlspecialchars($item['brand']) ?></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Claim Form -->
        <div class="glass-card">
            <div class="form-header">
                <div class="icon-circle">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h2>Claim This Item</h2>
                <p>Provide your details and proof of ownership</p>
            </div>

            <form method="POST" action="" novalidate>
                <div class="mb-4">
                    <h6 class="form-section-title">
                        <i class="fas fa-user"></i> Your Information
                    </h6>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Full Name <span class="required">*</span></label>
                            <input type="text" class="form-control <?= isset($errors['full_name']) ? 'is-invalid' : '' ?>" 
                                   name="full_name" value="<?= htmlspecialchars($formData['full_name'] ?? '') ?>" 
                                   placeholder="Your full name">
                            <?php if (isset($errors['full_name'])): ?>
                                <div class="invalid-feedback"><i class="fas fa-exclamation-circle me-1"></i><?= $errors['full_name'] ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Student/Staff ID</label>
                            <input type="text" class="form-control <?= isset($errors['student_id']) ? 'is-invalid' : '' ?>" 
                                   name="student_id" value="<?= htmlspecialchars($formData['student_id'] ?? '') ?>" 
                                   placeholder="e.g., STU-2024-001">
                            <?php if (isset($errors['student_id'])): ?>
                                <div class="invalid-feedback"><i class="fas fa-exclamation-circle me-1"></i><?= $errors['student_id'] ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Contact Number <span class="required">*</span></label>
                            <input type="text" class="form-control <?= isset($errors['contact_number']) ? 'is-invalid' : '' ?>" 
                                   name="contact_number" value="<?= htmlspecialchars($formData['contact_number'] ?? '') ?>" 
                                   placeholder="e.g., 0244XXXXXX">
                            <?php if (isset($errors['contact_number'])): ?>
                                <div class="invalid-feedback"><i class="fas fa-exclamation-circle me-1"></i><?= $errors['contact_number'] ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>" 
                                   name="email" value="<?= htmlspecialchars($formData['email'] ?? '') ?>" 
                                   placeholder="your@email.com">
                            <?php if (isset($errors['email'])): ?>
                                <div class="invalid-feedback"><i class="fas fa-exclamation-circle me-1"></i><?= $errors['email'] ?></div>
                            <?php endif; ?>
                            <small class="text-muted">You'll need this to track your claim later.</small>
                        </div>
                    </div>
                </div>

                <div class="mb-4">
                    <h6 class="form-section-title">
                        <i class="fas fa-shield-alt"></i> Proof of Ownership
                    </h6>
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label">Ownership Evidence <span class="required">*</span></label>
                            <textarea class="form-control <?= isset($errors['ownership_evidence']) ? 'is-invalid' : '' ?>" 
                                      name="ownership_evidence" rows="4" 
                                      placeholder="Describe how this item belongs to you. For example:&#10;&#10;- It has a scratch on the bottom left corner&#10;- The case is navy blue with a university sticker&#10;- It has a specific serial number or marking"><?= htmlspecialchars($formData['ownership_evidence'] ?? '') ?></textarea>
                            <?php if (isset($errors['ownership_evidence'])): ?>
                                <div class="invalid-feedback"><i class="fas fa-exclamation-circle me-1"></i><?= $errors['ownership_evidence'] ?></div>
                            <?php endif; ?>
                            <small class="text-muted">The more detail you provide, the faster we can verify your claim.</small>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Additional Notes (optional)</label>
                            <textarea class="form-control" name="additional_notes" rows="2" 
                                placeholder="Any other information that might help..."><?= htmlspecialchars($formData['additional_notes'] ?? '') ?></textarea>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn-submit">
                    <i class="fas fa-paper-plane"></i> Submit Claim
                </button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleTheme() {
            var html = document.documentElement;
            var icons = document.querySelectorAll('#themeIcon, #themeIconMobile');
            var isDark = html.getAttribute('data-bs-theme') === 'dark';
            if (isDark) {
                html.setAttribute('data-bs-theme', 'light');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-moon'; });
                localStorage.setItem('theme', 'light');
            } else {
                html.setAttribute('data-bs-theme', 'dark');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-sun'; });
                localStorage.setItem('theme', 'dark');
            }
        }

        (function() {
            var saved = localStorage.getItem('theme');
            var prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            var icons = document.querySelectorAll('#themeIcon, #themeIconMobile');
            if (saved === 'dark' || (!saved && prefersDark)) {
                document.documentElement.setAttribute('data-bs-theme', 'dark');
                icons.forEach(function(icon) { if (icon) icon.className = 'fas fa-sun'; });
            }
        })();

        document.querySelectorAll('.navbar-nav .nav-link').forEach(function(link) {
            link.addEventListener('click', function() {
                var collapse = document.getElementById('navbarNav');
                if (collapse.classList.contains('show')) {
                    bootstrap.Collapse.getInstance(collapse).hide();
                }
            });
        });
    </script>
</body>
</html>